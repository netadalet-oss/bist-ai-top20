package com.aurum.bisttop20.data.excel

data class SheetSchema(val name:String,val orderedColumns:List<String>,val schemaVersion:Int=1)
data class WorkbookSchema(val workbookId:String,val sheets:List<SheetSchema>)
data class SchemaDifference(val sheet:String,val missing:List<String>,val added:List<String>,val reordered:Boolean)
object ExcelSchemaContract {
 fun normalizeHeader(raw:String)=raw.replace(Regex("[\u200B-\u200D\u2060\uFEFF]"),"").trim()
 fun compare(expected:WorkbookSchema,actual:WorkbookSchema):List<SchemaDifference>{
  val map=actual.sheets.associateBy{it.name}; return expected.sheets.mapNotNull { e -> val a=map[e.name]?:return@mapNotNull SchemaDifference(e.name,e.orderedColumns,emptyList(),false); val ec=e.orderedColumns.map(::normalizeHeader); val ac=a.orderedColumns.map(::normalizeHeader); val miss=ec-ac.toSet(); val add=ac-ec.toSet(); val commonE=ec.filter{it in ac}; val commonA=ac.filter{it in ec}; val r=commonE!=commonA; if(miss.isEmpty()&&add.isEmpty()&&!r)null else SchemaDifference(e.name,miss,add,r) }
 }
}
