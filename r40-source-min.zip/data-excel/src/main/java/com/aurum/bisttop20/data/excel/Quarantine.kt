package com.aurum.bisttop20.data.excel

import java.security.MessageDigest

data class QuarantineRecord(
    val id: String,
    val workbookId: String,
    val address: CellAddress,
    val rawValue: String?,
    val reason: String,
    val observedAtEpochMs: Long,
    val sourceHash: String
)

object QuarantineFactory {
    fun create(workbookId: String, address: CellAddress, rawValue: String?, reason: String, observedAtEpochMs: Long, sourceHash: String): QuarantineRecord {
        val material = listOf(workbookId, address.sheet, address.row, address.column, rawValue, reason, sourceHash).joinToString("|")
        val id = MessageDigest.getInstance("SHA-256").digest(material.toByteArray()).joinToString("") { "%02x".format(it) }
        return QuarantineRecord(id, workbookId, address, rawValue, reason, observedAtEpochMs, sourceHash)
    }
}
