package com.aurum.bisttop20.data.excel

data class WorkbookCompatibilityReport(
    val differences: List<SchemaDifference>,
    val safeForRoundTrip: Boolean,
    val blockingReasons: List<String>
)

object WorkbookCompatibility {
    fun assess(expected: WorkbookSchema, actual: WorkbookSchema): WorkbookCompatibilityReport {
        val differences = ExcelSchemaContract.compare(expected, actual)
        val blockers = buildList {
            differences.forEach { difference ->
                if (difference.missing.isNotEmpty()) add("${difference.sheet}: missing=${difference.missing.joinToString()}")
                if (difference.reordered) add("${difference.sheet}: column order changed")
            }
        }
        return WorkbookCompatibilityReport(differences, blockers.isEmpty(), blockers)
    }
}
