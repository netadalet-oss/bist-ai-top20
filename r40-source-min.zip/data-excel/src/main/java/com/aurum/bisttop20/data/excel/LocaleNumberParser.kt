package com.aurum.bisttop20.data.excel

data class NumberParseResult(val value: Double?, val normalized: String?, val quarantineReason: String?) {
    val accepted: Boolean get() = value != null && quarantineReason == null
}

object LocaleNumberParser {
    private val objectLeak = Regex("^\\[object Object]$", RegexOption.IGNORE_CASE)
    private val allowed = Regex("^[+-]?[0-9][0-9., ]*$")

    fun parse(raw: String?): NumberParseResult {
        val text = raw?.trim().orEmpty()
        if (text.isEmpty()) return NumberParseResult(null, null, "BLANK")
        if (objectLeak.matches(text)) return NumberParseResult(null, null, "SERIALIZATION_OBJECT_LEAK")
        if (!allowed.matches(text)) return NumberParseResult(null, null, "UNSUPPORTED_CHARACTERS")
        val compact = text.replace(" ", "")
        val comma = compact.lastIndexOf(',')
        val dot = compact.lastIndexOf('.')
        val decimalSeparator = when {
            comma >= 0 && dot >= 0 -> if (comma > dot) ',' else '.'
            comma >= 0 -> inferSingleSeparator(compact, ',')
            dot >= 0 -> inferSingleSeparator(compact, '.')
            else -> null
        }
        if ((comma >= 0 || dot >= 0) && decimalSeparator == null && compact.count { it == ',' || it == '.' } > 0) {
            return NumberParseResult(null, null, "AMBIGUOUS_SEPARATOR")
        }
        val normalized = buildString {
            compact.forEachIndexed { index, ch ->
                when {
                    ch == decimalSeparator && index == compact.lastIndexOf(decimalSeparator) -> append('.')
                    ch == ',' || ch == '.' -> Unit
                    else -> append(ch)
                }
            }
        }
        val value = normalized.toDoubleOrNull()
            ?: return NumberParseResult(null, normalized, "NOT_A_NUMBER")
        return NumberParseResult(value, normalized, null)
    }

    private fun inferSingleSeparator(text: String, separator: Char): Char? {
        val count = text.count { it == separator }
        if (count > 1) {
            val groups = text.removePrefix("+").removePrefix("-").split(separator)
            return if (groups.drop(1).all { it.length == 3 }) null else separator
        }
        val decimals = text.substringAfterLast(separator).length
        return when {
            decimals in 1..2 -> separator
            decimals == 3 && text.substringBefore(separator).length <= 3 -> null
            else -> null
        }
    }
}
