package com.aurum.bisttop20.data.excel

data class ImportedValue(val address: CellAddress, val value: Any?)
data class ImportBatch(val accepted: List<ImportedValue>, val quarantined: List<QuarantineRecord>)

class ExcelImportPipeline(private val workbookId: String, private val sourceHash: String) {
    fun importNumeric(cells: List<RawCell>, observedAtEpochMs: Long): ImportBatch {
        val accepted = mutableListOf<ImportedValue>()
        val quarantined = mutableListOf<QuarantineRecord>()
        cells.forEach { cell ->
            when (val value = cell.value) {
                ExcelCell.Blank -> accepted += ImportedValue(cell.address, null)
                is ExcelCell.Number -> accepted += ImportedValue(cell.address, value.value)
                is ExcelCell.Text -> {
                    val result = LocaleNumberParser.parse(value.value)
                    if (result.accepted) accepted += ImportedValue(cell.address, result.value)
                    else quarantined += QuarantineFactory.create(workbookId, cell.address, value.value, result.quarantineReason ?: "UNKNOWN", observedAtEpochMs, sourceHash)
                }
                is ExcelCell.Formula -> quarantined += QuarantineFactory.create(workbookId, cell.address, value.expression, "FORMULA_REQUIRES_EVALUATION", observedAtEpochMs, sourceHash)
                is ExcelCell.Bool -> quarantined += QuarantineFactory.create(workbookId, cell.address, value.value.toString(), "BOOLEAN_IN_NUMERIC_COLUMN", observedAtEpochMs, sourceHash)
                is ExcelCell.Error -> quarantined += QuarantineFactory.create(workbookId, cell.address, value.code, "EXCEL_ERROR", observedAtEpochMs, sourceHash)
            }
        }
        return ImportBatch(accepted, quarantined)
    }
}
