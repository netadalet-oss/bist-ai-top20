package com.aurum.bisttop20.data.excel

data class ColumnMapping(val sourceIndex: Int, val targetIndex: Int, val sourceHeader: String, val canonicalHeader: String)
data class MappingResult(val mappings: List<ColumnMapping>, val missingCanonical: List<String>, val duplicateNormalizedHeaders: List<String>)

object ColumnMapper {
    fun map(sourceHeaders: List<String>, canonicalHeaders: List<String>): MappingResult {
        val normalizedSource = sourceHeaders.map(ExcelSchemaContract::normalizeHeader)
        val duplicates = normalizedSource.groupingBy { it }.eachCount().filterValues { it > 1 }.keys.sorted()
        val mappings = canonicalHeaders.mapIndexedNotNull { targetIndex, canonical ->
            val normalized = ExcelSchemaContract.normalizeHeader(canonical)
            val sourceIndex = normalizedSource.indexOf(normalized)
            if (sourceIndex < 0) null else ColumnMapping(sourceIndex, targetIndex, sourceHeaders[sourceIndex], canonical)
        }
        val mappedTargets = mappings.map { ExcelSchemaContract.normalizeHeader(it.canonicalHeader) }.toSet()
        val missing = canonicalHeaders.filter { ExcelSchemaContract.normalizeHeader(it) !in mappedTargets }
        return MappingResult(mappings, missing, duplicates)
    }
}
