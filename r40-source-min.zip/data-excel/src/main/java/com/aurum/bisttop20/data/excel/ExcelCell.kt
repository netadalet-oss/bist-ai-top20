package com.aurum.bisttop20.data.excel

sealed interface ExcelCell {
    data object Blank : ExcelCell
    data class Text(val value: String) : ExcelCell
    data class Number(val value: Double) : ExcelCell
    data class Bool(val value: Boolean) : ExcelCell
    data class Formula(val expression: String, val cachedValue: String?) : ExcelCell
    data class Error(val code: String) : ExcelCell
}

data class CellAddress(val sheet: String, val row: Int, val column: Int)
data class RawCell(val address: CellAddress, val value: ExcelCell)
