package com.aurum.bisttop20.data.excel
import org.junit.Assert.*
import org.junit.Test
class ExcelSchemaContractTest { @Test fun detectsReorderAndUnicode(){ val e=WorkbookSchema("x",listOf(SheetSchema("S",listOf("Sembol","Skor")))); val ok=WorkbookSchema("x",listOf(SheetSchema("S",listOf("\uFEFFSembol","Skor")))); assertTrue(ExcelSchemaContract.compare(e,ok).isEmpty()); val bad=WorkbookSchema("x",listOf(SheetSchema("S",listOf("Skor","Sembol")))); assertTrue(ExcelSchemaContract.compare(e,bad).single().reordered) } }
