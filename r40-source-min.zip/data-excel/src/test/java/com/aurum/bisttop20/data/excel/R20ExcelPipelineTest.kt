package com.aurum.bisttop20.data.excel

import org.junit.Assert.*
import org.junit.Test

class R20ExcelPipelineTest {
    @Test fun parsesTurkishAndInternationalNumbers() {
        assertEquals(2744.17, LocaleNumberParser.parse("2.744,17").value!!, 0.000001)
        assertEquals(2744.17, LocaleNumberParser.parse("2744.17").value!!, 0.000001)
        assertEquals(14.66, LocaleNumberParser.parse("14,66").value!!, 0.000001)
    }
    @Test fun quarantinesObjectLeakAndAmbiguousInput() {
        assertEquals("SERIALIZATION_OBJECT_LEAK", LocaleNumberParser.parse("[object Object]").quarantineReason)
        assertFalse(LocaleNumberParser.parse("1.234").accepted)
    }
    @Test fun preservesColumnOrderAndNormalizesUnicode() {
        val result = ColumnMapper.map(listOf("\uFEFFSembol", "Skor"), listOf("Sembol", "Skor"))
        assertTrue(result.missingCanonical.isEmpty())
        assertEquals(listOf(0,1), result.mappings.map { it.sourceIndex })
    }
    @Test fun createsDeterministicQuarantineId() {
        val address = CellAddress("K5", 2, 9)
        val a = QuarantineFactory.create("wb", address, "[object Object]", "SERIALIZATION_OBJECT_LEAK", 1L, "a".repeat(64))
        val b = QuarantineFactory.create("wb", address, "[object Object]", "SERIALIZATION_OBJECT_LEAK", 2L, "a".repeat(64))
        assertEquals(a.id, b.id)
    }
}
