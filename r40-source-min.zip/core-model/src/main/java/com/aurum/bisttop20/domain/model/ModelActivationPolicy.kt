package com.aurum.bisttop20.domain.model

enum class ModelSlot { K1, K2, K3, K4, K5, K6, K7, K8, K9, K10 }
enum class ModelStage { DRAFT, WALK_FORWARD_PASSED, SHADOW_PASSED, PAPER_TRADING_PASSED, ACCEPTED, RETIRED }
enum class ModelRole { CHAMPION, CHALLENGER }

data class ModelActivationRequest(
    val slot: ModelSlot,
    val version: String,
    val artifactHash: String,
    val stage: ModelStage,
    val role: ModelRole,
    val trainedAt: Long?,
    val lastValidDataAt: Long?,
    val externalMetricsRecorded: Boolean,
    val userApprovalRecorded: Boolean,
)

data class ModelActivationDecision(val active: Boolean, val reasons: List<String>)

/** Prevents untrained or unaccepted K6-K10 models from appearing as active. */
object ModelActivationPolicy {
    fun evaluate(request: ModelActivationRequest): ModelActivationDecision {
        val errors = buildList {
            if (request.version.isBlank()) add("model version is required")
            if (!request.artifactHash.matches(Regex("[a-fA-F0-9]{64}"))) add("SHA-256 artifact hash is required")
            if (request.trainedAt == null) add("training timestamp is required")
            if (request.lastValidDataAt == null) add("last valid data timestamp is required")
            if (!request.externalMetricsRecorded) add("out-of-sample metrics are required")
            if (request.stage != ModelStage.ACCEPTED) add("model has not passed the acceptance gate")
            if (!request.userApprovalRecorded) add("controlled production approval is required")
        }
        return ModelActivationDecision(errors.isEmpty(), errors)
    }
}
