package com.aurum.bisttop20.core.model

data class SourceStamp(val sourceId:String,val observedAt:Long,val acquiredAt:Long,val availableForPredictionAt:Long,val schemaVersion:Int,val dataVersion:String,val deduplicationKey:String,val sourceHash:String)
data class PredictionIdentity(val runId:String,val decisionTimestamp:Long,val dataCutoffTimestamp:Long,val targetHorizon:String,val modelVersion:String,val featureVersion:String,val universeVersion:String,val snapshotHash:String)
data class RankedCandidate(val symbol:String,val rank:Int,val rawScore:Double,val calibratedProbability:Double?,val expectedNetReturn:Double?,val uncertainty:Double?,val qualityScore:Double)
enum class QualityStatus { VALID, QUARANTINED, REJECTED, STALE, CONFLICT }
