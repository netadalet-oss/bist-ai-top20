package com.aurum.bisttop20.domain.calendar

data class TradingDayState(val officialTradingDay:Boolean,val sessionCompleted:Boolean,val closeReceived:Boolean,val requiredSymbolsComplete:Boolean,val qualityPassed:Boolean,val snapshotAlreadyWritten:Boolean)
object TradingCalendarPolicy { fun mayRollover(s: TradingDayState)=s.officialTradingDay&&s.sessionCompleted&&s.closeReceived&&s.requiredSymbolsComplete&&s.qualityPassed&&!s.snapshotAlreadyWritten }
