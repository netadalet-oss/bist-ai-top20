plugins { alias(libs.plugins.kotlin.android); alias(libs.plugins.android.library) }
android { namespace = "com.aurum.bisttop20.data.adapters"; compileSdk = 35; defaultConfig { minSdk = 26 }; compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }; kotlinOptions { jvmTarget = "17" } }
dependencies { implementation(project(":core-network")); implementation(project(":domain-staging")); implementation(project(":domain-events")) }
