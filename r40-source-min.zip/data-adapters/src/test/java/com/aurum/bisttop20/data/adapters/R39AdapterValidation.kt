package com.aurum.bisttop20.data.adapters

import com.aurum.bisttop20.network.*

private class EchoTransport:HttpTransport{
 override fun execute(request:HttpRequest,connectTimeoutMs:Int,readTimeoutMs:Int)=HttpResponse(200,("payload:"+request.url).toByteArray(),emptyMap())
}
fun main(){
 val client=ResilientHttpClient(EchoTransport(), sleeper={})
 val p=IsYatirimPriceAdapter(listOf("THYAO","ASELS"),client).fetch(Long.MAX_VALUE)
 check(p.size==2 && p.all{it.payloadBase64.isNotBlank() && it.sourceHashSha256.length==64})
 val k=KapDisclosureAdapter(client).fetch(Long.MAX_VALUE); check(k.single().sourceId=="kap-disclosures")
 val n=EconomyNewsRssAdapter(client).fetch(Long.MAX_VALUE); check(n.single().sourceId=="aa-economy-news")
 val m=TcmbEvdsMacroAdapter("key",listOf("TP.DK.USD.A.YTL"),client).fetch(Long.MAX_VALUE); check(m.single().sourceId=="tcmb-evds-macro")
 var missing=false; try{TcmbEvdsMacroAdapter("",listOf("X"),client).fetch(Long.MAX_VALUE)}catch(_:IllegalArgumentException){missing=true}; check(missing)
 println("R39_ADAPTERS_PASS")
}
