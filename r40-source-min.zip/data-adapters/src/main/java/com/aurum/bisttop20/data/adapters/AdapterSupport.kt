package com.aurum.bisttop20.data.adapters

import com.aurum.bisttop20.domain.staging.*
import java.security.MessageDigest
import java.time.Instant
import java.util.Base64

object Hashing { fun sha256(bytes: ByteArray)=MessageDigest.getInstance("SHA-256").digest(bytes).joinToString(""){"%02x".format(it)} }
fun record(sourceId:String, id:String, observedAt:Long, acquiredAt:Long, payload:ByteArray): AdapterRecord {
    val h=Hashing.sha256(payload)
    return AdapterRecord(id,"$sourceId:$id",sourceId,h,observedAt,acquiredAt,acquiredAt,h,Base64.getEncoder().encodeToString(payload),QualityDecision.ACCEPT)
}
fun parseIsoOrEpoch(value:String?):Long = try { Instant.parse(value).toEpochMilli() } catch(_:Exception) { value?.toLongOrNull() ?: System.currentTimeMillis() }
