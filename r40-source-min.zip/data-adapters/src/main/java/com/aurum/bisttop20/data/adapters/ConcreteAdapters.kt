package com.aurum.bisttop20.data.adapters

import com.aurum.bisttop20.domain.staging.*
import com.aurum.bisttop20.network.*
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

abstract class HttpMarketAdapter(
    final override val adapterId:String,
    protected val client:ResilientHttpClient,
    protected val retry:RetryPolicy,
    protected val quota:QuotaPolicy
): MarketDataAdapter

/** Existing Apps Script source-compatible İş Yatırım adapter. Endpoint use remains subject to provider terms. */
class IsYatirimPriceAdapter(
    private val symbols:List<String>, client:ResilientHttpClient,
    retry:RetryPolicy=RetryPolicy(maxAttempts=3,readTimeoutMs=12_000),
    quota:QuotaPolicy=QuotaPolicy(120,60_000),
    private val primaryTemplate:String="https://www.isyatirim.com.tr/_layouts/15/Isyatirim.Website/Common/Data.aspx/HisseTekil?hisse={SYMBOL}",
    private val fallbackTemplate:String?=null
):HttpMarketAdapter("is-yatirim-price",client,retry,quota){
    override fun fetch(cutoffAt:Long):List<AdapterRecord> = symbols.distinct().sorted().map { sym ->
        val enc=URLEncoder.encode(sym,StandardCharsets.UTF_8.name())
        val urls=listOfNotNull(primaryTemplate.replace("{SYMBOL}",enc), fallbackTemplate?.replace("{SYMBOL}",enc))
        val r=client.get(adapterId,urls,retry,quota); val acquired=System.currentTimeMillis()
        record(adapterId,"$sym:$cutoffAt",acquired,acquired,r.body)
    }
}

/** KAP public disclosure query page adapter. HTML is retained raw; canonical parsing occurs downstream. */
class KapDisclosureAdapter(
    client:ResilientHttpClient,
    retry:RetryPolicy=RetryPolicy(maxAttempts=3,readTimeoutMs=20_000),
    quota:QuotaPolicy=QuotaPolicy(30,60_000),
    private val primaryUrl:String="https://www.kap.org.tr/tr/bildirim-sorgu",
    private val fallbackUrl:String="https://www.kap.org.tr/tr/bildirim-sorgu-sonuc"
):HttpMarketAdapter("kap-disclosures",client,retry,quota){
    override fun fetch(cutoffAt:Long):List<AdapterRecord>{
        val r=client.get(adapterId,listOf(primaryUrl,fallbackUrl),retry,quota,mapOf("Accept" to "text/html")); val acquired=System.currentTimeMillis()
        return listOf(record(adapterId,"kap:$cutoffAt",acquired,acquired,r.body))
    }
}

/** Licensed/configured RSS endpoint adapter. The default points to AA's published economy RSS page endpoint. */
class EconomyNewsRssAdapter(
    client:ResilientHttpClient,
    retry:RetryPolicy=RetryPolicy(maxAttempts=3,readTimeoutMs=15_000),
    quota:QuotaPolicy=QuotaPolicy(20,60_000),
    private val primaryUrl:String="https://www.aa.com.tr/tr/teyithatti/rss/news?cat=ekonomi",
    private val fallbackUrl:String="https://www.aa.com.tr/tr/latest/ekonomi"
):HttpMarketAdapter("aa-economy-news",client,retry,quota){
    override fun fetch(cutoffAt:Long):List<AdapterRecord>{
        val r=client.get(adapterId,listOf(primaryUrl,fallbackUrl),retry,quota,mapOf("Accept" to "application/rss+xml, application/xml, text/html")); val acquired=System.currentTimeMillis()
        return listOf(record(adapterId,"news:$cutoffAt",acquired,acquired,r.body))
    }
}

/** TCMB EVDS adapter. Requires a user-provided API key and explicit series codes. */
class TcmbEvdsMacroAdapter(
    private val apiKey:String,
    private val series:List<String>,
    client:ResilientHttpClient,
    retry:RetryPolicy=RetryPolicy(maxAttempts=3,readTimeoutMs=20_000),
    quota:QuotaPolicy=QuotaPolicy(30,60_000),
    private val baseUrls:List<String> = listOf("https://evds2.tcmb.gov.tr/service/evds/series=", "https://evds3.tcmb.gov.tr/service/evds/series=")
):HttpMarketAdapter("tcmb-evds-macro",client,retry,quota){
    override fun fetch(cutoffAt:Long):List<AdapterRecord>{
        require(apiKey.isNotBlank()){ "EVDS_API_KEY_REQUIRED" }; require(series.isNotEmpty()){ "EVDS_SERIES_REQUIRED" }
        val codes=series.joinToString("-"); val suffix="$codes&startDate=01-01-2020&endDate=31-12-2099&type=json"
        val urls=baseUrls.map{it+suffix}
        val r=client.get(adapterId,urls,retry,quota,mapOf("key" to apiKey,"Accept" to "application/json")); val acquired=System.currentTimeMillis()
        return listOf(record(adapterId,"macro:$codes:$cutoffAt",acquired,acquired,r.body))
    }
}
