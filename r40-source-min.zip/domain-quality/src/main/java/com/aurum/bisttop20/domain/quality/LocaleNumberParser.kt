package com.aurum.bisttop20.domain.quality

object LocaleNumberParser {
    sealed interface Result { data class Valid(val value: Double): Result; data class Quarantine(val raw: String, val reason: String): Result }
    fun parse(raw: String?): Result {
        val s = raw?.trim()?.replace("\u00A0", "")?.replace(" ", "") ?: return Result.Quarantine("", "null")
        if (s.isEmpty()) return Result.Quarantine(s, "empty")
        if (!s.matches(Regex("[-+]?\\d{1,3}([.,]\\d{3})*([.,]\\d+)?|[-+]?\\d+([.,]\\d+)?"))) return Result.Quarantine(s, "invalid_characters")
        val comma=s.lastIndexOf(','); val dot=s.lastIndexOf('.')
        val normalized = when {
            comma>=0 && dot>=0 -> if (comma>dot) s.replace(".", "").replace(',', '.') else s.replace(",", "")
            comma>=0 -> if (s.substringAfterLast(',').length==3 && s.count{it==','}==1) s.replace(",", "") else s.replace(',', '.')
            dot>=0 -> if (s.substringAfterLast('.').length==3 && s.count{it=='.'}==1) s.replace(".", "") else s
            else -> s
        }
        return normalized.toDoubleOrNull()?.let { Result.Valid(it) } ?: Result.Quarantine(s, "ambiguous")
    }
}
