package com.aurum.bisttop20.domain.quality

enum class DataQualityFlag {
    CORPORATE_ACTION,
    PRICE_SCALE_ERROR,
    STALE_CLOSE,
    RETURN_OUTLIER,
    DUPLICATE_SNAPSHOT,
    SYMBOL_CHANGE,
    SOURCE_CONFLICT,
    INSUFFICIENT_HISTORY,
    POINT_IN_TIME_VIOLATION,
    MANUAL_REVIEW_REQUIRED,
}

enum class QualityDisposition { VALIDATED, QUARANTINED, REJECTED_FOR_TRAINING }

data class QualityAssessment(
    val flags: Set<DataQualityFlag>,
    val disposition: QualityDisposition,
    val explanation: String,
)

object DataQualityPolicy {
    private val trainingBlockers = setOf(
        DataQualityFlag.PRICE_SCALE_ERROR,
        DataQualityFlag.RETURN_OUTLIER,
        DataQualityFlag.SOURCE_CONFLICT,
        DataQualityFlag.POINT_IN_TIME_VIOLATION,
        DataQualityFlag.MANUAL_REVIEW_REQUIRED,
    )

    fun assess(flags: Set<DataQualityFlag>): QualityAssessment = when {
        flags.isEmpty() -> QualityAssessment(flags, QualityDisposition.VALIDATED, "No quality flags")
        flags.any { it in trainingBlockers } -> QualityAssessment(
            flags,
            QualityDisposition.REJECTED_FOR_TRAINING,
            "Record remains preserved but cannot be used in training until resolved",
        )
        else -> QualityAssessment(flags, QualityDisposition.QUARANTINED, "Record requires reconciliation")
    }
}
