package com.aurum.bisttop20.domain.technical

data class SupportResistanceResult(val support: Double?, val resistance: Double?, val supportDistancePct: Double?, val resistanceDistancePct: Double?, val downsideRiskPct: Double?, val upsidePotentialPct: Double?, val riskReward: Double?)
object SupportResistance {
    fun calculate(price: Double, levels: Collection<Double>): SupportResistanceResult {
        require(price > 0)
        val valid=levels.filter { it.isFinite() && it>0 }.distinct().sorted()
        val support=valid.lastOrNull { it < price }; val resistance=valid.firstOrNull { it > price }
        val down=support?.let { (price-it)/price*100.0 }; val up=resistance?.let { (it-price)/price*100.0 }
        return SupportResistanceResult(support,resistance,down,up,down,up,if(down!=null&&down>0&&up!=null) up/down else null)
    }
}
