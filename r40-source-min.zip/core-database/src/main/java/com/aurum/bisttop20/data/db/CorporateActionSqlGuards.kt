package com.aurum.bisttop20.data.db

import androidx.sqlite.db.SupportSQLiteDatabase

object CorporateActionSqlGuards {
    fun install(db:SupportSQLiteDatabase) {
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS adjusted_price_bars_no_update BEFORE UPDATE ON adjusted_price_bars WHEN OLD.frozen=1 BEGIN SELECT RAISE(ABORT,'adjusted price bars are versioned and immutable'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS adjusted_price_bars_no_delete BEFORE DELETE ON adjusted_price_bars WHEN OLD.frozen=1 BEGIN SELECT RAISE(ABORT,'adjusted price bars are versioned and immutable'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS adjustment_versions_no_update BEFORE UPDATE ON adjustment_versions BEGIN SELECT RAISE(ABORT,'adjustment versions are append-only'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS adjustment_versions_no_delete BEFORE DELETE ON adjustment_versions BEGIN SELECT RAISE(ABORT,'adjustment versions are append-only'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS corporate_action_impacts_prediction_guard BEFORE INSERT ON corporate_action_impacts WHEN NEW.historicalPredictionsModified=1 BEGIN SELECT RAISE(ABORT,'historical predictions cannot be modified'); END""")
    }
}
