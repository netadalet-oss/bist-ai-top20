package com.aurum.bisttop20.data.db

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import com.aurum.bisttop20.domain.risk.ObservableRiskStateStore
import com.aurum.bisttop20.domain.risk.RiskControlDecision
import com.aurum.bisttop20.domain.risk.RiskAuditEvent
import com.aurum.bisttop20.domain.risk.RiskControlState
import java.security.MessageDigest

@Entity(tableName = "risk_control_state")
data class RiskControlStateEntity(
    @PrimaryKey val singletonId: Int = 1,
    val state: String,
    val reason: String,
    val updatedAt: Long,
    val approvedBy: String?
)

@Dao
interface RiskControlDao {
    @Query("SELECT * FROM risk_control_state WHERE singletonId = 1")
    suspend fun currentState(): RiskControlStateEntity?

    @Query("SELECT * FROM risk_control_state WHERE singletonId = 1")
    fun observeState(): Flow<RiskControlStateEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun replaceState(state: RiskControlStateEntity)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun appendAudit(event: AuditEventEntity)

    @Transaction
    suspend fun persistTransition(
        event: RiskAuditEvent,
        reason: String,
        actor: String,
        approvedBy: String? = null
    ) {
        appendAudit(event.toAuditEntity(actor))
        replaceState(
            RiskControlStateEntity(
                state = event.stateAfter.name,
                reason = reason,
                updatedAt = event.timestamp,
                approvedBy = approvedBy
            )
        )
    }
}

fun RiskControlStateEntity.asDomain(): RiskControlState = RiskControlState.valueOf(state)

private fun RiskAuditEvent.toAuditEntity(actor: String): AuditEventEntity {
    val payload = listOf(
        eventId, timestamp.toString(), severity.name, code, message,
        affectedSymbols.sorted().joinToString(","), stateBefore.name, stateAfter.name
    ).joinToString("|")
    val hash = MessageDigest.getInstance("SHA-256")
        .digest(payload.toByteArray())
        .joinToString("") { "%02x".format(it) }
    return AuditEventEntity(
        auditId = eventId,
        eventType = code,
        actor = actor,
        entityType = "RISK_CONTROL",
        entityId = "singleton",
        payloadHash = hash,
        occurredAt = timestamp
    )
}


class RoomRiskStateStore(private val dao: RiskControlDao) : ObservableRiskStateStore {
    override suspend fun read(): RiskControlState = dao.currentState()?.asDomain() ?: RiskControlState.PAUSED

    override fun observe(): Flow<RiskControlState> = dao.observeState().map { it?.asDomain() ?: RiskControlState.PAUSED }

    override suspend fun append(decision: RiskControlDecision, actor: String, reason: String, approvedBy: String?) {
        val event = decision.auditEvents.singleOrNull()
            ?: error("Exactly one risk audit event is required for a state transition")
        dao.persistTransition(event, reason, actor, approvedBy)
    }
}
