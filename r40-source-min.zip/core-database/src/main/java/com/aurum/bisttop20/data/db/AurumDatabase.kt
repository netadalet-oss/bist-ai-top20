package com.aurum.bisttop20.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities=[InstrumentEntity::class,SymbolHistoryEntity::class,TradingCalendarEntity::class,MarketSnapshotEntity::class,PriceBarEntity::class,OrderBookSnapshotEntity::class,CorporateActionEntity::class,KapDisclosureEntity::class,NewsEventEntity::class,MacroObservationEntity::class,FundamentalObservationEntity::class,FeatureSnapshotEntity::class,StockDnaProfileEntity::class,MarketRegimeEntity::class,PredictionRunEntity::class,PredictionItemEntity::class,PredictionRevisionEntity::class,ActualOutcomeEntity::class,TradeCostEstimateEntity::class,ModelVersionEntity::class,FeatureVersionEntity::class,UniverseVersionEntity::class,DataSourceEntity::class,SourceHealthEntity::class,SourceConflictEntity::class,DataQualityIssueEntity::class,JobExecutionEntity::class,AuditEventEntity::class,ChampionChallengerEvaluationEntity::class,WarehouseRecordEntity::class,WarehouseTransitionEntity::class,FeatureSnapshotInputEntity::class,UniverseMemberEntity::class,SymbolEventEntity::class,ExchangeSessionEntity::class,MarketHolidayEntity::class,AdjustmentVersionEntity::class,AdjustedPriceBarEntity::class,CorporateActionImpactEntity::class,CanonicalEventEntity::class,EventRevisionEntity::class,AiEventInterpretationEntity::class,RiskControlStateEntity::class,StagingBatchEntity::class,StagingRecordEntity::class,PublishReceiptEntity::class],version=8,exportSchema=true)
abstract class AurumDatabase:RoomDatabase(){ abstract fun predictionDao():PredictionDao
    abstract fun warehouseDao():WarehouseDao
    abstract fun universeDao():UniverseDao
    abstract fun corporateActionDao():CorporateActionDao
    abstract fun eventDao():EventDao
    abstract fun riskControlDao():RiskControlDao
    abstract fun jobExecutionDao():JobExecutionDao
    abstract fun stagingDao():StagingDao
}
