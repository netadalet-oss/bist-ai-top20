package com.aurum.bisttop20.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface UniverseDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertMembers(rows: List<UniverseMemberEntity>)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertSymbolEvents(rows: List<SymbolEventEntity>)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertSession(row: ExchangeSessionEntity)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertHoliday(row: MarketHolidayEntity)

    @Query("""SELECT * FROM universe_members
        WHERE effectiveFrom <= :date
          AND (effectiveToExclusive IS NULL OR :date < effectiveToExclusive)
          AND (firstTradingDate IS NULL OR firstTradingDate <= :date)
          AND (delistedDate IS NULL OR :date < delistedDate)
          AND tradingStatus = 'OPEN'
        ORDER BY symbol""")
    suspend fun tradableUniverse(date: String): List<UniverseMemberEntity>

    @Query("SELECT * FROM exchange_sessions WHERE tradingDate=:date LIMIT 1")
    suspend fun session(date: String): ExchangeSessionEntity?
}
