package com.aurum.bisttop20.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface WarehouseDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertRecord(record: WarehouseRecordEntity)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertTransition(transition: WarehouseTransitionEntity)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertFeatureInputs(inputs: List<FeatureSnapshotInputEntity>)

    @Query("SELECT * FROM warehouse_records WHERE uniqueId=:recordId")
    suspend fun record(recordId: String): WarehouseRecordEntity?

    @Query("SELECT * FROM warehouse_records WHERE layer=:layer ORDER BY createdAt DESC")
    suspend fun recordsByLayer(layer: String): List<WarehouseRecordEntity>

    @Query("SELECT COUNT(*) FROM warehouse_records WHERE layer='RAW' AND deduplicationKey=:key")
    suspend fun rawCountByDeduplicationKey(key: String): Int

    @Query("SELECT * FROM warehouse_records WHERE availableForPredictionTimestamp<=:cutoff AND layer='CANONICAL'")
    suspend fun canonicalAvailableAt(cutoff: Long): List<WarehouseRecordEntity>

    @Query("SELECT * FROM feature_snapshot_inputs WHERE featureSnapshotId=:featureSnapshotId")
    suspend fun featureInputs(featureSnapshotId: String): List<FeatureSnapshotInputEntity>
}
