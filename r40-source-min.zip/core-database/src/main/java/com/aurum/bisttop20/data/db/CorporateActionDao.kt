package com.aurum.bisttop20.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface CorporateActionDao {
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertAdjustmentVersion(entity:AdjustmentVersionEntity)
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertAdjustedBars(entities:List<AdjustedPriceBarEntity>)
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertImpact(entity:CorporateActionImpactEntity)
    @Query("SELECT * FROM adjusted_price_bars WHERE instrumentId=:instrumentId AND adjustmentVersion=:version ORDER BY timestamp")
    suspend fun adjustedSeries(instrumentId:String, version:String):List<AdjustedPriceBarEntity>
    @Query("SELECT * FROM adjustment_versions WHERE adjustmentVersion=:version LIMIT 1")
    suspend fun version(version:String):AdjustmentVersionEntity?

    @Transaction
    suspend fun publish(version:AdjustmentVersionEntity, bars:List<AdjustedPriceBarEntity>, impact:CorporateActionImpactEntity) {
        require(version.status == "VALIDATED") { "only validated adjustment version can publish" }
        require(!impact.historicalPredictionsModified) { "historical predictions must not be modified" }
        insertAdjustmentVersion(version)
        insertAdjustedBars(bars)
        insertImpact(impact)
    }
}
