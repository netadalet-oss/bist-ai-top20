package com.aurum.bisttop20.data.db

import android.content.Context
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

/** Creates the canonical database and installs SQL-level append-only guards. */
object DatabaseFactory {
    fun create(context: Context): AurumDatabase =
        Room.databaseBuilder(context, AurumDatabase::class.java, "aurum-canonical.db")
            .addMigrations(*AurumMigrations.ALL)
            .addCallback(ImmutabilityCallback)
            .build()

    private object ImmutabilityCallback : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            WarehouseSqlGuards.install(db)
            CorporateActionSqlGuards.install(db)
            db.execSQL("""
                CREATE TRIGGER IF NOT EXISTS prediction_runs_no_update
                BEFORE UPDATE ON prediction_runs
                BEGIN SELECT RAISE(ABORT, 'prediction_runs are append-only'); END
            """.trimIndent())
            db.execSQL("""
                CREATE TRIGGER IF NOT EXISTS prediction_runs_no_delete
                BEFORE DELETE ON prediction_runs
                BEGIN SELECT RAISE(ABORT, 'prediction_runs are append-only'); END
            """.trimIndent())
            db.execSQL("""
                CREATE TRIGGER IF NOT EXISTS prediction_items_no_update
                BEFORE UPDATE ON prediction_items
                BEGIN SELECT RAISE(ABORT, 'prediction_items are append-only'); END
            """.trimIndent())
            db.execSQL("""
                CREATE TRIGGER IF NOT EXISTS prediction_items_no_delete
                BEFORE DELETE ON prediction_items
                BEGIN SELECT RAISE(ABORT, 'prediction_items are append-only'); END
            """.trimIndent())
            db.execSQL("""
                CREATE TRIGGER IF NOT EXISTS feature_snapshots_no_update_when_frozen
                BEFORE UPDATE ON feature_snapshots
                WHEN OLD.frozen = 1
                BEGIN SELECT RAISE(ABORT, 'frozen feature snapshots are immutable'); END
            """.trimIndent())
            db.execSQL("""
                CREATE TRIGGER IF NOT EXISTS feature_snapshots_no_delete_when_frozen
                BEFORE DELETE ON feature_snapshots
                WHEN OLD.frozen = 1
                BEGIN SELECT RAISE(ABORT, 'frozen feature snapshots are immutable'); END
            """.trimIndent())
        }
        override fun onOpen(db: SupportSQLiteDatabase) {
            super.onOpen(db)
            WarehouseSqlGuards.install(db)
            CorporateActionSqlGuards.install(db)
        }
    }
}
