package com.aurum.bisttop20.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
abstract class PredictionDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) protected abstract suspend fun insertRunInternal(run:PredictionRunEntity)
    @Insert(onConflict = OnConflictStrategy.ABORT) protected abstract suspend fun insertItemsInternal(items:List<PredictionItemEntity>)
    @Insert(onConflict = OnConflictStrategy.ABORT) abstract suspend fun insertOutcome(outcome:ActualOutcomeEntity)
    @Query("SELECT * FROM prediction_runs ORDER BY decisionTimestamp DESC") abstract suspend fun runs():List<PredictionRunEntity>
    @Query("SELECT * FROM prediction_items WHERE predictionRunId=:runId ORDER BY predictedRank") abstract suspend fun items(runId:String):List<PredictionItemEntity>
    @Transaction open suspend fun appendPrediction(run:PredictionRunEntity,items:List<PredictionItemEntity>){ require(items.isNotEmpty()); require(items.all{it.predictionRunId==run.predictionRunId}); insertRunInternal(run); insertItemsInternal(items) }
    // Deliberately no UPDATE or DELETE operation: predictions are append-only by API design.
}
