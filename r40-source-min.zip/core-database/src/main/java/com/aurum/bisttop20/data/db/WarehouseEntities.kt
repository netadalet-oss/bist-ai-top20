package com.aurum.bisttop20.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "warehouse_records",
    indices = [
        Index(value = ["layer", "deduplicationKey"], unique = true),
        Index(value = ["availableForPredictionTimestamp"]),
        Index(value = ["sourceId", "sourceHashSha256"])
    ]
)
data class WarehouseRecordEntity(
    @PrimaryKey val uniqueId: String,
    val layer: String,
    val deduplicationKey: String,
    val sourceId: String,
    val sourceHashSha256: String,
    val effectiveTimestamp: Long,
    val observedTimestamp: Long,
    val acquiredTimestamp: Long,
    val availableForPredictionTimestamp: Long,
    val schemaVersion: String,
    val dataVersion: String,
    val payloadJson: String,
    val payloadHashSha256: String,
    val parentRecordId: String?,
    val supersedesId: String?,
    val frozen: Boolean,
    val createdAt: Long
)

@Entity(
    tableName = "warehouse_transitions",
    indices = [Index(value = ["fromRecordId"]), Index(value = ["toRecordId"])]
)
data class WarehouseTransitionEntity(
    @PrimaryKey val transitionId: String,
    val fromRecordId: String,
    val toRecordId: String,
    val fromLayer: String,
    val toLayer: String,
    val reasonCode: String,
    val actor: String,
    val occurredAt: Long
)

@Entity(tableName = "feature_snapshot_inputs", primaryKeys = ["featureSnapshotId", "warehouseRecordId"])
data class FeatureSnapshotInputEntity(
    val featureSnapshotId: String,
    val warehouseRecordId: String,
    val sourceHashSha256: String,
    val availableForPredictionTimestamp: Long
)
