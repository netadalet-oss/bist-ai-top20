package com.aurum.bisttop20.data.db

import androidx.room.withTransaction

interface PredictionArchiveRepository {
    suspend fun appendRun(run: PredictionRunEntity, items: List<PredictionItemEntity>)
    suspend fun appendOutcomes(outcomes: List<ActualOutcomeEntity>)
}

class RoomPredictionArchiveRepository(private val db: AurumDatabase) : PredictionArchiveRepository {
    override suspend fun appendRun(run: PredictionRunEntity, items: List<PredictionItemEntity>) {
        db.predictionDao().appendPrediction(run, items)
    }

    override suspend fun appendOutcomes(outcomes: List<ActualOutcomeEntity>) {
        require(outcomes.isNotEmpty())
        db.withTransaction { outcomes.forEach { db.predictionDao().insertOutcome(it) } }
    }
}
