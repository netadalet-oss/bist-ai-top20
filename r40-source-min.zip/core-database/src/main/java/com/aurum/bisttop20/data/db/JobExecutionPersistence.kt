package com.aurum.bisttop20.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
import com.aurum.bisttop20.domain.jobs.*

@Dao
interface JobExecutionDao {
    @Query("SELECT * FROM job_executions ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<JobExecutionEntity>>

    @Query("SELECT * FROM job_executions WHERE jobId = :jobId LIMIT 1")
    suspend fun find(jobId: String): JobExecutionEntity?

    @Query("SELECT * FROM job_executions WHERE status IN ('QUEUED','RUNNING','PAUSED','FAILED')")
    suspend fun recoverable(): List<JobExecutionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(entity: JobExecutionEntity)
}

class RoomJobExecutionStore(private val dao: JobExecutionDao) {
    fun observeAll(): Flow<List<JobExecutionEntity>> = dao.observeAll()
    suspend fun read(jobId: String): JobSnapshot? = dao.find(jobId)?.asDomain()
    suspend fun save(snapshot: JobSnapshot) = dao.save(snapshot.asEntity())

    suspend fun applyCommand(jobId: String, command: JobCommand, now: Long): JobSnapshot {
        val current = requireNotNull(read(jobId)) { "JOB_NOT_FOUND:$jobId" }
        val decision = JobCommandPolicy.decide(current, command)
        require(decision.accepted && decision.targetStatus != null) { decision.reason }
        val target = decision.targetStatus
        val next = when (command) {
            JobCommand.RESTART -> current.copy(
                status = JobStatus.QUEUED, startedAt = null, endedAt = null, progress = 0.0,
                completedRecords = 0, failedRecords = 0, checkpoint = null, lastError = null,
                updatedAt = now
            )
            else -> JobStatePolicy.transition(current, target, now)
        }
        save(next)
        return next
    }

    suspend fun recoverAfterProcessDeath(now: Long): List<RecoveryDecision> = dao.recoverable().map { entity ->
        val decision = ProcessDeathRecovery.recover(entity.asDomain(), now)
        dao.save(decision.recoveredSnapshot.asEntity())
        decision
    }
}

fun JobExecutionEntity.asDomain(): JobSnapshot = JobSnapshot(
    jobId = jobId,
    module = JobModule.valueOf(module),
    status = JobStatus.valueOf(status),
    startedAt = startedAt,
    endedAt = endedAt,
    progress = progress,
    completedRecords = completedRecords,
    failedRecords = failedRecords,
    retryCount = retryCount,
    checkpoint = checkpointJson,
    lastError = lastError,
    totalRecords = totalRecords,
    resourceUsage = JobResourceUsage(cpuMillis, networkBytes, readBytes, writtenBytes, peakMemoryBytes),
    updatedAt = updatedAt
)

fun JobSnapshot.asEntity(): JobExecutionEntity = JobExecutionEntity(
    jobId = jobId, module = module.name, status = status.name, startedAt = startedAt, endedAt = endedAt,
    progress = progress, completedRecords = completedRecords, failedRecords = failedRecords,
    retryCount = retryCount, checkpointJson = checkpoint, lastError = lastError,
    totalRecords = totalRecords, remainingRecords = remainingRecords,
    cpuMillis = resourceUsage.cpuMillis, networkBytes = resourceUsage.networkBytes,
    readBytes = resourceUsage.readBytes, writtenBytes = resourceUsage.writtenBytes,
    peakMemoryBytes = resourceUsage.peakMemoryBytes, updatedAt = updatedAt
)
