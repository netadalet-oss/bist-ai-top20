package com.aurum.bisttop20.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName="universe_members", indices=[Index("universeVersion","instrumentId","effectiveFrom", unique=true), Index("symbol","effectiveFrom")])
data class UniverseMemberEntity(
    @PrimaryKey val membershipId: String,
    val universeVersion: String,
    val instrumentId: String,
    val symbol: String,
    val effectiveFrom: String,
    val effectiveToExclusive: String?,
    val market: String,
    val tradingMethod: String,
    val tradingStatus: String,
    val firstTradingDate: String?,
    val delistedDate: String?,
    val freeFloat: Double?,
    val liquidityBucket: String?,
    val sector: String?
)

@Entity(tableName="symbol_events", indices=[Index("instrumentId","effectiveDate"), Index("newSymbol","effectiveDate")])
data class SymbolEventEntity(
    @PrimaryKey val eventId: String,
    val instrumentId: String,
    val oldSymbol: String?,
    val newSymbol: String?,
    val eventType: String,
    val effectiveDate: String,
    val relatedInstrumentId: String?,
    val sourceId: String,
    val sourceHashSha256: String
)

@Entity(tableName="exchange_sessions")
data class ExchangeSessionEntity(
    @PrimaryKey val tradingDate: String,
    val isTradingDay: Boolean,
    val sessionType: String,
    val openEpochMillis: Long?,
    val closeEpochMillis: Long?,
    val sourceId: String,
    val sourceHashSha256: String
)

@Entity(tableName="market_holidays")
data class MarketHolidayEntity(
    @PrimaryKey val holidayDate: String,
    val holidayName: String,
    val sessionType: String,
    val sourceId: String,
    val sourceHashSha256: String
)
