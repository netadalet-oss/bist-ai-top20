package com.aurum.bisttop20.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface EventDao {
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertEvent(event:CanonicalEventEntity)
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertRevision(revision:EventRevisionEntity)
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertAiInterpretation(value:AiEventInterpretationEntity)
    @Query("SELECT * FROM canonical_events WHERE contentFingerprintSha256=:fingerprint LIMIT 1") suspend fun byFingerprint(fingerprint:String):CanonicalEventEntity?
    @Query("SELECT * FROM canonical_events WHERE eventId=:eventId LIMIT 1") suspend fun byId(eventId:String):CanonicalEventEntity?
    @Query("SELECT * FROM event_revisions WHERE rootEventId=:rootId ORDER BY revisionPublishedAt") suspend fun revisions(rootId:String):List<EventRevisionEntity>
    @Query("SELECT * FROM ai_event_interpretations WHERE eventId=:eventId ORDER BY requestedAt") suspend fun aiInterpretations(eventId:String):List<AiEventInterpretationEntity>

    @Transaction
    suspend fun insertRevisionChain(event:CanonicalEventEntity, revision:EventRevisionEntity) {
        insertEvent(event); insertRevision(revision)
    }
}
