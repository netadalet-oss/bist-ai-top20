package com.aurum.bisttop20.data.db

import androidx.room.withTransaction
import com.aurum.bisttop20.data.warehouse.LayerTransitionPolicy
import com.aurum.bisttop20.data.warehouse.WarehouseDecision
import com.aurum.bisttop20.data.warehouse.WarehouseIngressPolicy
import com.aurum.bisttop20.data.warehouse.WarehouseLayer
import com.aurum.bisttop20.data.warehouse.WarehouseRecord
import com.aurum.bisttop20.data.warehouse.WarehouseStamp
import java.security.MessageDigest

interface WarehouseRepository {
    suspend fun appendRaw(record: WarehouseRecord<String>)
    suspend fun transition(sourceId: String, target: WarehouseRecord<String>, reasonCode: String, actor: String, occurredAt: Long)
    suspend fun freezeFeatureSnapshot(snapshot: FeatureSnapshotEntity, inputs: List<WarehouseRecord<String>>, cutoff: Long)
}

class RoomWarehouseRepository(private val db: AurumDatabase) : WarehouseRepository {
    override suspend fun appendRaw(record: WarehouseRecord<String>) {
        require(record.layer == WarehouseLayer.RAW)
        require(WarehouseIngressPolicy.validate(record) is WarehouseDecision.Accept)
        db.withTransaction {
            require(db.warehouseDao().rawCountByDeduplicationKey(record.deduplicationKey) == 0) { "duplicate raw record" }
            db.warehouseDao().insertRecord(record.toEntity(frozen = true))
        }
    }

    override suspend fun transition(sourceId: String, target: WarehouseRecord<String>, reasonCode: String, actor: String, occurredAt: Long) {
        require(WarehouseIngressPolicy.validate(target) is WarehouseDecision.Accept)
        db.withTransaction {
            val source = requireNotNull(db.warehouseDao().record(sourceId)) { "source record not found" }
            val sourceLayer = WarehouseLayer.valueOf(source.layer)
            require(LayerTransitionPolicy.canMove(sourceLayer, target.layer)) { "illegal layer transition $sourceLayer -> ${target.layer}" }
            require(target.parentRecordId == sourceId) { "target must reference source as parent" }
            db.warehouseDao().insertRecord(target.toEntity(frozen = target.layer in setOf(WarehouseLayer.FEATURE, WarehouseLayer.PREDICTION, WarehouseLayer.OUTCOME, WarehouseLayer.ARCHIVE)))
            db.warehouseDao().insertTransition(WarehouseTransitionEntity(
                transitionId = sha256("$sourceId|${target.uniqueId}|$occurredAt|$reasonCode"),
                fromRecordId = sourceId,
                toRecordId = target.uniqueId,
                fromLayer = sourceLayer.name,
                toLayer = target.layer.name,
                reasonCode = reasonCode,
                actor = actor,
                occurredAt = occurredAt
            ))
        }
    }

    override suspend fun freezeFeatureSnapshot(snapshot: FeatureSnapshotEntity, inputs: List<WarehouseRecord<String>>, cutoff: Long) {
        require(snapshot.frozen)
        require(inputs.isNotEmpty())
        require(inputs.all { it.layer == WarehouseLayer.CANONICAL })
        require(inputs.all { WarehouseIngressPolicy.validate(it, cutoff) is WarehouseDecision.Accept })
        db.withTransaction {
            inputs.forEach { input -> requireNotNull(db.warehouseDao().record(input.uniqueId)) }
            db.warehouseDao().insertRecord(
                WarehouseRecordEntity(
                    uniqueId = snapshot.uniqueId,
                    layer = WarehouseLayer.FEATURE.name,
                    deduplicationKey = snapshot.deduplicationKey,
                    sourceId = snapshot.sourceId ?: "canonical-aggregate",
                    sourceHashSha256 = sha256(inputs.sortedBy { it.uniqueId }.joinToString("|") { it.stamp.sourceHashSha256 }),
                    effectiveTimestamp = snapshot.effectiveTimestamp ?: cutoff,
                    observedTimestamp = snapshot.observedTimestamp,
                    acquiredTimestamp = snapshot.acquiredTimestamp,
                    availableForPredictionTimestamp = snapshot.availableForPredictionTimestamp,
                    schemaVersion = snapshot.schemaVersion.toString(),
                    dataVersion = snapshot.dataVersion,
                    payloadJson = snapshot.valuesJson,
                    payloadHashSha256 = sha256(snapshot.valuesJson),
                    parentRecordId = null,
                    supersedesId = null,
                    frozen = true,
                    createdAt = snapshot.acquiredTimestamp
                )
            )
            db.warehouseDao().insertFeatureInputs(inputs.map {
                FeatureSnapshotInputEntity(snapshot.uniqueId, it.uniqueId, it.stamp.sourceHashSha256, it.stamp.availableForPredictionTimestamp)
            })
        }
    }
}

private fun WarehouseRecord<String>.toEntity(frozen: Boolean) = WarehouseRecordEntity(
    uniqueId = uniqueId,
    layer = layer.name,
    deduplicationKey = deduplicationKey,
    sourceId = stamp.sourceId,
    sourceHashSha256 = stamp.sourceHashSha256.lowercase(),
    effectiveTimestamp = stamp.effectiveTimestamp,
    observedTimestamp = stamp.observedTimestamp,
    acquiredTimestamp = stamp.acquiredTimestamp,
    availableForPredictionTimestamp = stamp.availableForPredictionTimestamp,
    schemaVersion = stamp.schemaVersion,
    dataVersion = stamp.dataVersion,
    payloadJson = payload,
    payloadHashSha256 = sha256(payload),
    parentRecordId = parentRecordId,
    supersedesId = supersedesId,
    frozen = frozen,
    createdAt = stamp.acquiredTimestamp
)

private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
    .digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
