package com.aurum.bisttop20.data.db

import androidx.sqlite.db.SupportSQLiteDatabase

object EventSqlGuards {
    fun install(db:SupportSQLiteDatabase) {
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS canonical_events_no_update BEFORE UPDATE ON canonical_events WHEN OLD.frozen=1 BEGIN SELECT RAISE(ABORT,'canonical event is append-only'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS canonical_events_no_delete BEFORE DELETE ON canonical_events BEGIN SELECT RAISE(ABORT,'canonical event cannot be deleted'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS ai_event_interpretations_no_update BEFORE UPDATE ON ai_event_interpretations BEGIN SELECT RAISE(ABORT,'AI interpretation is append-only'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS ai_event_interpretations_no_delete BEFORE DELETE ON ai_event_interpretations BEGIN SELECT RAISE(ABORT,'AI interpretation cannot be deleted'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS event_revision_parent_guard BEFORE INSERT ON event_revisions WHEN NOT EXISTS(SELECT 1 FROM canonical_events WHERE eventId=NEW.rootEventId) BEGIN SELECT RAISE(ABORT,'revision root event missing'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS ai_event_parent_guard BEFORE INSERT ON ai_event_interpretations WHEN NOT EXISTS(SELECT 1 FROM canonical_events WHERE eventId=NEW.eventId) BEGIN SELECT RAISE(ABORT,'AI interpretation event missing'); END""")
    }
}
