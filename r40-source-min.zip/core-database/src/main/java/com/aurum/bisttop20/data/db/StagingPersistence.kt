package com.aurum.bisttop20.data.db

import androidx.room.*

@Entity(tableName="staging_batches", indices=[Index(value=["module","state"]), Index(value=["publishToken"], unique=true)])
data class StagingBatchEntity(@PrimaryKey val batchId:String,val module:String,val createdAt:Long,val cutoffAt:Long,val state:String,val expectedRecordCount:Int,val validationHashSha256:String?,val publishToken:String?,val publishedAt:Long?)

@Entity(tableName="staging_records", primaryKeys=["batchId","recordId"], indices=[Index(value=["batchId","deduplicationKey"],unique=true)])
data class StagingRecordEntity(val batchId:String,val recordId:String,val deduplicationKey:String,val sourceId:String,val sourceHashSha256:String,val observedAt:Long,val acquiredAt:Long,val availableForPredictionAt:Long,val payloadJson:String,val payloadHashSha256:String,val qualityDecision:String)

@Entity(tableName="publish_receipts", indices=[Index(value=["publishToken"],unique=true)])
data class PublishReceiptEntity(@PrimaryKey val receiptId:String,val batchId:String,val publishToken:String,val publishedRecordCount:Int,val payloadSetHashSha256:String,val publishedAt:Long)

@Dao interface StagingDao {
 @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertBatch(value:StagingBatchEntity)
 @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertRecords(values:List<StagingRecordEntity>)
 @Transaction suspend fun insertBatchAndRecords(batch:StagingBatchEntity, records:List<StagingRecordEntity>) { insertBatch(batch); insertRecords(records) }
 @Query("SELECT * FROM staging_batches WHERE batchId=:batchId") suspend fun batch(batchId:String):StagingBatchEntity?
 @Query("SELECT * FROM staging_records WHERE batchId=:batchId ORDER BY deduplicationKey") suspend fun records(batchId:String):List<StagingRecordEntity>
 @Query("SELECT * FROM publish_receipts WHERE publishToken=:token") suspend fun receipt(token:String):PublishReceiptEntity?
 @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertReceipt(value:PublishReceiptEntity)
 @Query("UPDATE staging_batches SET state='VALIDATED', validationHashSha256=:hash WHERE batchId=:batchId AND state='OPEN'") suspend fun markValidated(batchId:String,hash:String):Int
 @Query("UPDATE staging_batches SET state='PUBLISHED', publishToken=:token, publishedAt=:publishedAt WHERE batchId=:batchId AND state='VALIDATED'") suspend fun markPublished(batchId:String,token:String,publishedAt:Long):Int
 @Transaction suspend fun publishWithReceipt(receipt:PublishReceiptEntity,batchId:String,token:String,publishedAt:Long) {
  insertReceipt(receipt)
  check(markPublished(batchId,token,publishedAt)==1) { "PUBLISH_STATE_TRANSITION_FAILED" }
 }
}
