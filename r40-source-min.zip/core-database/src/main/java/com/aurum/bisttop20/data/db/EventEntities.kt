package com.aurum.bisttop20.data.db

import androidx.room.Entity
import androidx.room.Index

@Entity(tableName="canonical_events", indices=[Index(value=["contentFingerprintSha256"], unique=true), Index(value=["kind","firstPublishedAt"]), Index(value=["symbol","firstPublishedAt"])], primaryKeys=["eventId"])
data class CanonicalEventEntity(
    val eventId:String,val kind:String,val instrumentId:String?,val symbol:String?,val eventType:String,val title:String?,val body:String,
    val firstPublishedAt:Long,val updatedAt:Long?,val referencePeriod:String?,val initiallyReportedValue:Double?,val revisedValue:Double?,
    val expectation:Double?,val surprise:Double?,val direction:String,val severity:Double?,val novelty:Double?,val pricedIn:Double?,
    val estimatedImpactMinutes:Long?,val contentFingerprintSha256:String,val sourceId:String,val sourceHashSha256:String,
    val observedAt:Long,val acquiredAt:Long,val revisionType:String,val parentEventId:String?,val attachmentHashesJson:String,val frozen:Boolean=true
)

@Entity(tableName="event_revisions", indices=[Index(value=["rootEventId","revisionPublishedAt"])], primaryKeys=["revisionId"])
data class EventRevisionEntity(
    val revisionId:String,val rootEventId:String,val eventId:String,val revisionType:String,val revisionPublishedAt:Long,
    val priorContentFingerprintSha256:String,val newContentFingerprintSha256:String,val reason:String?
)

@Entity(tableName="ai_event_interpretations", indices=[Index(value=["eventId","requestedAt"]),Index(value=["model","outputVersion"])], primaryKeys=["interpretationId"])
data class AiEventInterpretationEntity(
    val interpretationId:String,val eventId:String,val model:String,val requestedAt:Long,val inputCutoffAt:Long,val confidence:Double,
    val sourceIdsJson:String,val outputVersion:String,val structuredOutputJson:String,val tokenInput:Long?,val tokenOutput:Long?,val costMicros:Long?
)
