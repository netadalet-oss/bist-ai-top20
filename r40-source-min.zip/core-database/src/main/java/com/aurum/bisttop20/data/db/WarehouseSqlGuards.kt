package com.aurum.bisttop20.data.db

import androidx.sqlite.db.SupportSQLiteDatabase

object WarehouseSqlGuards {
    fun install(db: SupportSQLiteDatabase) {
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS warehouse_raw_no_update BEFORE UPDATE ON warehouse_records WHEN OLD.layer='RAW' BEGIN SELECT RAISE(ABORT, 'raw warehouse records are immutable'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS warehouse_raw_no_delete BEFORE DELETE ON warehouse_records WHEN OLD.layer='RAW' BEGIN SELECT RAISE(ABORT, 'raw warehouse records are immutable'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS warehouse_frozen_no_update BEFORE UPDATE ON warehouse_records WHEN OLD.frozen=1 BEGIN SELECT RAISE(ABORT, 'frozen warehouse records are immutable'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS warehouse_frozen_no_delete BEFORE DELETE ON warehouse_records WHEN OLD.frozen=1 BEGIN SELECT RAISE(ABORT, 'frozen warehouse records are immutable'); END""")
        db.execSQL("""CREATE TRIGGER IF NOT EXISTS warehouse_raw_no_supersede BEFORE INSERT ON warehouse_records WHEN NEW.layer='RAW' AND NEW.supersedesId IS NOT NULL BEGIN SELECT RAISE(ABORT, 'raw record cannot supersede'); END""")
    }
}
