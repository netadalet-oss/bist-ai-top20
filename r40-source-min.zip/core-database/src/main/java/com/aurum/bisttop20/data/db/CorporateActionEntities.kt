package com.aurum.bisttop20.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName="adjustment_versions", indices=[Index(value=["instrumentId","createdAt"])])
data class AdjustmentVersionEntity(
    @PrimaryKey val adjustmentVersion:String,
    val instrumentId:String,
    val actionSetHashSha256:String,
    val createdAt:Long,
    val status:String,
    val sourceSnapshotHashSha256:String
)

@Entity(tableName="adjusted_price_bars", indices=[Index(value=["rawBarId","adjustmentVersion"], unique=true), Index(value=["instrumentId","timestamp"])])
data class AdjustedPriceBarEntity(
    @PrimaryKey val adjustedBarId:String,
    val rawBarId:String,
    val instrumentId:String,
    val displaySymbol:String,
    val timestamp:Long,
    val open:Double,
    val high:Double,
    val low:Double,
    val close:Double,
    val volume:Double,
    val priceFactor:Double,
    val volumeFactor:Double,
    val adjustmentVersion:String,
    val appliedActionIdsJson:String,
    val frozen:Boolean=true
)

@Entity(tableName="corporate_action_impacts", indices=[Index(value=["actionId","createdAt"])])
data class CorporateActionImpactEntity(
    @PrimaryKey val impactId:String,
    val actionId:String,
    val adjustmentVersion:String,
    val affectedRawBarCount:Int,
    val affectedFeatureSnapshotCount:Int,
    val anomalyRecheckRequired:Boolean,
    val historicalPredictionsModified:Boolean,
    val createdAt:Long
)
