package com.aurum.bisttop20.data.db

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

object AurumMigrations {
    val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("""CREATE TABLE IF NOT EXISTS `warehouse_records` (`uniqueId` TEXT NOT NULL, `layer` TEXT NOT NULL, `deduplicationKey` TEXT NOT NULL, `sourceId` TEXT NOT NULL, `sourceHashSha256` TEXT NOT NULL, `effectiveTimestamp` INTEGER NOT NULL, `observedTimestamp` INTEGER NOT NULL, `acquiredTimestamp` INTEGER NOT NULL, `availableForPredictionTimestamp` INTEGER NOT NULL, `schemaVersion` TEXT NOT NULL, `dataVersion` TEXT NOT NULL, `payloadJson` TEXT NOT NULL, `payloadHashSha256` TEXT NOT NULL, `parentRecordId` TEXT, `supersedesId` TEXT, `frozen` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, PRIMARY KEY(`uniqueId`))""")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_warehouse_records_layer_deduplicationKey` ON `warehouse_records` (`layer`, `deduplicationKey`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_warehouse_records_availableForPredictionTimestamp` ON `warehouse_records` (`availableForPredictionTimestamp`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_warehouse_records_sourceId_sourceHashSha256` ON `warehouse_records` (`sourceId`, `sourceHashSha256`)")
            db.execSQL("""CREATE TABLE IF NOT EXISTS `warehouse_transitions` (`transitionId` TEXT NOT NULL, `fromRecordId` TEXT NOT NULL, `toRecordId` TEXT NOT NULL, `fromLayer` TEXT NOT NULL, `toLayer` TEXT NOT NULL, `reasonCode` TEXT NOT NULL, `actor` TEXT NOT NULL, `occurredAt` INTEGER NOT NULL, PRIMARY KEY(`transitionId`))""")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_warehouse_transitions_fromRecordId` ON `warehouse_transitions` (`fromRecordId`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_warehouse_transitions_toRecordId` ON `warehouse_transitions` (`toRecordId`)")
            db.execSQL("""CREATE TABLE IF NOT EXISTS `feature_snapshot_inputs` (`featureSnapshotId` TEXT NOT NULL, `warehouseRecordId` TEXT NOT NULL, `sourceHashSha256` TEXT NOT NULL, `availableForPredictionTimestamp` INTEGER NOT NULL, PRIMARY KEY(`featureSnapshotId`, `warehouseRecordId`))""")
            WarehouseSqlGuards.install(db)
        }
    }

    val MIGRATION_2_3 = object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("""CREATE TABLE IF NOT EXISTS `universe_members` (`membershipId` TEXT NOT NULL, `universeVersion` TEXT NOT NULL, `instrumentId` TEXT NOT NULL, `symbol` TEXT NOT NULL, `effectiveFrom` TEXT NOT NULL, `effectiveToExclusive` TEXT, `market` TEXT NOT NULL, `tradingMethod` TEXT NOT NULL, `tradingStatus` TEXT NOT NULL, `firstTradingDate` TEXT, `delistedDate` TEXT, `freeFloat` REAL, `liquidityBucket` TEXT, `sector` TEXT, PRIMARY KEY(`membershipId`))""")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_universe_members_universeVersion_instrumentId_effectiveFrom` ON `universe_members` (`universeVersion`,`instrumentId`,`effectiveFrom`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_universe_members_symbol_effectiveFrom` ON `universe_members` (`symbol`,`effectiveFrom`)")
            db.execSQL("""CREATE TABLE IF NOT EXISTS `symbol_events` (`eventId` TEXT NOT NULL, `instrumentId` TEXT NOT NULL, `oldSymbol` TEXT, `newSymbol` TEXT, `eventType` TEXT NOT NULL, `effectiveDate` TEXT NOT NULL, `relatedInstrumentId` TEXT, `sourceId` TEXT NOT NULL, `sourceHashSha256` TEXT NOT NULL, PRIMARY KEY(`eventId`))""")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_symbol_events_instrumentId_effectiveDate` ON `symbol_events` (`instrumentId`,`effectiveDate`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_symbol_events_newSymbol_effectiveDate` ON `symbol_events` (`newSymbol`,`effectiveDate`)")
            db.execSQL("""CREATE TABLE IF NOT EXISTS `exchange_sessions` (`tradingDate` TEXT NOT NULL, `isTradingDay` INTEGER NOT NULL, `sessionType` TEXT NOT NULL, `openEpochMillis` INTEGER, `closeEpochMillis` INTEGER, `sourceId` TEXT NOT NULL, `sourceHashSha256` TEXT NOT NULL, PRIMARY KEY(`tradingDate`))""")
            db.execSQL("""CREATE TABLE IF NOT EXISTS `market_holidays` (`holidayDate` TEXT NOT NULL, `holidayName` TEXT NOT NULL, `sessionType` TEXT NOT NULL, `sourceId` TEXT NOT NULL, `sourceHashSha256` TEXT NOT NULL, PRIMARY KEY(`holidayDate`))""")
        }
    }


    val MIGRATION_3_4 = object : Migration(3, 4) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("""CREATE TABLE IF NOT EXISTS `adjustment_versions` (`adjustmentVersion` TEXT NOT NULL, `instrumentId` TEXT NOT NULL, `actionSetHashSha256` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `status` TEXT NOT NULL, `sourceSnapshotHashSha256` TEXT NOT NULL, PRIMARY KEY(`adjustmentVersion`))""")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_adjustment_versions_instrumentId_createdAt` ON `adjustment_versions` (`instrumentId`,`createdAt`)")
            db.execSQL("""CREATE TABLE IF NOT EXISTS `adjusted_price_bars` (`adjustedBarId` TEXT NOT NULL, `rawBarId` TEXT NOT NULL, `instrumentId` TEXT NOT NULL, `displaySymbol` TEXT NOT NULL, `timestamp` INTEGER NOT NULL, `open` REAL NOT NULL, `high` REAL NOT NULL, `low` REAL NOT NULL, `close` REAL NOT NULL, `volume` REAL NOT NULL, `priceFactor` REAL NOT NULL, `volumeFactor` REAL NOT NULL, `adjustmentVersion` TEXT NOT NULL, `appliedActionIdsJson` TEXT NOT NULL, `frozen` INTEGER NOT NULL, PRIMARY KEY(`adjustedBarId`))""")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_adjusted_price_bars_rawBarId_adjustmentVersion` ON `adjusted_price_bars` (`rawBarId`,`adjustmentVersion`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_adjusted_price_bars_instrumentId_timestamp` ON `adjusted_price_bars` (`instrumentId`,`timestamp`)")
            db.execSQL("""CREATE TABLE IF NOT EXISTS `corporate_action_impacts` (`impactId` TEXT NOT NULL, `actionId` TEXT NOT NULL, `adjustmentVersion` TEXT NOT NULL, `affectedRawBarCount` INTEGER NOT NULL, `affectedFeatureSnapshotCount` INTEGER NOT NULL, `anomalyRecheckRequired` INTEGER NOT NULL, `historicalPredictionsModified` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, PRIMARY KEY(`impactId`))""")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_corporate_action_impacts_actionId_createdAt` ON `corporate_action_impacts` (`actionId`,`createdAt`)")
            CorporateActionSqlGuards.install(db)
        }
    }


    val MIGRATION_4_5 = object : Migration(4, 5) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("""CREATE TABLE IF NOT EXISTS `canonical_events` (`eventId` TEXT NOT NULL, `kind` TEXT NOT NULL, `instrumentId` TEXT, `symbol` TEXT, `eventType` TEXT NOT NULL, `title` TEXT, `body` TEXT NOT NULL, `firstPublishedAt` INTEGER NOT NULL, `updatedAt` INTEGER, `referencePeriod` TEXT, `initiallyReportedValue` REAL, `revisedValue` REAL, `expectation` REAL, `surprise` REAL, `direction` TEXT NOT NULL, `severity` REAL, `novelty` REAL, `pricedIn` REAL, `estimatedImpactMinutes` INTEGER, `contentFingerprintSha256` TEXT NOT NULL, `sourceId` TEXT NOT NULL, `sourceHashSha256` TEXT NOT NULL, `observedAt` INTEGER NOT NULL, `acquiredAt` INTEGER NOT NULL, `revisionType` TEXT NOT NULL, `parentEventId` TEXT, `attachmentHashesJson` TEXT NOT NULL, `frozen` INTEGER NOT NULL, PRIMARY KEY(`eventId`))""")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_canonical_events_contentFingerprintSha256` ON `canonical_events` (`contentFingerprintSha256`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_canonical_events_kind_firstPublishedAt` ON `canonical_events` (`kind`,`firstPublishedAt`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_canonical_events_symbol_firstPublishedAt` ON `canonical_events` (`symbol`,`firstPublishedAt`)")
            db.execSQL("""CREATE TABLE IF NOT EXISTS `event_revisions` (`revisionId` TEXT NOT NULL, `rootEventId` TEXT NOT NULL, `eventId` TEXT NOT NULL, `revisionType` TEXT NOT NULL, `revisionPublishedAt` INTEGER NOT NULL, `priorContentFingerprintSha256` TEXT NOT NULL, `newContentFingerprintSha256` TEXT NOT NULL, `reason` TEXT, PRIMARY KEY(`revisionId`))""")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_event_revisions_rootEventId_revisionPublishedAt` ON `event_revisions` (`rootEventId`,`revisionPublishedAt`)")
            db.execSQL("""CREATE TABLE IF NOT EXISTS `ai_event_interpretations` (`interpretationId` TEXT NOT NULL, `eventId` TEXT NOT NULL, `model` TEXT NOT NULL, `requestedAt` INTEGER NOT NULL, `inputCutoffAt` INTEGER NOT NULL, `confidence` REAL NOT NULL, `sourceIdsJson` TEXT NOT NULL, `outputVersion` TEXT NOT NULL, `structuredOutputJson` TEXT NOT NULL, `tokenInput` INTEGER, `tokenOutput` INTEGER, `costMicros` INTEGER, PRIMARY KEY(`interpretationId`))""")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_ai_event_interpretations_eventId_requestedAt` ON `ai_event_interpretations` (`eventId`,`requestedAt`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_ai_event_interpretations_model_outputVersion` ON `ai_event_interpretations` (`model`,`outputVersion`)")
            EventSqlGuards.install(db)
        }
    }


    val MIGRATION_5_6 = object : Migration(5, 6) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("""CREATE TABLE IF NOT EXISTS `risk_control_state` (`singletonId` INTEGER NOT NULL, `state` TEXT NOT NULL, `reason` TEXT NOT NULL, `updatedAt` INTEGER NOT NULL, `approvedBy` TEXT, PRIMARY KEY(`singletonId`))""")
            db.execSQL("""INSERT OR IGNORE INTO `risk_control_state` (`singletonId`,`state`,`reason`,`updatedAt`,`approvedBy`) VALUES (1,'PAUSED','INITIAL_SAFE_STATE',0,NULL)""")
        }
    }

    val MIGRATION_6_7 = object : Migration(6, 7) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE `job_executions` ADD COLUMN `totalRecords` INTEGER")
            db.execSQL("ALTER TABLE `job_executions` ADD COLUMN `remainingRecords` INTEGER")
            db.execSQL("ALTER TABLE `job_executions` ADD COLUMN `cpuMillis` INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE `job_executions` ADD COLUMN `networkBytes` INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE `job_executions` ADD COLUMN `readBytes` INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE `job_executions` ADD COLUMN `writtenBytes` INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE `job_executions` ADD COLUMN `peakMemoryBytes` INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE `job_executions` ADD COLUMN `updatedAt` INTEGER NOT NULL DEFAULT 0")
        }
    }


    val MIGRATION_7_8 = object : Migration(7, 8) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("""CREATE TABLE IF NOT EXISTS `staging_batches` (`batchId` TEXT NOT NULL, `module` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `cutoffAt` INTEGER NOT NULL, `state` TEXT NOT NULL, `expectedRecordCount` INTEGER NOT NULL, `validationHashSha256` TEXT, `publishToken` TEXT, `publishedAt` INTEGER, PRIMARY KEY(`batchId`))""")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_staging_batches_module_state` ON `staging_batches` (`module`,`state`)")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_staging_batches_publishToken` ON `staging_batches` (`publishToken`)")
            db.execSQL("""CREATE TABLE IF NOT EXISTS `staging_records` (`batchId` TEXT NOT NULL, `recordId` TEXT NOT NULL, `deduplicationKey` TEXT NOT NULL, `sourceId` TEXT NOT NULL, `sourceHashSha256` TEXT NOT NULL, `observedAt` INTEGER NOT NULL, `acquiredAt` INTEGER NOT NULL, `availableForPredictionAt` INTEGER NOT NULL, `payloadJson` TEXT NOT NULL, `payloadHashSha256` TEXT NOT NULL, `qualityDecision` TEXT NOT NULL, PRIMARY KEY(`batchId`,`recordId`))""")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_staging_records_batchId_deduplicationKey` ON `staging_records` (`batchId`,`deduplicationKey`)")
            db.execSQL("""CREATE TABLE IF NOT EXISTS `publish_receipts` (`receiptId` TEXT NOT NULL, `batchId` TEXT NOT NULL, `publishToken` TEXT NOT NULL, `publishedRecordCount` INTEGER NOT NULL, `payloadSetHashSha256` TEXT NOT NULL, `publishedAt` INTEGER NOT NULL, PRIMARY KEY(`receiptId`))""")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_publish_receipts_publishToken` ON `publish_receipts` (`publishToken`)")
        }
    }

    val ALL: Array<Migration> = arrayOf(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8)

    fun assertSupported(from: Int, to: Int) {
        require(from == to || ALL.any { it.startVersion == from && it.endVersion == to }) {
            "Missing Room migration $from->$to"
        }
    }
}
