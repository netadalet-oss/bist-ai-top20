plugins { alias(libs.plugins.android.library); alias(libs.plugins.kotlin.android); alias(libs.plugins.ksp) }
android { namespace="com.aurum.bisttop20.core.database"; compileSdk=35
 defaultConfig { minSdk=26; testInstrumentationRunner="androidx.test.runner.AndroidJUnitRunner" }
 compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget="17" }
}
dependencies { implementation(project(":domain-jobs")); implementation(project(":core-model")); implementation(project(":domain-risk")); implementation(project(":domain-staging")); implementation(project(":data-warehouse")); implementation(libs.room.runtime); implementation(libs.room.ktx); ksp(libs.room.compiler); testImplementation(libs.junit); androidTestImplementation(libs.androidx.junit) }
