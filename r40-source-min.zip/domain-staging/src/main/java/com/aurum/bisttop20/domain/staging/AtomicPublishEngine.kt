package com.aurum.bisttop20.domain.staging

import java.security.MessageDigest

class AtomicPublishEngine(
    private val store: BatchStore,
    private val riskGate: RiskPublishGate
) {
    fun validate(batch: StagingBatch): StagingBatch {
        require(batch.state == BatchState.OPEN) { "Only OPEN batch can be validated" }
        require(batch.expectedRecordCount == batch.records.size) { "PARTIAL_BATCH" }
        require(batch.records.isNotEmpty()) { "EMPTY_BATCH" }
        val duplicateIds = batch.records.groupBy { it.recordId }.filterValues { it.size > 1 }.keys
        require(duplicateIds.isEmpty()) { "DUPLICATE_RECORD_ID:${duplicateIds.first()}" }
        val duplicateKeys = batch.records.groupBy { it.deduplicationKey }.filterValues { it.size > 1 }.keys
        require(duplicateKeys.isEmpty()) { "DUPLICATE_DEDUP_KEY:${duplicateKeys.first()}" }
        batch.records.forEach {
            require(SHA256.matches(it.sourceHashSha256)) { "INVALID_SOURCE_HASH:${it.recordId}" }
            require(SHA256.matches(it.payloadHashSha256)) { "INVALID_PAYLOAD_HASH:${it.recordId}" }
            require(it.observedAt <= it.acquiredAt) { "TIME_ORDER:${it.recordId}" }
            require(it.acquiredAt <= it.availableForPredictionAt) { "TIME_ORDER:${it.recordId}" }
            require(it.availableForPredictionAt <= batch.cutoffAt) { "POINT_IN_TIME:${it.recordId}" }
            require(it.qualityDecision == QualityDecision.ACCEPT) { "QUALITY_GATE:${it.recordId}" }
        }
        return batch.copy(state = BatchState.VALIDATED, validationHashSha256 = payloadSetHash(batch.records)).also(store::save)
    }

    fun publish(batchId: String, publishToken: String, now: Long): PublishReceipt {
        require(publishToken.isNotBlank()) { "publishToken required" }
        store.existingReceipt(publishToken)?.let { return it.copy(idempotentReplay = true) }
        val batch = requireNotNull(store.load(batchId)) { "Batch not found" }
        require(batch.state == BatchState.VALIDATED) { "Batch is not validated" }
        riskGate.assertPublishAllowed(now)
        val currentHash = payloadSetHash(batch.records)
        require(currentHash == batch.validationHashSha256) { "STAGING_MUTATED_AFTER_VALIDATION" }
        val receipt = PublishReceipt(batch.batchId, publishToken, batch.records.size, currentHash, now, false)
        store.publishAtomically(batch.copy(state = BatchState.PUBLISHED, publishedAt = now), receipt)
        return receipt
    }

    private fun payloadSetHash(records: List<AdapterRecord>): String = sha256(
        records.sortedBy { it.deduplicationKey }
            .joinToString("|") { "${it.deduplicationKey}:${it.payloadHashSha256}" }
    )
    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
    private companion object { val SHA256 = Regex("^[0-9a-fA-F]{64}$") }
}
