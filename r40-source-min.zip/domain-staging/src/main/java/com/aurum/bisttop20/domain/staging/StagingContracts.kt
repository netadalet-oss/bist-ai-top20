package com.aurum.bisttop20.domain.staging

enum class BatchState { OPEN, VALIDATED, PUBLISHED, REJECTED, ABORTED }
enum class QualityDecision { ACCEPT, QUARANTINE, REJECT }

data class AdapterRecord(
    val recordId: String,
    val deduplicationKey: String,
    val sourceId: String,
    val sourceHashSha256: String,
    val observedAt: Long,
    val acquiredAt: Long,
    val availableForPredictionAt: Long,
    val payloadHashSha256: String,
    val payloadBase64: String = "",
    val qualityDecision: QualityDecision = QualityDecision.ACCEPT
)

data class StagingBatch(
    val batchId: String,
    val module: String,
    val createdAt: Long,
    val cutoffAt: Long,
    val state: BatchState,
    val expectedRecordCount: Int,
    val records: List<AdapterRecord>,
    val validationHashSha256: String? = null,
    val publishedAt: Long? = null
)

data class PublishReceipt(
    val batchId: String,
    val publishToken: String,
    val publishedRecordCount: Int,
    val payloadSetHashSha256: String,
    val publishedAt: Long,
    val idempotentReplay: Boolean
)

interface MarketDataAdapter {
    val adapterId: String
    fun fetch(cutoffAt: Long): List<AdapterRecord>
}

interface RiskPublishGate { fun assertPublishAllowed(at: Long) }
interface BatchStore {
    fun load(batchId: String): StagingBatch?
    fun save(batch: StagingBatch)
    fun existingReceipt(publishToken: String): PublishReceipt?
    fun publishAtomically(batch: StagingBatch, receipt: PublishReceipt)
}
