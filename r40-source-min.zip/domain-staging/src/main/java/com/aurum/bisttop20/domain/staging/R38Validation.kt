package com.aurum.bisttop20.domain.staging

private class MemStore : BatchStore {
    val batches = mutableMapOf<String, StagingBatch>()
    val receipts = mutableMapOf<String, PublishReceipt>()
    val live = mutableListOf<AdapterRecord>()
    override fun load(batchId: String)=batches[batchId]
    override fun save(batch: StagingBatch){ batches[batch.batchId]=batch }
    override fun existingReceipt(publishToken: String)=receipts[publishToken]
    override fun publishAtomically(batch: StagingBatch, receipt: PublishReceipt) {
        check(batches[batch.batchId]?.state == BatchState.VALIDATED)
        live.addAll(batch.records); batches[batch.batchId]=batch; receipts[receipt.publishToken]=receipt
    }
}
fun main(){
    val h="a".repeat(64); val store=MemStore(); var allowed=true
    val engine=AtomicPublishEngine(store, object:RiskPublishGate{override fun assertPublishAllowed(at:Long){check(allowed)}})
    val records=listOf(AdapterRecord("r1","k1","src",h,1,2,3,h),AdapterRecord("r2","k2","src",h,1,2,3,h))
    store.save(StagingBatch("b1","PRICE",0,10,BatchState.OPEN,2,records))
    engine.validate(store.load("b1")!!)
    val first=engine.publish("b1","token-1",11); check(first.publishedRecordCount==2 && store.live.size==2)
    val replay=engine.publish("b1","token-1",12); check(replay.idempotentReplay && store.live.size==2)
    store.save(StagingBatch("b2","PRICE",0,10,BatchState.OPEN,3,records))
    check(runCatching{engine.validate(store.load("b2")!!)}.isFailure)
    store.save(StagingBatch("b3","PRICE",0,10,BatchState.OPEN,2,records))
    engine.validate(store.load("b3")!!); allowed=false
    check(runCatching{engine.publish("b3","token-3",12)}.isFailure && store.live.size==2)
    println("R38_ATOMIC_STAGING_PASS")
}
