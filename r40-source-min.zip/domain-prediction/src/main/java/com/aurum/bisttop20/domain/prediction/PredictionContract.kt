package com.aurum.bisttop20.domain.prediction

data class PredictionRunContract(
    val runId: String,
    val decisionTimestamp: Long,
    val dataCutoffTimestamp: Long,
    val targetStartTimestamp: Long,
    val targetEndTimestamp: Long,
    val dataSnapshotHash: String,
    val modelVersion: String,
    val featureVersion: String,
    val universeVersion: String,
)

data class PredictionCandidateContract(
    val symbol: String,
    val predictedRank: Int,
    val probability: Double?,
    val expectedNetReturn: Double?,
    val uncertainty: Double?,
    val dataQualityScore: Double?,
)

data class PredictionContractResult(val valid: Boolean, val violations: List<String>)

object PredictionContractValidator {
    fun validate(run: PredictionRunContract, candidates: List<PredictionCandidateContract>): PredictionContractResult {
        val violations = buildList {
            if (run.runId.isBlank()) add("runId is required")
            if (run.dataCutoffTimestamp > run.decisionTimestamp) add("data cutoff is after decision time")
            if (run.targetStartTimestamp < run.decisionTimestamp) add("target starts before decision time")
            if (run.targetEndTimestamp <= run.targetStartTimestamp) add("target window is invalid")
            if (!run.dataSnapshotHash.matches(Regex("[a-fA-F0-9]{64}"))) add("data snapshot SHA-256 is required")
            if (run.modelVersion.isBlank() || run.featureVersion.isBlank() || run.universeVersion.isBlank()) add("version fields are required")
            if (candidates.isEmpty()) add("at least one candidate is required")
            if (candidates.map { it.symbol }.distinct().size != candidates.size) add("candidate symbols must be unique")
            if (candidates.map { it.predictedRank }.sorted() != (1..candidates.size).toList()) add("ranks must be contiguous from 1")
            candidates.forEach { item ->
                if (!item.symbol.matches(Regex("[A-Z0-9]{2,12}"))) add("invalid symbol: ${item.symbol}")
                item.probability?.let { if (it !in 0.0..1.0) add("probability out of range for ${item.symbol}") }
                item.uncertainty?.let { if (it !in 0.0..1.0) add("uncertainty out of range for ${item.symbol}") }
                item.dataQualityScore?.let { if (it !in 0.0..1.0) add("data quality score out of range for ${item.symbol}") }
            }
        }
        return PredictionContractResult(violations.isEmpty(), violations)
    }
}
