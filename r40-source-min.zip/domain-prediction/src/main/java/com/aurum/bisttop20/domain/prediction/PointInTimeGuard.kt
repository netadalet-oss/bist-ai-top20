package com.aurum.bisttop20.domain.prediction

/** Pure-domain leakage guard; usable in Android and model-training validation. */
data class TimedFeature(
    val name: String,
    val observedTimestamp: Long,
    val acquiredTimestamp: Long,
    val availableForPredictionTimestamp: Long,
    val sourceHash: String
)

data class PredictionCutoff(
    val decisionTimestamp: Long,
    val dataCutoffTimestamp: Long
)

sealed interface PointInTimeResult {
    data object Valid : PointInTimeResult
    data class Invalid(val violations: List<String>) : PointInTimeResult
}

object PointInTimeGuard {
    fun validate(cutoff: PredictionCutoff, features: List<TimedFeature>): PointInTimeResult {
        val violations = buildList {
            if (cutoff.dataCutoffTimestamp > cutoff.decisionTimestamp) {
                add("data_cutoff_after_decision")
            }
            features.forEach { feature ->
                if (feature.availableForPredictionTimestamp > cutoff.dataCutoffTimestamp) {
                    add("${feature.name}:available_after_cutoff")
                }
                if (feature.acquiredTimestamp > cutoff.dataCutoffTimestamp) {
                    add("${feature.name}:acquired_after_cutoff")
                }
                if (feature.sourceHash.isBlank()) {
                    add("${feature.name}:missing_source_hash")
                }
            }
        }
        return if (violations.isEmpty()) PointInTimeResult.Valid else PointInTimeResult.Invalid(violations)
    }
}
