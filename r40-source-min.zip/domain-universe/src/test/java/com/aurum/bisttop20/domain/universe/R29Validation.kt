package com.aurum.bisttop20.domain.universe

fun main() {
    val members = listOf(
        UniverseMember("u1","i1","OLD","2025-01-01","2025-06-01","STAR","CONTINUOUS","OPEN","2025-01-01",null,0.3,"L2","BANK"),
        UniverseMember("u1","i1","NEW","2025-06-01",null,"STAR","CONTINUOUS","OPEN","2025-01-01",null,0.3,"L2","BANK"),
        UniverseMember("u1","i2","DEL","2025-01-01",null,"MAIN","CONTINUOUS","OPEN","2025-01-01","2025-04-01",0.2,"L3","IND")
    )
    val version = UniverseVersion("u1","2025-01-01",UniverseHash.sha256(members),members)
    check(version.definitionHashSha256.length == 64)
    val full = ExchangeSession("2025-06-02",true,SessionType.FULL_DAY,1,2,"official","a".repeat(64))
    val replay = UniverseReplayRunner().replay("2025-06-02",version,full)
    check(replay.map { it.symbol } == listOf("NEW"))

    val gate = TradingDayGate()
    val pass = gate.evaluate(full, DailySnapshotStatus("2025-06-02",true,true,1,1,true,false))
    check(pass.accepted)
    val fail = gate.evaluate(full, DailySnapshotStatus("2025-06-02",false,false,2,1,false,true))
    check(!fail.accepted && fail.reasons.containsAll(setOf("SESSION_NOT_COMPLETED","CLOSE_DATA_MISSING","INCOMPLETE_SYMBOL_COVERAGE","QUALITY_GATE_FAILED","DUPLICATE_SNAPSHOT")))

    val labels = TSeriesViewGenerator().generate(listOf(
        TSeriesViewGenerator.DatedValue("2025-06-02",10.0),
        TSeriesViewGenerator.DatedValue("2025-05-30",9.0),
        TSeriesViewGenerator.DatedValue("2025-05-30",999.0)
    ))
    check(labels.map { it.label } == listOf("T0","T1"))
    check(labels[1].tradingDate == "2025-05-30")
    println("R29_UNIVERSE_CALENDAR_PASS")
}
