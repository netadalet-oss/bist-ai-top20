package com.aurum.bisttop20.domain.universe

import java.security.MessageDigest

object UniverseHash {
    fun sha256(members: List<UniverseMember>): String {
        val canonical = members.sortedWith(compareBy<UniverseMember> { it.instrumentId }.thenBy { it.effectiveFrom })
            .joinToString("\n") { listOf(it.instrumentId,it.symbol,it.effectiveFrom,it.effectiveToExclusive.orEmpty(),it.market,it.tradingMethod,it.tradingStatus).joinToString("|") }
        return MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}
