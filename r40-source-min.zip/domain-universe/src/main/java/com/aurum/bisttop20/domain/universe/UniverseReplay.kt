package com.aurum.bisttop20.domain.universe

class UniverseReplayRunner {
    fun replay(date: String, version: UniverseVersion, session: ExchangeSession): List<UniverseMember> {
        require(session.tradingDate == date) { "Session date mismatch" }
        require(session.isTradingDay && session.sessionType != SessionType.HOLIDAY && session.sessionType != SessionType.EXTRAORDINARY_CLOSED) {
            "Cannot replay a closed exchange date"
        }
        require(version.effectiveDate <= date) { "Universe version is from the future" }
        return version.members
            .asSequence()
            .filter { it.isTradableOn(date) }
            .distinctBy { it.instrumentId }
            .sortedBy { it.symbol }
            .toList()
    }
}

class TradingDayGate {
    fun evaluate(session: ExchangeSession?, status: DailySnapshotStatus): RolloverDecision {
        val reasons = linkedSetOf<String>()
        if (session == null || !session.isTradingDay) reasons += "NOT_OFFICIAL_TRADING_DAY"
        if (session?.sessionType == SessionType.HOLIDAY || session?.sessionType == SessionType.EXTRAORDINARY_CLOSED) reasons += "SESSION_CLOSED"
        if (!status.sessionCompleted) reasons += "SESSION_NOT_COMPLETED"
        if (!status.closeDataReceived) reasons += "CLOSE_DATA_MISSING"
        if (status.completedSymbolCount < status.requiredSymbolCount) reasons += "INCOMPLETE_SYMBOL_COVERAGE"
        if (!status.qualityPassed) reasons += "QUALITY_GATE_FAILED"
        if (status.alreadyWritten) reasons += "DUPLICATE_SNAPSHOT"
        return RolloverDecision(reasons.isEmpty(), reasons)
    }
}

class TSeriesViewGenerator {
    data class DatedValue(val tradingDate: String, val value: Double?)
    data class LabeledValue(val label: String, val tradingDate: String, val value: Double?)

    fun generate(descendingTradingDates: List<DatedValue>, maxDepth: Int = 90): List<LabeledValue> {
        require(maxDepth in 0..90)
        return descendingTradingDates
            .distinctBy { it.tradingDate }
            .sortedByDescending { it.tradingDate }
            .take(maxDepth + 1)
            .mapIndexed { index, item -> LabeledValue("T$index", item.tradingDate, item.value) }
    }
}
