package com.aurum.bisttop20.domain.universe

data class ExchangeSession(
    val tradingDate: String,
    val isTradingDay: Boolean,
    val sessionType: SessionType,
    val openEpochMillis: Long?,
    val closeEpochMillis: Long?,
    val sourceId: String,
    val sourceHashSha256: String
)

enum class SessionType { FULL_DAY, HALF_DAY, HOLIDAY, EXTRAORDINARY_CLOSED }

data class SymbolEvent(
    val eventId: String,
    val instrumentId: String,
    val oldSymbol: String?,
    val newSymbol: String?,
    val eventType: SymbolEventType,
    val effectiveDate: String,
    val relatedInstrumentId: String? = null
)

enum class SymbolEventType { SYMBOL_CHANGE, MERGER, SPLIT, ACQUISITION, LISTING, DELISTING }

data class UniverseMember(
    val universeVersion: String,
    val instrumentId: String,
    val symbol: String,
    val effectiveFrom: String,
    val effectiveToExclusive: String?,
    val market: String,
    val tradingMethod: String,
    val tradingStatus: String,
    val firstTradingDate: String?,
    val delistedDate: String?,
    val freeFloat: Double?,
    val liquidityBucket: String?,
    val sector: String?
) {
    fun isEffectiveOn(date: String): Boolean =
        date >= effectiveFrom && (effectiveToExclusive == null || date < effectiveToExclusive)

    fun isTradableOn(date: String): Boolean = isEffectiveOn(date) &&
        tradingStatus == "OPEN" &&
        (firstTradingDate == null || date >= firstTradingDate) &&
        (delistedDate == null || date < delistedDate)
}

data class UniverseVersion(
    val id: String,
    val effectiveDate: String,
    val definitionHashSha256: String,
    val members: List<UniverseMember>
)

data class DailySnapshotStatus(
    val tradingDate: String,
    val sessionCompleted: Boolean,
    val closeDataReceived: Boolean,
    val requiredSymbolCount: Int,
    val completedSymbolCount: Int,
    val qualityPassed: Boolean,
    val alreadyWritten: Boolean
)

data class RolloverDecision(val accepted: Boolean, val reasons: Set<String>)
