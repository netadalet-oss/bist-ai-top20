package com.aurum.bisttop20.domain.jobs

enum class JobCommand { START, PAUSE, RESUME, CANCEL, RETRY, RESTART }

data class JobCommandDecision(
    val accepted: Boolean,
    val targetStatus: JobStatus?,
    val reason: String
)

object JobCommandPolicy {
    fun decide(snapshot: JobSnapshot, command: JobCommand): JobCommandDecision = when (command) {
        JobCommand.START -> when (snapshot.status) {
            JobStatus.QUEUED -> JobCommandDecision(true, JobStatus.RUNNING, "START_ALLOWED")
            else -> JobCommandDecision(false, null, "START_REQUIRES_QUEUED")
        }
        JobCommand.PAUSE -> when (snapshot.status) {
            JobStatus.RUNNING -> JobCommandDecision(true, JobStatus.PAUSED, "PAUSE_ALLOWED")
            else -> JobCommandDecision(false, null, "PAUSE_REQUIRES_RUNNING")
        }
        JobCommand.RESUME -> when (snapshot.status) {
            JobStatus.PAUSED -> JobCommandDecision(true, JobStatus.RUNNING, "RESUME_ALLOWED")
            else -> JobCommandDecision(false, null, "RESUME_REQUIRES_PAUSED")
        }
        JobCommand.CANCEL -> when (snapshot.status) {
            JobStatus.QUEUED, JobStatus.RUNNING, JobStatus.PAUSED, JobStatus.FAILED ->
                JobCommandDecision(true, JobStatus.CANCELLED, "CANCEL_ALLOWED")
            else -> JobCommandDecision(false, null, "CANCEL_NOT_ALLOWED_FOR_TERMINAL")
        }
        JobCommand.RETRY -> when (snapshot.status) {
            JobStatus.FAILED -> JobCommandDecision(true, JobStatus.QUEUED, "RETRY_ALLOWED")
            else -> JobCommandDecision(false, null, "RETRY_REQUIRES_FAILED")
        }
        JobCommand.RESTART -> when (snapshot.status) {
            JobStatus.FAILED -> JobCommandDecision(true, JobStatus.QUEUED, "RESTART_ALLOWED")
            else -> JobCommandDecision(false, null, "RESTART_REQUIRES_FAILED")
        }
    }
}

data class JobResourceUsage(
    val cpuMillis: Long = 0,
    val networkBytes: Long = 0,
    val readBytes: Long = 0,
    val writtenBytes: Long = 0,
    val peakMemoryBytes: Long = 0
) {
    init {
        require(cpuMillis >= 0)
        require(networkBytes >= 0)
        require(readBytes >= 0)
        require(writtenBytes >= 0)
        require(peakMemoryBytes >= 0)
    }
}

data class JobWorkEstimate(
    val totalRecords: Long?,
    val completedRecords: Long,
    val failedRecords: Long
) {
    init {
        require(totalRecords == null || totalRecords >= 0)
        require(completedRecords >= 0)
        require(failedRecords >= 0)
    }
    val remainingRecords: Long?
        get() = totalRecords?.let { (it - completedRecords - failedRecords).coerceAtLeast(0) }
}
