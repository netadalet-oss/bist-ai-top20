package com.aurum.bisttop20.domain.jobs

object ProcessDeathRecovery {
    fun recover(snapshot: JobSnapshot, now: Long): RecoveryDecision = when (snapshot.status) {
        JobStatus.RUNNING -> {
            if (!snapshot.checkpoint.isNullOrBlank()) {
                RecoveryDecision(
                    RecoveryAction.RESUME_FROM_CHECKPOINT,
                    "PROCESS_DEATH_WITH_CHECKPOINT",
                    snapshot.copy(status = JobStatus.PAUSED, updatedAt = now, lastError = "PROCESS_DEATH_RECOVERY")
                )
            } else {
                RecoveryDecision(
                    RecoveryAction.RESTART_FROM_SCRATCH,
                    "PROCESS_DEATH_WITHOUT_CHECKPOINT",
                    snapshot.copy(status = JobStatus.FAILED, endedAt = now, updatedAt = now, lastError = "PROCESS_DEATH_NO_CHECKPOINT")
                )
            }
        }
        JobStatus.QUEUED, JobStatus.PAUSED, JobStatus.FAILED -> RecoveryDecision(
            if (snapshot.checkpoint.isNullOrBlank()) RecoveryAction.RESTART_FROM_SCRATCH else RecoveryAction.RESUME_FROM_CHECKPOINT,
            "RECOVERABLE_NON_TERMINAL",
            snapshot.copy(updatedAt = now)
        )
        JobStatus.CANCELLED, JobStatus.COMPLETED -> RecoveryDecision(
            RecoveryAction.KEEP_TERMINAL,
            "TERMINAL_STATE_PRESERVED",
            snapshot.copy(updatedAt = now)
        )
    }
}
