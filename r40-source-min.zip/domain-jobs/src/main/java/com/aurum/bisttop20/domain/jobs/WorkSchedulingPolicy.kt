package com.aurum.bisttop20.domain.jobs

enum class ExistingWorkRule { KEEP, REPLACE, APPEND_OR_REPLACE }

data class WorkScheduleSpec(
    val uniqueName: String,
    val module: JobModule,
    val existingWorkRule: ExistingWorkRule,
    val requiresNetwork: Boolean,
    val requiresBatteryNotLow: Boolean,
    val periodicIntervalMinutes: Long? = null
) {
    init {
        require(uniqueName.isNotBlank())
        require(periodicIntervalMinutes == null || periodicIntervalMinutes >= 15) {
            "WORKMANAGER_PERIODIC_MINIMUM_15_MINUTES"
        }
    }
}

object WorkSchedulingPolicy {
    fun defaultFor(module: JobModule): WorkScheduleSpec {
        val network = module in setOf(
            JobModule.PRICE_COLLECTION, JobModule.VOLUME_COLLECTION,
            JobModule.ORDER_BOOK_COLLECTION, JobModule.KAP_SCAN,
            JobModule.NEWS_SCAN, JobModule.MACRO_COLLECTION
        )
        val replaceable = module in setOf(
            JobModule.PRICE_COLLECTION, JobModule.VOLUME_COLLECTION,
            JobModule.ORDER_BOOK_COLLECTION, JobModule.FINAL_RANKER,
            JobModule.PERFORMANCE_EVALUATION
        )
        return WorkScheduleSpec(
            uniqueName = "aurum.${module.name.lowercase()}",
            module = module,
            existingWorkRule = if (replaceable) ExistingWorkRule.REPLACE else ExistingWorkRule.KEEP,
            requiresNetwork = network,
            requiresBatteryNotLow = module in setOf(JobModule.BACKTEST, JobModule.CHALLENGER_TRAINING),
            periodicIntervalMinutes = null
        )
    }

    fun validateUnique(specs: List<WorkScheduleSpec>) {
        require(specs.map { it.uniqueName }.distinct().size == specs.size) { "DUPLICATE_UNIQUE_WORK_NAME" }
    }
}
