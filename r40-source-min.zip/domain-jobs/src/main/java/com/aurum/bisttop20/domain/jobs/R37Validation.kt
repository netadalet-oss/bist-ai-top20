package com.aurum.bisttop20.domain.jobs

fun main() {
    val base = JobSnapshot("job-1", JobModule.PRICE_COLLECTION, JobStatus.RUNNING, startedAt = 1, updatedAt = 1)
    check(JobCommandPolicy.decide(base, JobCommand.PAUSE).accepted)
    check(!JobCommandPolicy.decide(base, JobCommand.RETRY).accepted)
    val failed = base.copy(status = JobStatus.FAILED, endedAt = 10, updatedAt = 10)
    check(JobCommandPolicy.decide(failed, JobCommand.RETRY).targetStatus == JobStatus.QUEUED)
    check(JobWorkEstimate(100, 72, 3).remainingRecords == 25L)
    check(JobWorkEstimate(null, 72, 3).remainingRecords == null)
    val specs = JobModule.values().map(WorkSchedulingPolicy::defaultFor)
    WorkSchedulingPolicy.validateUnique(specs)
    check(specs.first { it.module == JobModule.PRICE_COLLECTION }.existingWorkRule == ExistingWorkRule.REPLACE)
    check(specs.first { it.module == JobModule.KAP_SCAN }.requiresNetwork)
    runCatching { WorkScheduleSpec("x", JobModule.REPORTING, ExistingWorkRule.KEEP, false, false, 10) }
        .onSuccess { error("INVALID_PERIOD_ACCEPTED") }
    println("R37_JOB_CONTROL_SCHEDULING_PASS")
}
