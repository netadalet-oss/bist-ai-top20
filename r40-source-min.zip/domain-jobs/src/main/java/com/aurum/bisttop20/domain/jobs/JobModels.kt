package com.aurum.bisttop20.domain.jobs

enum class JobStatus { QUEUED, RUNNING, PAUSED, CANCELLED, FAILED, COMPLETED }

enum class JobModule {
    PRICE_COLLECTION, VOLUME_COLLECTION, ORDER_BOOK_COLLECTION,
    KAP_SCAN, NEWS_SCAN, MACRO_COLLECTION, DATA_QUALITY,
    CORPORATE_ACTIONS, FEATURE_COMPUTATION, STOCK_DNA,
    MARKET_REGIME, SUB_MODELS, FINAL_RANKER, PORTFOLIO_RISK,
    BACKTEST, PAPER_TRADING, CHALLENGER_TRAINING,
    PERFORMANCE_EVALUATION, DRIFT_CHECK, REPORTING
}

data class JobSnapshot(
    val jobId: String,
    val module: JobModule,
    val status: JobStatus,
    val startedAt: Long? = null,
    val endedAt: Long? = null,
    val progress: Double = 0.0,
    val completedRecords: Long = 0,
    val failedRecords: Long = 0,
    val retryCount: Int = 0,
    val checkpoint: String? = null,
    val lastError: String? = null,
    val totalRecords: Long? = null,
    val resourceUsage: JobResourceUsage = JobResourceUsage(),
    val updatedAt: Long
) {
    init {
        require(jobId.isNotBlank())
        require(progress in 0.0..1.0)
        require(completedRecords >= 0 && failedRecords >= 0 && retryCount >= 0)
        require(totalRecords == null || totalRecords >= completedRecords + failedRecords)
        require(endedAt == null || startedAt == null || endedAt >= startedAt)
    }
    val remainingRecords: Long?
        get() = totalRecords?.let { (it - completedRecords - failedRecords).coerceAtLeast(0) }
}

data class RecoveryDecision(
    val action: RecoveryAction,
    val reason: String,
    val recoveredSnapshot: JobSnapshot
)

enum class RecoveryAction { RESUME_FROM_CHECKPOINT, RESTART_FROM_SCRATCH, KEEP_TERMINAL }
