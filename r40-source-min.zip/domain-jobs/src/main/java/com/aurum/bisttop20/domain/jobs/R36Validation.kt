package com.aurum.bisttop20.domain.jobs

object R36Validation {
    @JvmStatic fun main(args: Array<String>) {
        val q = JobSnapshot("j1", JobModule.PRICE_COLLECTION, JobStatus.QUEUED, updatedAt = 1)
        val r = JobStatePolicy.transition(q, JobStatus.RUNNING, 2)
        val c = JobStatePolicy.checkpoint(r, "symbol=AKBNK", 10, 1, 0.25, 3)
        val paused = ProcessDeathRecovery.recover(c, 4)
        check(paused.action == RecoveryAction.RESUME_FROM_CHECKPOINT)
        check(paused.recoveredSnapshot.status == JobStatus.PAUSED)
        val failed = ProcessDeathRecovery.recover(r, 4)
        check(failed.action == RecoveryAction.RESTART_FROM_SCRATCH)
        check(failed.recoveredSnapshot.status == JobStatus.FAILED)
        val done = JobStatePolicy.transition(c, JobStatus.COMPLETED, 5)
        check(done.progress == 1.0)
        check(ProcessDeathRecovery.recover(done, 6).action == RecoveryAction.KEEP_TERMINAL)
        println("R36_JOB_RECOVERY_PASS")
    }
}
