package com.aurum.bisttop20.domain.jobs

object JobStatePolicy {
    private val transitions = mapOf(
        JobStatus.QUEUED to setOf(JobStatus.RUNNING, JobStatus.CANCELLED),
        JobStatus.RUNNING to setOf(JobStatus.PAUSED, JobStatus.CANCELLED, JobStatus.FAILED, JobStatus.COMPLETED),
        JobStatus.PAUSED to setOf(JobStatus.RUNNING, JobStatus.CANCELLED),
        JobStatus.FAILED to setOf(JobStatus.QUEUED, JobStatus.CANCELLED),
        JobStatus.CANCELLED to emptySet(),
        JobStatus.COMPLETED to emptySet()
    )

    fun transition(current: JobSnapshot, target: JobStatus, now: Long, error: String? = null): JobSnapshot {
        require(target in transitions.getValue(current.status)) { "INVALID_JOB_TRANSITION:${current.status}:$target" }
        return current.copy(
            status = target,
            startedAt = if (target == JobStatus.RUNNING) current.startedAt ?: now else current.startedAt,
            endedAt = if (target in setOf(JobStatus.CANCELLED, JobStatus.FAILED, JobStatus.COMPLETED)) now else null,
            progress = if (target == JobStatus.COMPLETED) 1.0 else current.progress,
            retryCount = if (current.status == JobStatus.FAILED && target == JobStatus.QUEUED) current.retryCount + 1 else current.retryCount,
            lastError = error ?: if (target == JobStatus.RUNNING) null else current.lastError,
            updatedAt = now
        )
    }

    fun checkpoint(current: JobSnapshot, value: String, completed: Long, failed: Long, progress: Double, now: Long): JobSnapshot {
        require(current.status == JobStatus.RUNNING) { "CHECKPOINT_REQUIRES_RUNNING" }
        require(value.isNotBlank()) { "CHECKPOINT_REQUIRED" }
        require(completed >= current.completedRecords) { "COMPLETED_RECORDS_REGRESSION" }
        require(failed >= current.failedRecords) { "FAILED_RECORDS_REGRESSION" }
        require(progress + 1e-12 >= current.progress) { "PROGRESS_REGRESSION" }
        return current.copy(
            checkpoint = value,
            completedRecords = completed,
            failedRecords = failed,
            progress = progress.coerceIn(0.0, 1.0),
            updatedAt = now
        )
    }

    fun telemetry(
        current: JobSnapshot,
        totalRecords: Long? = current.totalRecords,
        usage: JobResourceUsage,
        now: Long
    ): JobSnapshot {
        require(totalRecords == null || totalRecords >= current.completedRecords + current.failedRecords) {
            "TOTAL_RECORDS_BELOW_PROCESSED"
        }
        require(usage.cpuMillis >= current.resourceUsage.cpuMillis) { "CPU_USAGE_REGRESSION" }
        require(usage.networkBytes >= current.resourceUsage.networkBytes) { "NETWORK_USAGE_REGRESSION" }
        require(usage.readBytes >= current.resourceUsage.readBytes) { "READ_USAGE_REGRESSION" }
        require(usage.writtenBytes >= current.resourceUsage.writtenBytes) { "WRITE_USAGE_REGRESSION" }
        return current.copy(totalRecords = totalRecords, resourceUsage = usage, updatedAt = now)
    }
}
