package com.aurum.bisttop20.data.warehouse

private fun stamp(t: Long = 10) = WarehouseStamp(t, t + 1, t + 2, t + 3, "SRC", "a".repeat(64), "1", "1")
private fun rec(id: String, layer: WarehouseLayer, parent: String? = null, t: Long = 10) = WarehouseRecord(id, layer, "dedup-$id", stamp(t), "{\"id\":\"$id\"}", parentRecordId = parent)

fun main() {
    val w = InMemoryWarehouse()
    val raw = rec("raw-1", WarehouseLayer.RAW)
    w.appendRaw(raw)
    check(runCatching { w.replace(raw.copy(payload = "changed")) }.isFailure)
    check(runCatching { w.delete(raw.uniqueId) }.isFailure)
    check(runCatching { w.appendRaw(raw.copy(uniqueId = "raw-2")) }.isFailure)

    val quarantine = rec("q-1", WarehouseLayer.QUARANTINE, raw.uniqueId)
    w.transition(raw.uniqueId, quarantine)
    val validated = rec("v-1", WarehouseLayer.VALIDATED, quarantine.uniqueId)
    w.transition(quarantine.uniqueId, validated)
    val canonical = rec("c-1", WarehouseLayer.CANONICAL, validated.uniqueId)
    w.transition(validated.uniqueId, canonical)
    check(w.transitionCount() == 3)

    val feature = rec("f-1", WarehouseLayer.FEATURE, t = 20)
    w.freezeFeature(feature, listOf(canonical.uniqueId), cutoff = 100)
    check(w.featureInputIds(feature.uniqueId) == listOf(canonical.uniqueId))
    check(runCatching { w.replace(feature.copy(payload = "changed")) }.isFailure)

    val futureCanonical = rec("c-future", WarehouseLayer.CANONICAL, t = 200)
    check(runCatching { w.freezeFeature(rec("f-2", WarehouseLayer.FEATURE, t=210), listOf(futureCanonical.uniqueId), 100) }.isFailure)
    check(!LayerTransitionPolicy.canMove(WarehouseLayer.CANONICAL, WarehouseLayer.OUTCOME))
    println("R28_WAREHOUSE_TRANSACTION_PASS")
}
