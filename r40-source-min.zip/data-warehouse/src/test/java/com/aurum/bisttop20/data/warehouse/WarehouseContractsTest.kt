package com.aurum.bisttop20.data.warehouse

import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertTrue

class WarehouseContractsTest {
    @Test fun rejectsFutureAvailableData() {
        val r = WarehouseRecord("1", WarehouseLayer.FEATURE, "d", WarehouseStamp(1,2,3,5,"s","a".repeat(64),"1","1"), "x")
        assertIs<WarehouseDecision.Reject>(WarehouseIngressPolicy.validate(r, predictionCutoff = 4))
    }
    @Test fun transitionGraphIsClosed() {
        assertTrue(LayerTransitionPolicy.canMove(WarehouseLayer.RAW, WarehouseLayer.VALIDATED))
        assertFalse(LayerTransitionPolicy.canMove(WarehouseLayer.OUTCOME, WarehouseLayer.FEATURE))
    }
}
