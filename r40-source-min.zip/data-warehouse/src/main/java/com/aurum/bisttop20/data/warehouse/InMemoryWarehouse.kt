package com.aurum.bisttop20.data.warehouse

class InMemoryWarehouse {
    private val records = linkedMapOf<String, WarehouseRecord<String>>()
    private val transitions = mutableListOf<Pair<String, String>>()
    private val frozen = mutableSetOf<String>()
    private val featureInputs = mutableMapOf<String, List<String>>()

    fun appendRaw(record: WarehouseRecord<String>) {
        require(record.layer == WarehouseLayer.RAW)
        require(WarehouseIngressPolicy.validate(record) is WarehouseDecision.Accept)
        require(records.values.none { it.layer == WarehouseLayer.RAW && it.deduplicationKey == record.deduplicationKey })
        records[record.uniqueId] = record
        frozen += record.uniqueId
    }

    fun transition(sourceId: String, target: WarehouseRecord<String>) {
        val source = requireNotNull(records[sourceId])
        require(target.parentRecordId == sourceId)
        require(LayerTransitionPolicy.canMove(source.layer, target.layer))
        require(WarehouseIngressPolicy.validate(target) is WarehouseDecision.Accept)
        require(target.uniqueId !in records)
        records[target.uniqueId] = target
        transitions += sourceId to target.uniqueId
        if (target.layer in setOf(WarehouseLayer.FEATURE, WarehouseLayer.PREDICTION, WarehouseLayer.OUTCOME, WarehouseLayer.ARCHIVE)) frozen += target.uniqueId
    }

    fun freezeFeature(snapshot: WarehouseRecord<String>, inputIds: List<String>, cutoff: Long) {
        require(snapshot.layer == WarehouseLayer.FEATURE)
        require(inputIds.isNotEmpty())
        val inputs = inputIds.map { requireNotNull(records[it]) }
        require(inputs.all { it.layer == WarehouseLayer.CANONICAL })
        require(inputs.all { WarehouseIngressPolicy.validate(it, cutoff) is WarehouseDecision.Accept })
        require(snapshot.uniqueId !in records)
        records[snapshot.uniqueId] = snapshot
        featureInputs[snapshot.uniqueId] = inputIds.toList()
        frozen += snapshot.uniqueId
    }

    fun replace(record: WarehouseRecord<String>) {
        require(record.uniqueId !in frozen) { "immutable record" }
        require(record.uniqueId in records)
        records[record.uniqueId] = record
    }

    fun delete(recordId: String) {
        require(recordId !in frozen) { "immutable record" }
        records.remove(recordId)
    }

    fun record(id: String) = records[id]
    fun transitionCount() = transitions.size
    fun featureInputIds(id: String) = featureInputs[id].orEmpty()
}
