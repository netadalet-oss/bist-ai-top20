package com.aurum.bisttop20.data.warehouse

enum class WarehouseLayer { RAW, QUARANTINE, VALIDATED, CANONICAL, FEATURE, PREDICTION, OUTCOME, ARCHIVE }

data class WarehouseStamp(
    val effectiveTimestamp: Long,
    val observedTimestamp: Long,
    val acquiredTimestamp: Long,
    val availableForPredictionTimestamp: Long,
    val sourceId: String,
    val sourceHashSha256: String,
    val schemaVersion: String,
    val dataVersion: String
)

data class WarehouseRecord<T>(
    val uniqueId: String,
    val layer: WarehouseLayer,
    val deduplicationKey: String,
    val stamp: WarehouseStamp,
    val payload: T,
    val parentRecordId: String? = null,
    val supersedesId: String? = null
)

sealed interface WarehouseDecision {
    data object Accept : WarehouseDecision
    data class Reject(val reasons: List<String>) : WarehouseDecision
}

object WarehouseIngressPolicy {
    private val sha256 = Regex("^[0-9a-fA-F]{64}$")

    fun validate(record: WarehouseRecord<*>, predictionCutoff: Long? = null): WarehouseDecision {
        val errors = mutableListOf<String>()
        if (record.uniqueId.isBlank()) errors += "unique_id_missing"
        if (record.deduplicationKey.isBlank()) errors += "deduplication_key_missing"
        if (record.stamp.sourceId.isBlank()) errors += "source_id_missing"
        if (!sha256.matches(record.stamp.sourceHashSha256)) errors += "source_hash_invalid"
        if (record.stamp.observedTimestamp < record.stamp.effectiveTimestamp) errors += "observed_before_effective"
        if (record.stamp.acquiredTimestamp < record.stamp.observedTimestamp) errors += "acquired_before_observed"
        if (record.stamp.availableForPredictionTimestamp < record.stamp.acquiredTimestamp) errors += "available_before_acquired"
        if (predictionCutoff != null && record.stamp.availableForPredictionTimestamp > predictionCutoff) {
            errors += "point_in_time_violation"
        }
        if (record.layer == WarehouseLayer.RAW && record.supersedesId != null) errors += "raw_record_cannot_supersede"
        return if (errors.isEmpty()) WarehouseDecision.Accept else WarehouseDecision.Reject(errors)
    }
}

object LayerTransitionPolicy {
    private val allowed = mapOf(
        WarehouseLayer.RAW to setOf(WarehouseLayer.QUARANTINE, WarehouseLayer.VALIDATED, WarehouseLayer.ARCHIVE),
        WarehouseLayer.QUARANTINE to setOf(WarehouseLayer.VALIDATED, WarehouseLayer.ARCHIVE),
        WarehouseLayer.VALIDATED to setOf(WarehouseLayer.CANONICAL, WarehouseLayer.ARCHIVE),
        WarehouseLayer.CANONICAL to setOf(WarehouseLayer.FEATURE, WarehouseLayer.ARCHIVE),
        WarehouseLayer.FEATURE to setOf(WarehouseLayer.PREDICTION, WarehouseLayer.ARCHIVE),
        WarehouseLayer.PREDICTION to setOf(WarehouseLayer.OUTCOME, WarehouseLayer.ARCHIVE),
        WarehouseLayer.OUTCOME to setOf(WarehouseLayer.ARCHIVE),
        WarehouseLayer.ARCHIVE to emptySet()
    )

    fun canMove(from: WarehouseLayer, to: WarehouseLayer): Boolean = to in allowed.getValue(from)
}
