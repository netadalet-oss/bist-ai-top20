package com.aurum.bisttop20.domain.risk

object R35Validation {
    @JvmStatic fun main(args: Array<String>) {
        check(RiskControlUiMapper.map(RiskControlState.ACTIVE).mayRunJobs)
        check(!RiskControlUiMapper.map(RiskControlState.PAUSED).mayRunJobs)
        check(RiskControlUiMapper.map(RiskControlState.KILLED).mayResume)
        check(!RiskControlUiMapper.map(RiskControlState.KILLED).mayKill)
        println("R35_RISK_UI_FLOW_PASS")
    }
}
