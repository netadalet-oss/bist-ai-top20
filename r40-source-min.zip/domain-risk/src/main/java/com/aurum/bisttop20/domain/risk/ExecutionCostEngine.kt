package com.aurum.bisttop20.domain.risk

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class ExecutionCostEngine {
    fun evaluate(context: MarketExecutionContext, assumptions: CostAssumptions): ExecutionOutcome {
        val errors = linkedSetOf<String>()
        if (context.entryTimestamp < context.decisionTimestamp) errors += "ENTRY_BEFORE_DECISION"
        if (context.exitTimestamp <= context.entryTimestamp) errors += "EXIT_NOT_AFTER_ENTRY"
        if (context.referenceEntryPrice <= 0.0 || context.referenceExitPrice <= 0.0) errors += "INVALID_PRICE"
        if (context.orderValue <= 0.0) errors += "INVALID_ORDER_VALUE"
        if (assumptions.commissionRate !in 0.0..0.1) errors += "INVALID_COMMISSION_RATE"
        if (assumptions.taxRate !in 0.0..0.1) errors += "INVALID_TAX_RATE"
        if (assumptions.slippageBps < 0.0) errors += "INVALID_SLIPPAGE"
        if (assumptions.minimumFillProbability !in 0.0..1.0) errors += "INVALID_MIN_FILL_PROBABILITY"
        if (context.tradingHalted) errors += "TRADING_HALTED"
        if (context.lockedLimitUp) errors += "LOCKED_LIMIT_UP"
        if (context.lockedLimitDown) errors += "LOCKED_LIMIT_DOWN"
        if (errors.isNotEmpty()) return rejected(errors)

        val spreadPerShare = when {
            context.bid != null && context.ask != null && context.ask >= context.bid -> context.ask - context.bid
            else -> 0.0
        }
        val entry = max(context.referenceEntryPrice, context.ask ?: context.referenceEntryPrice)
        val exit = min(context.referenceExitPrice, context.bid ?: context.referenceExitPrice)
        val participation = context.averageDailyValue?.takeIf { it > 0.0 }?.let { context.orderValue / it }
        val fillProbability = when (participation) {
            null -> 0.5
            else -> (1.0 - participation * 2.0).coerceIn(0.0, 1.0)
        }
        if (fillProbability < assumptions.minimumFillProbability) {
            return rejected(setOf("INSUFFICIENT_FILL_PROBABILITY"), fillProbability)
        }

        val commission = context.orderValue * assumptions.commissionRate * 2.0
        val tax = context.orderValue * assumptions.taxRate
        val spreadCost = spreadPerShare / entry * context.orderValue
        val slippage = context.orderValue * assumptions.slippageBps / 10_000.0
        val impactRate = participation?.let { assumptions.marketImpactCoefficient * sqrt(it.coerceAtLeast(0.0)) } ?: 0.0
        val marketImpact = context.orderValue * impactRate
        val totalCost = commission + tax + spreadCost + slippage + marketImpact
        val grossReturn = exit / entry - 1.0
        val netReturn = grossReturn - totalCost / context.orderValue
        val status = if (fillProbability >= 0.999) FillStatus.FILLED else FillStatus.PARTIAL
        return ExecutionOutcome(entry, exit, grossReturn, netReturn, fillProbability, status,
            TradeCostBreakdown(commission, tax, spreadCost, slippage, marketImpact, totalCost), emptySet())
    }

    private fun rejected(reasons: Set<String>, probability: Double = 0.0) = ExecutionOutcome(
        null, null, null, null, probability,
        if (reasons.any { it == "TRADING_HALTED" || it.startsWith("LOCKED_") }) FillStatus.NOT_TRADABLE else FillStatus.NOT_FILLED,
        null, reasons
    )
}
