package com.aurum.bisttop20.domain.risk

fun main() {
    val positions = listOf(
        CandidatePosition("AAA", "BANK", .10, .80, .05, .20, 20_000_000.0, 100_000.0, true),
        CandidatePosition("BBB", "INDUSTRIAL", .10, .78, .04, .22, 18_000_000.0, 100_000.0, true),
        CandidatePosition("CCC", "RETAIL", .10, .75, .03, .25, 16_000_000.0, 100_000.0, true)
    )
    val correlation = CorrelationRiskGate().evaluate(
        positions,
        listOf(
            CorrelationObservation("AAA", "BBB", .91, 120, 900),
            CorrelationObservation("AAA", "CCC", .30, 120, 900),
            CorrelationObservation("BBB", "CCC", .20, 120, 1100) // cutoff sonrası, kullanılmamalı
        ),
        CorrelationLimits(.85, 60, 1000)
    )
    check(correlation.accepted.map { it.symbol } == listOf("AAA", "CCC"))
    check(correlation.rejected["BBB"]?.contains("CORRELATION_LIMIT:AAA") == true)
    check(correlation.portfolioConcentrationScore > 0.0)

    val controller = DailyLossAndKillSwitch { ts, code -> "evt-$ts-$code" }
    val loss = controller.evaluate(
        DailyRiskSnapshot("2026-08-01", -7500.0, -3000.0, 500_000.0, 300_000.0, 8, 1000),
        OperationalRiskLimits(10_000.0, 1_000_000.0, 20),
        RiskControlState.ACTIVE
    )
    check(loss.state == RiskControlState.KILLED)
    check("DAILY_LOSS_LIMIT" in loss.breachedRules)
    check(loss.auditEvents.single().severity == RiskEventSeverity.CRITICAL)

    val manual = controller.manualKill(1100, RiskControlState.ACTIVE, "Data source conflict")
    check(manual.state == RiskControlState.KILLED)
    val resumed = controller.resume(1200, manual.state, approved = true, reason = "Conflict resolved and reviewed")
    check(resumed.state == RiskControlState.ACTIVE)

    println("R33_OPERATIONAL_RISK_PASS")
}
