package com.aurum.bisttop20.domain.risk

interface RiskStateStore {
    suspend fun read(): RiskControlState
    suspend fun append(decision: RiskControlDecision, actor: String, reason: String, approvedBy: String? = null)
}

data class RiskCommandResult(
    val accepted: Boolean,
    val state: RiskControlState,
    val message: String
)

class RiskCommandService(
    private val store: RiskStateStore,
    private val engine: DailyLossAndKillSwitch
) {
    suspend fun kill(timestamp: Long, actor: String, reason: String): RiskCommandResult {
        val current = store.read()
        val decision = engine.manualKill(timestamp, current, reason)
        store.append(decision, actor, reason)
        return RiskCommandResult(true, decision.state, "Emergency stop applied")
    }

    suspend fun resume(
        timestamp: Long,
        actor: String,
        approvedBy: String,
        reason: String,
        explicitApproval: Boolean
    ): RiskCommandResult {
        val current = store.read()
        if (current == RiskControlState.ACTIVE) return RiskCommandResult(false, current, "Already active")
        val decision = engine.resume(timestamp, current, explicitApproval, reason)
        store.append(decision, actor, reason, approvedBy)
        return RiskCommandResult(true, decision.state, "Risk control resumed")
    }
}

class RiskExecutionGate {
    fun mayExecute(state: RiskControlState): Boolean = state == RiskControlState.ACTIVE
    fun requireExecutionAllowed(state: RiskControlState) {
        check(mayExecute(state)) { "Execution blocked by risk control state: $state" }
    }
}

interface ObservableRiskStateStore : RiskStateStore {
    fun observe(): kotlinx.coroutines.flow.Flow<RiskControlState>
}

data class RiskControlUiState(
    val state: RiskControlState,
    val statusText: String,
    val mayRunJobs: Boolean,
    val mayKill: Boolean,
    val mayResume: Boolean
)

object RiskControlUiMapper {
    fun map(state: RiskControlState): RiskControlUiState = RiskControlUiState(
        state = state,
        statusText = when (state) {
            RiskControlState.ACTIVE -> "Aktif"
            RiskControlState.PAUSED -> "Duraklatıldı"
            RiskControlState.KILLED -> "Acil durdurma etkin"
        },
        mayRunJobs = state == RiskControlState.ACTIVE,
        mayKill = state != RiskControlState.KILLED,
        mayResume = state != RiskControlState.ACTIVE
    )
}
