package com.aurum.bisttop20.domain.risk

fun main() {
    val engine = ExecutionCostEngine()
    val context = MarketExecutionContext(1000, 1010, 2000, EntryRule.FIRST_EXECUTABLE, ExitRule.END_OF_DAY,
        100.0, 105.0, 99.9, 100.1, 10_000_000.0, 100_000.0, false, false, false)
    val out = engine.evaluate(context, CostAssumptions(.001, 0.0, 5.0, .01, .5))
    check(out.netReturn != null && out.netReturn!! < out.grossReturn!!)
    check(out.fillStatus == FillStatus.PARTIAL || out.fillStatus == FillStatus.FILLED)
    val blocked = engine.evaluate(context.copy(lockedLimitUp = true), CostAssumptions(.001, 0.0, 5.0, .01, .5))
    check(blocked.fillStatus == FillStatus.NOT_TRADABLE)

    val gate = PortfolioRiskGate()
    val result = gate.evaluate(listOf(
        CandidatePosition("AAA","BANK",.10,.8,.04,.2,10_000_000.0,100_000.0,true),
        CandidatePosition("BBB","BANK",.20,.4,.01,.8,100_000.0,500_000.0,true)
    ), RiskLimits(.15,.20,.05,.6,.02,.5))
    check(result.accepted.map { it.symbol } == listOf("AAA"))
    check("BBB" in result.rejected)
    println("R32_RISK_ENGINE_PASS")
}
