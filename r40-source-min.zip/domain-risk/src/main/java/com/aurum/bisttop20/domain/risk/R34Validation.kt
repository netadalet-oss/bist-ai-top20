package com.aurum.bisttop20.domain.risk

import kotlin.coroutines.*

private class MemoryRiskStore(initial: RiskControlState) : RiskStateStore {
    var state = initial
    val decisions = mutableListOf<RiskControlDecision>()
    override suspend fun read(): RiskControlState = state
    override suspend fun append(decision: RiskControlDecision, actor: String, reason: String, approvedBy: String?) {
        require(actor.isNotBlank())
        require(reason.isNotBlank())
        decisions += decision
        state = decision.state
    }
}

private fun <T> runSuspend(block: suspend () -> T): T {
    var result: Result<T>? = null
    block.startCoroutine(object : Continuation<T> {
        override val context: CoroutineContext = EmptyCoroutineContext
        override fun resumeWith(r: Result<T>) { result = r }
    })
    return result!!.getOrThrow()
}

fun main() = runSuspend {
    val store = MemoryRiskStore(RiskControlState.ACTIVE)
    val service = RiskCommandService(store, DailyLossAndKillSwitch { ts, code -> "r34-$ts-$code" })
    val gate = RiskExecutionGate()
    check(gate.mayExecute(RiskControlState.ACTIVE))
    check(!gate.mayExecute(RiskControlState.PAUSED))
    check(!gate.mayExecute(RiskControlState.KILLED))

    val killed = service.kill(1000L, "user", "manual emergency stop")
    check(killed.state == RiskControlState.KILLED)
    check(runCatching { gate.requireExecutionAllowed(store.state) }.isFailure)

    check(runCatching { service.resume(1100L, "user", "approver", "review complete", false) }.isFailure)
    val resumed = service.resume(1200L, "user", "approver", "risk review complete", true)
    check(resumed.state == RiskControlState.ACTIVE)
    check(store.decisions.size == 2)
    println("R34_RISK_PERSISTENCE_GATE_PASS")
}
