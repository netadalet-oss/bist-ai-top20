package com.aurum.bisttop20.domain.risk

import kotlin.math.sqrt

data class CorrelationObservation(
    val leftSymbol: String,
    val rightSymbol: String,
    val correlation: Double,
    val observationCount: Int,
    val availableForPredictionTimestamp: Long
)

data class CorrelationLimits(
    val maximumPairwiseCorrelation: Double,
    val minimumObservationCount: Int,
    val decisionCutoffTimestamp: Long
)

data class CorrelationDecision(
    val accepted: List<CandidatePosition>,
    val rejected: Map<String, Set<String>>,
    val portfolioConcentrationScore: Double
)

class CorrelationRiskGate {
    fun evaluate(
        candidates: List<CandidatePosition>,
        observations: List<CorrelationObservation>,
        limits: CorrelationLimits
    ): CorrelationDecision {
        require(limits.maximumPairwiseCorrelation in -1.0..1.0)
        require(limits.minimumObservationCount >= 2)
        val map = mutableMapOf<Pair<String, String>, CorrelationObservation>()
        observations.forEach { o ->
            require(o.correlation in -1.0..1.0)
            if (o.availableForPredictionTimestamp <= limits.decisionCutoffTimestamp && o.observationCount >= limits.minimumObservationCount) {
                map[key(o.leftSymbol, o.rightSymbol)] = o
            }
        }
        val accepted = mutableListOf<CandidatePosition>()
        val rejected = linkedMapOf<String, Set<String>>()
        candidates.sortedByDescending { it.expectedNetReturn }.forEach { candidate ->
            val reasons = linkedSetOf<String>()
            accepted.forEach { existing ->
                val obs = map[key(candidate.symbol, existing.symbol)]
                if (obs != null && obs.correlation > limits.maximumPairwiseCorrelation) {
                    reasons += "CORRELATION_LIMIT:${existing.symbol}"
                }
            }
            if (reasons.isEmpty()) accepted += candidate else rejected[candidate.symbol] = reasons
        }
        return CorrelationDecision(accepted, rejected, concentrationScore(accepted, map))
    }

    private fun key(a: String, b: String) = if (a <= b) a to b else b to a

    private fun concentrationScore(
        positions: List<CandidatePosition>,
        map: Map<Pair<String, String>, CorrelationObservation>
    ): Double {
        if (positions.isEmpty()) return 0.0
        var variance = 0.0
        for (i in positions.indices) {
            val pi = positions[i]
            variance += pi.proposedWeight * pi.proposedWeight
            for (j in i + 1 until positions.size) {
                val pj = positions[j]
                val corr = map[key(pi.symbol, pj.symbol)]?.correlation ?: 0.0
                variance += 2.0 * pi.proposedWeight * pj.proposedWeight * corr
            }
        }
        return sqrt(variance.coerceAtLeast(0.0))
    }
}
