package com.aurum.bisttop20.domain.risk

enum class EntryRule { OPEN_AUCTION, FIRST_EXECUTABLE, VWAP_1M, VWAP_5M, BROKER_FILL }
enum class ExitRule { FIRST_TOP20_ENTRY, FIXED_HORIZON, END_OF_DAY, T_PLUS_1_CLOSE, STOP_OR_TARGET, EXECUTABLE_VWAP }
enum class FillStatus { FILLED, PARTIAL, NOT_FILLED, NOT_TRADABLE }

data class MarketExecutionContext(
    val decisionTimestamp: Long,
    val entryTimestamp: Long,
    val exitTimestamp: Long,
    val entryRule: EntryRule,
    val exitRule: ExitRule,
    val referenceEntryPrice: Double,
    val referenceExitPrice: Double,
    val bid: Double?,
    val ask: Double?,
    val averageDailyValue: Double?,
    val orderValue: Double,
    val lockedLimitUp: Boolean,
    val lockedLimitDown: Boolean,
    val tradingHalted: Boolean
)

data class CostAssumptions(
    val commissionRate: Double,
    val taxRate: Double,
    val slippageBps: Double,
    val marketImpactCoefficient: Double,
    val minimumFillProbability: Double
)

data class TradeCostBreakdown(
    val commission: Double,
    val tax: Double,
    val spreadCost: Double,
    val slippage: Double,
    val marketImpact: Double,
    val totalCost: Double
)

data class ExecutionOutcome(
    val executableEntryPrice: Double?,
    val executableExitPrice: Double?,
    val grossReturn: Double?,
    val netReturn: Double?,
    val fillProbability: Double,
    val fillStatus: FillStatus,
    val costs: TradeCostBreakdown?,
    val rejectionReasons: Set<String>
)
