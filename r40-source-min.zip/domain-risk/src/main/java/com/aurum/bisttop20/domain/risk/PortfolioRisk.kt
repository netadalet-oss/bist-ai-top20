package com.aurum.bisttop20.domain.risk

data class CandidatePosition(
    val symbol: String,
    val sector: String,
    val proposedWeight: Double,
    val probability: Double,
    val expectedNetReturn: Double,
    val uncertainty: Double,
    val averageDailyValue: Double,
    val proposedOrderValue: Double,
    val tradable: Boolean
)

data class RiskLimits(
    val maxSingleNameWeight: Double,
    val maxSectorWeight: Double,
    val maxDailyValueParticipation: Double,
    val minimumProbability: Double,
    val minimumExpectedNetReturn: Double,
    val maximumUncertainty: Double,
    val maximumTotalWeight: Double = 1.0
)

data class PortfolioDecision(val accepted: List<CandidatePosition>, val rejected: Map<String, Set<String>>)

class PortfolioRiskGate {
    fun evaluate(candidates: List<CandidatePosition>, limits: RiskLimits): PortfolioDecision {
        val accepted = mutableListOf<CandidatePosition>()
        val rejected = linkedMapOf<String, Set<String>>()
        val sectorWeights = mutableMapOf<String, Double>()
        var totalWeight = 0.0
        candidates.sortedByDescending { it.expectedNetReturn }.forEach { c ->
            val reasons = linkedSetOf<String>()
            if (!c.tradable) reasons += "NOT_TRADABLE"
            if (c.proposedWeight <= 0.0 || c.proposedWeight > limits.maxSingleNameWeight) reasons += "SINGLE_NAME_LIMIT"
            if (c.probability < limits.minimumProbability) reasons += "PROBABILITY_BELOW_LIMIT"
            if (c.expectedNetReturn < limits.minimumExpectedNetReturn) reasons += "NET_RETURN_BELOW_LIMIT"
            if (c.uncertainty > limits.maximumUncertainty) reasons += "UNCERTAINTY_ABOVE_LIMIT"
            val participation = if (c.averageDailyValue > 0.0) c.proposedOrderValue / c.averageDailyValue else Double.POSITIVE_INFINITY
            if (participation > limits.maxDailyValueParticipation) reasons += "LIQUIDITY_LIMIT"
            if ((sectorWeights[c.sector] ?: 0.0) + c.proposedWeight > limits.maxSectorWeight) reasons += "SECTOR_LIMIT"
            if (totalWeight + c.proposedWeight > limits.maximumTotalWeight) reasons += "TOTAL_WEIGHT_LIMIT"
            if (reasons.isEmpty()) {
                accepted += c
                totalWeight += c.proposedWeight
                sectorWeights[c.sector] = (sectorWeights[c.sector] ?: 0.0) + c.proposedWeight
            } else rejected[c.symbol] = reasons
        }
        return PortfolioDecision(accepted, rejected)
    }
}
