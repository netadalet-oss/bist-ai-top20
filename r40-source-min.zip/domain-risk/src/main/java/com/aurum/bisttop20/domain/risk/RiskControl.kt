package com.aurum.bisttop20.domain.risk

import kotlin.math.abs

enum class RiskControlState { ACTIVE, PAUSED, KILLED }
enum class RiskEventSeverity { INFO, WARNING, CRITICAL }

data class RiskAuditEvent(
    val eventId: String,
    val timestamp: Long,
    val severity: RiskEventSeverity,
    val code: String,
    val message: String,
    val affectedSymbols: Set<String> = emptySet(),
    val stateBefore: RiskControlState,
    val stateAfter: RiskControlState
)

data class DailyRiskSnapshot(
    val tradingDate: String,
    val realizedPnl: Double,
    val unrealizedPnl: Double,
    val grossExposure: Double,
    val netExposure: Double,
    val openPositionCount: Int,
    val lastUpdatedTimestamp: Long
) {
    val totalPnl: Double get() = realizedPnl + unrealizedPnl
}

data class OperationalRiskLimits(
    val maximumDailyLoss: Double,
    val maximumGrossExposure: Double,
    val maximumOpenPositions: Int,
    val automaticKillOnLimitBreach: Boolean = true
)

data class RiskControlDecision(
    val state: RiskControlState,
    val breachedRules: Set<String>,
    val auditEvents: List<RiskAuditEvent>
)

class DailyLossAndKillSwitch(private val eventIdFactory: (Long, String) -> String = { ts, code -> "$ts-$code" }) {
    fun evaluate(
        snapshot: DailyRiskSnapshot,
        limits: OperationalRiskLimits,
        currentState: RiskControlState
    ): RiskControlDecision {
        val breaches = linkedSetOf<String>()
        require(limits.maximumDailyLoss >= 0.0) { "maximumDailyLoss must be non-negative" }
        require(limits.maximumGrossExposure >= 0.0) { "maximumGrossExposure must be non-negative" }
        require(limits.maximumOpenPositions >= 0) { "maximumOpenPositions must be non-negative" }

        if (snapshot.totalPnl <= -abs(limits.maximumDailyLoss)) breaches += "DAILY_LOSS_LIMIT"
        if (snapshot.grossExposure > limits.maximumGrossExposure) breaches += "GROSS_EXPOSURE_LIMIT"
        if (snapshot.openPositionCount > limits.maximumOpenPositions) breaches += "OPEN_POSITION_LIMIT"

        val targetState = when {
            currentState == RiskControlState.KILLED -> RiskControlState.KILLED
            breaches.isEmpty() -> currentState
            limits.automaticKillOnLimitBreach -> RiskControlState.KILLED
            else -> RiskControlState.PAUSED
        }
        val events = if (breaches.isEmpty()) emptyList() else listOf(
            RiskAuditEvent(
                eventId = eventIdFactory(snapshot.lastUpdatedTimestamp, breaches.joinToString("+")),
                timestamp = snapshot.lastUpdatedTimestamp,
                severity = if (targetState == RiskControlState.KILLED) RiskEventSeverity.CRITICAL else RiskEventSeverity.WARNING,
                code = if (targetState == RiskControlState.KILLED) "RISK_KILL_SWITCH" else "RISK_PAUSE",
                message = "Operational risk limit breached: ${breaches.joinToString(",")}",
                stateBefore = currentState,
                stateAfter = targetState
            )
        )
        return RiskControlDecision(targetState, breaches, events)
    }

    fun manualKill(timestamp: Long, currentState: RiskControlState, reason: String): RiskControlDecision {
        require(reason.isNotBlank()) { "Manual kill reason is required" }
        val event = RiskAuditEvent(
            eventIdFactory(timestamp, "MANUAL_KILL"), timestamp, RiskEventSeverity.CRITICAL,
            "MANUAL_KILL", reason, stateBefore = currentState, stateAfter = RiskControlState.KILLED
        )
        return RiskControlDecision(RiskControlState.KILLED, setOf("MANUAL_KILL"), listOf(event))
    }

    fun resume(timestamp: Long, currentState: RiskControlState, approved: Boolean, reason: String): RiskControlDecision {
        require(approved) { "Explicit approval is required to resume" }
        require(reason.isNotBlank()) { "Resume reason is required" }
        val event = RiskAuditEvent(
            eventIdFactory(timestamp, "RISK_RESUME"), timestamp, RiskEventSeverity.INFO,
            "RISK_RESUME", reason, stateBefore = currentState, stateAfter = RiskControlState.ACTIVE
        )
        return RiskControlDecision(RiskControlState.ACTIVE, emptySet(), listOf(event))
    }
}
