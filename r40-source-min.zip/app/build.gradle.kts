plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.aurum.bisttop20"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.aurum.bisttop20"
        minSdk = 26
        targetSdk = 35
        versionCode = 40
        versionName = "0.40.0-release-candidate"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "SCHEMA_VERSION", "\"1\"")
    }
    signingConfigs {
        create("release") {
            val storeFilePath = System.getenv("AURUM_STORE_FILE")
            if (!storeFilePath.isNullOrBlank()) storeFile = file(storeFilePath)
            storePassword = System.getenv("AURUM_STORE_PASSWORD")
            keyAlias = System.getenv("AURUM_KEY_ALIAS")
            keyPassword = System.getenv("AURUM_KEY_PASSWORD")
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
            enableV4Signing = false
        }
    }
    buildTypes {
        debug { applicationIdSuffix = ".debug"; versionNameSuffix = "-debug" }
        release {
            isMinifyEnabled = true
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { buildConfig = true }
    packaging.resources.excludes += setOf("META-INF/AL2.0", "META-INF/LGPL2.1")
}

dependencies { implementation(project(":domain-jobs"));
    implementation(project(":core-model"))
    implementation(project(":core-database"))
    implementation(project(":domain-quality"))
    implementation(project(":domain-prediction"))
    implementation(project(":domain-risk"))
    implementation(project(":data-excel"))
    implementation(project(":core-network"))
    implementation(project(":data-adapters"))
    implementation(project(":domain-staging"))

    implementation(libs.androidx.core)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.webkit)
    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)
    implementation(libs.work.runtime)
    implementation(libs.datastore)
    implementation(libs.coroutines)
    implementation(libs.security)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
}
