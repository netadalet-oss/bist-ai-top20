package com.aurum.bisttop20

import com.aurum.bisttop20.domain.prediction.*
import org.junit.Assert.*
import org.junit.Test

class PredictionContractValidatorTest {
    @Test fun validRunPasses() {
        val run = PredictionRunContract("r1", 100, 90, 101, 200, "c".repeat(64), "m1", "f1", "u1")
        val items = listOf(PredictionCandidateContract("THYAO", 1, .5, .02, .2, .9))
        assertTrue(PredictionContractValidator.validate(run, items).valid)
    }
    @Test fun futureDataAndBrokenRanksFail() {
        val run = PredictionRunContract("r1", 100, 110, 90, 80, "bad", "", "", "")
        val items = listOf(PredictionCandidateContract("thy", 2, 1.2, null, -1.0, 2.0))
        assertFalse(PredictionContractValidator.validate(run, items).valid)
    }
}
