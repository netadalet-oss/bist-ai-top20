package com.aurum.bisttop20

import com.aurum.bisttop20.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class ModelActivationPolicyTest {
    @Test fun acceptedModelCanActivate() {
        val result = ModelActivationPolicy.evaluate(ModelActivationRequest(
            ModelSlot.K6, "k6-1.0", "a".repeat(64), ModelStage.ACCEPTED, ModelRole.CHALLENGER,
            1L, 1L, externalMetricsRecorded = true, userApprovalRecorded = true,
        ))
        assertTrue(result.active)
    }
    @Test fun draftModelCannotActivate() {
        val result = ModelActivationPolicy.evaluate(ModelActivationRequest(
            ModelSlot.K10, "draft", "b".repeat(64), ModelStage.DRAFT, ModelRole.CHALLENGER,
            null, null, externalMetricsRecorded = false, userApprovalRecorded = false,
        ))
        assertFalse(result.active)
        assertTrue(result.reasons.isNotEmpty())
    }
}
