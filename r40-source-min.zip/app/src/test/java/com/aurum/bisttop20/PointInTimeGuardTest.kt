package com.aurum.bisttop20

import com.aurum.bisttop20.domain.prediction.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PointInTimeGuardTest {
    @Test fun acceptsOnlyFeaturesAvailableByCutoff() {
        val result = PointInTimeGuard.validate(
            PredictionCutoff(decisionTimestamp = 200, dataCutoffTimestamp = 190),
            listOf(TimedFeature("momentum", 170, 180, 185, "abc"))
        )
        assertEquals(PointInTimeResult.Valid, result)
    }

    @Test fun rejectsFutureAndUntraceableFeatures() {
        val result = PointInTimeGuard.validate(
            PredictionCutoff(decisionTimestamp = 200, dataCutoffTimestamp = 190),
            listOf(TimedFeature("news", 180, 195, 196, ""))
        )
        assertTrue(result is PointInTimeResult.Invalid)
        val violations = (result as PointInTimeResult.Invalid).violations
        assertTrue("news:available_after_cutoff" in violations)
        assertTrue("news:acquired_after_cutoff" in violations)
        assertTrue("news:missing_source_hash" in violations)
    }
}
