package com.aurum.bisttop20
import com.aurum.bisttop20.domain.calendar.*
import org.junit.Assert.*
import org.junit.Test
class TradingCalendarPolicyTest { @Test fun requiresAllRolloverGates(){ assertTrue(TradingCalendarPolicy.mayRollover(TradingDayState(true,true,true,true,true,false))); assertFalse(TradingCalendarPolicy.mayRollover(TradingDayState(true,true,false,true,true,false))); assertFalse(TradingCalendarPolicy.mayRollover(TradingDayState(true,true,true,true,true,true))) } }
