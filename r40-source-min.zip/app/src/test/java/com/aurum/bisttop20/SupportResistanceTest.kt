package com.aurum.bisttop20
import com.aurum.bisttop20.domain.technical.SupportResistance
import org.junit.Assert.*
import org.junit.Test
class SupportResistanceTest { @Test fun calculatesNearestLevelsAndDistances(){ val r=SupportResistance.calculate(100.0,listOf(80.0,95.0,110.0,130.0)); assertEquals(95.0,r.support!!,0.0); assertEquals(110.0,r.resistance!!,0.0); assertEquals(5.0,r.supportDistancePct!!,1e-9); assertEquals(10.0,r.resistanceDistancePct!!,1e-9); assertEquals(2.0,r.riskReward!!,1e-9) } }
