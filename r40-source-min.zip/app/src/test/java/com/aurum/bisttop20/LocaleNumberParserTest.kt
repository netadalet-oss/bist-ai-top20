package com.aurum.bisttop20
import com.aurum.bisttop20.domain.quality.LocaleNumberParser
import org.junit.Assert.*
import org.junit.Test
class LocaleNumberParserTest { @Test fun parsesTurkishAndDotDecimal(){ assertEquals(2744.17,(LocaleNumberParser.parse("2.744,17") as LocaleNumberParser.Result.Valid).value,1e-9); assertEquals(2744.17,(LocaleNumberParser.parse("2744.17") as LocaleNumberParser.Result.Valid).value,1e-9); assertEquals(14.66,(LocaleNumberParser.parse("14,66") as LocaleNumberParser.Result.Valid).value,1e-9) } @Test fun quarantinesObjects(){ assertTrue(LocaleNumberParser.parse("[object Object]") is LocaleNumberParser.Result.Quarantine) } }
