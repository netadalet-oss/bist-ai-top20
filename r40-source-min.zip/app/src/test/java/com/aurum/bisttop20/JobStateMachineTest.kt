package com.aurum.bisttop20

import com.aurum.bisttop20.jobs.*
import org.junit.Assert.assertEquals
import org.junit.Test

class JobStateMachineTest {
    @Test fun pauseResumeCancelFlow() {
        assertEquals(JobStatus.RUNNING, JobStateMachine.transition(JobStatus.WAITING, JobCommand.START))
        assertEquals(JobStatus.PAUSED, JobStateMachine.transition(JobStatus.RUNNING, JobCommand.PAUSE))
        assertEquals(JobStatus.RUNNING, JobStateMachine.transition(JobStatus.PAUSED, JobCommand.RESUME))
        assertEquals(JobStatus.CANCELLED, JobStateMachine.transition(JobStatus.RUNNING, JobCommand.CANCEL))
    }

    @Test(expected = IllegalStateException::class)
    fun completedCannotResume() {
        JobStateMachine.transition(JobStatus.COMPLETED, JobCommand.RESUME)
    }
}
