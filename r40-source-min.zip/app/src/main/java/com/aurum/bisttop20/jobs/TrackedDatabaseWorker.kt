package com.aurum.bisttop20.jobs

import android.content.Context
import androidx.work.WorkerParameters
import com.aurum.bisttop20.AurumApplication
import com.aurum.bisttop20.domain.jobs.*

abstract class TrackedDatabaseWorker(
    context: Context,
    params: WorkerParameters
) : DatabaseRiskAwareWorker(context, params) {
    protected abstract val module: JobModule
    protected open val jobId: String get() = inputData.getString("jobId") ?: id.toString()
    private val app get() = applicationContext as AurumApplication
    private val store get() = app.jobStore

    private suspend fun currentOrQueued(now: Long): JobSnapshot = store.read(jobId)
        ?: JobSnapshot(jobId, module, JobStatus.QUEUED, updatedAt = now)

    override suspend fun onJobStarted() {
        val now = System.currentTimeMillis()
        val current = currentOrQueued(now)
        val startable = when (current.status) {
            JobStatus.QUEUED, JobStatus.PAUSED -> current
            JobStatus.FAILED -> JobStatePolicy.transition(current, JobStatus.QUEUED, now)
            else -> current
        }
        store.save(JobStatePolicy.transition(startable, JobStatus.RUNNING, now))
    }

    override suspend fun onJobCheckpoint(stagingId: String) {
        val now = System.currentTimeMillis()
        val current = requireNotNull(store.read(jobId))
        val checkpointed = JobStatePolicy.checkpoint(current, stagingId, current.completedRecords, current.failedRecords, 0.75, now)
        val runtime = Runtime.getRuntime()
        val usedMemory = runtime.totalMemory() - runtime.freeMemory()
        val cpuApprox = (now - (checkpointed.startedAt ?: now)).coerceAtLeast(0)
        store.save(JobStatePolicy.telemetry(
            checkpointed,
            totalRecords = checkpointed.totalRecords,
            usage = checkpointed.resourceUsage.copy(
                cpuMillis = maxOf(checkpointed.resourceUsage.cpuMillis, cpuApprox),
                peakMemoryBytes = maxOf(checkpointed.resourceUsage.peakMemoryBytes, usedMemory)
            ),
            now = now
        ))
    }

    override suspend fun onJobCompleted() {
        val now = System.currentTimeMillis()
        val current = requireNotNull(store.read(jobId))
        store.save(JobStatePolicy.transition(current, JobStatus.COMPLETED, now))
    }

    override suspend fun onJobFailed(error: Throwable, willRetry: Boolean) {
        val now = System.currentTimeMillis()
        val current = store.read(jobId) ?: return
        val failed = JobStatePolicy.transition(current, JobStatus.FAILED, now, error.message ?: error.javaClass.simpleName)
        store.save(if (willRetry) JobStatePolicy.transition(failed, JobStatus.QUEUED, now) else failed)
    }

    override suspend fun onJobCancelled(error: Throwable) {
        val now = System.currentTimeMillis()
        val current = store.read(jobId) ?: return
        if (current.status == JobStatus.RUNNING || current.status == JobStatus.PAUSED || current.status == JobStatus.QUEUED) {
            store.save(JobStatePolicy.transition(current, JobStatus.CANCELLED, now, error.message))
        }
    }
}
