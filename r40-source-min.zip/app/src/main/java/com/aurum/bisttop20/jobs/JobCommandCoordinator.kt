package com.aurum.bisttop20.jobs

import com.aurum.bisttop20.data.db.RoomJobExecutionStore
import com.aurum.bisttop20.domain.jobs.*

class JobCommandCoordinator(
    private val store: RoomJobExecutionStore,
    private val scheduler: JobScheduler
) {
    suspend fun pause(jobId: String, now: Long): JobSnapshot {
        val next = store.applyCommand(jobId, JobCommand.PAUSE, now)
        scheduler.cancel(next.module)
        return next
    }

    suspend fun resume(jobId: String, now: Long): JobSnapshot {
        val next = store.applyCommand(jobId, JobCommand.RESUME, now)
        scheduler.enqueue(next.module, next.jobId)
        return next
    }

    suspend fun cancel(jobId: String, now: Long): JobSnapshot {
        val current = requireNotNull(store.read(jobId))
        scheduler.cancel(current.module)
        return store.applyCommand(jobId, JobCommand.CANCEL, now)
    }

    suspend fun retry(jobId: String, now: Long): JobSnapshot {
        val next = store.applyCommand(jobId, JobCommand.RETRY, now)
        scheduler.enqueue(next.module, next.jobId)
        return next
    }

    suspend fun restart(jobId: String, now: Long): JobSnapshot {
        val next = store.applyCommand(jobId, JobCommand.RESTART, now)
        scheduler.enqueue(next.module, next.jobId)
        return next
    }
}
