package com.aurum.bisttop20

import android.app.Application
import com.aurum.bisttop20.data.db.DatabaseFactory
import com.aurum.bisttop20.data.db.RoomRiskStateStore
import com.aurum.bisttop20.data.db.RoomJobExecutionStore
import com.aurum.bisttop20.domain.risk.DailyLossAndKillSwitch
import com.aurum.bisttop20.domain.risk.RiskCommandService
import kotlinx.coroutines.launch
import com.aurum.bisttop20.jobs.JobScheduler
import com.aurum.bisttop20.jobs.JobCommandCoordinator

class AurumApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.IO).launch {
            jobStore.recoverAfterProcessDeath(System.currentTimeMillis())
        }
    }
    val database by lazy { DatabaseFactory.create(this) }
    val jobStore by lazy { RoomJobExecutionStore(database.jobExecutionDao()) }
    val riskStore by lazy { RoomRiskStateStore(database.riskControlDao()) }
    val riskCommands by lazy { RiskCommandService(riskStore, DailyLossAndKillSwitch()) }
    val jobScheduler by lazy { JobScheduler(this) }
    val jobCommands by lazy { JobCommandCoordinator(jobStore, jobScheduler) }
}
