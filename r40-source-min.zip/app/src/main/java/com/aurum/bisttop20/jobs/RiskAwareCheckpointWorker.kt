package com.aurum.bisttop20.jobs

import android.content.Context
import androidx.work.WorkerParameters
import com.aurum.bisttop20.domain.risk.RiskControlState
import com.aurum.bisttop20.domain.risk.RiskExecutionGate

/**
 * A worker must check risk state before staging and immediately before atomic publication.
 * PAUSED/KILLED jobs fail closed and must not publish partial data.
 */
abstract class RiskAwareCheckpointWorker(
    context: Context,
    params: WorkerParameters
) : CheckpointWorker(context, params) {
    private val gate = RiskExecutionGate()
    protected abstract suspend fun currentRiskState(): RiskControlState

    protected suspend fun ensureRiskAllowsExecution() {
        gate.requireExecutionAllowed(currentRiskState())
    }

    final override suspend fun stage(): String {
        ensureRiskAllowsExecution()
        return stageRiskAware()
    }

    final override suspend fun publishAtomically(stagingId: String) {
        ensureRiskAllowsExecution()
        publishRiskAware(stagingId)
    }

    protected abstract suspend fun stageRiskAware(): String
    protected abstract suspend fun publishRiskAware(stagingId: String)
}
