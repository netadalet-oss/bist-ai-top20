package com.aurum.bisttop20

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.aurum.bisttop20.domain.risk.RiskControlState
import com.aurum.bisttop20.domain.risk.RiskControlUiMapper
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private val scope = MainScope()
    private val app: AurumApplication get() = application as AurumApplication
    private lateinit var status: TextView
    private lateinit var killButton: Button
    private lateinit var resumeButton: Button
    private lateinit var jobsStatus: TextView
    private lateinit var pauseJobButton: Button
    private lateinit var resumeJobButton: Button
    private lateinit var cancelJobButton: Button
    private var selectedJobId: String? = null
    private var selectedJobStatus: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildRiskControlScreen())
        scope.launch {
            app.riskStore.observe().collectLatest(::render)
        }
        scope.launch {
            app.jobStore.observeAll().collectLatest { jobs ->
                val selected = jobs.firstOrNull { it.status in setOf("RUNNING", "PAUSED", "QUEUED", "FAILED") }
                selectedJobId = selected?.jobId
                selectedJobStatus = selected?.status
                jobsStatus.text = if (jobs.isEmpty()) "İş kaydı yok" else jobs.take(8).joinToString("\n") { j ->
                    val remaining = j.remainingRecords?.let { " kalan:$it" } ?: ""
                    "${j.module}: ${j.status} %${(j.progress * 100).toInt()}$remaining"
                }
                renderJobButtons()
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun buildRiskControlScreen(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(40, 64, 40, 40)
        addView(TextView(context).apply { text = "Aurum BIST Top 20"; textSize = 26f })
        addView(TextView(context).apply { text = "Risk Kontrol Merkezi"; textSize = 20f })
        status = TextView(context).apply { textSize = 18f; setPadding(0, 48, 0, 32) }
        addView(status)
        killButton = Button(context).apply {
            text = "ACİL DURDUR"
            setOnClickListener { requestKill() }
        }
        addView(killButton)
        resumeButton = Button(context).apply {
            text = "KONTROLLÜ YENİDEN BAŞLAT"
            setOnClickListener { requestResume() }
        }
        addView(resumeButton)
        addView(TextView(context).apply {
            text = "Risk durumu ACTIVE değilken veri işleri ve atomik yayın kapalıdır."
            setPadding(0, 32, 0, 0)
        })
        jobsStatus = TextView(context).apply {
            text = "İş durumları yükleniyor…"
            setPadding(0, 32, 0, 0)
        }
        addView(jobsStatus)
        pauseJobButton = Button(context).apply { text = "İŞİ DURAKLAT"; setOnClickListener { commandSelectedJob("pause") } }
        resumeJobButton = Button(context).apply { text = "İŞE DEVAM ET"; setOnClickListener { commandSelectedJob("resume") } }
        cancelJobButton = Button(context).apply { text = "İŞİ İPTAL ET"; setOnClickListener { commandSelectedJob("cancel") } }
        addView(pauseJobButton); addView(resumeJobButton); addView(cancelJobButton)
        renderJobButtons()
    }

    private fun render(state: RiskControlState) {
        val ui = RiskControlUiMapper.map(state)
        status.text = "Durum: ${ui.statusText}"
        killButton.isEnabled = ui.mayKill
        resumeButton.isEnabled = ui.mayResume
    }

    private fun renderJobButtons() {
        if (!::pauseJobButton.isInitialized) return
        pauseJobButton.isEnabled = selectedJobStatus == "RUNNING"
        resumeJobButton.isEnabled = selectedJobStatus == "PAUSED"
        cancelJobButton.isEnabled = selectedJobStatus in setOf("RUNNING", "PAUSED", "QUEUED", "FAILED")
    }

    private fun commandSelectedJob(command: String) {
        val jobId = selectedJobId ?: return showMessage("Kontrol edilebilir iş bulunamadı")
        val actionName = when (command) { "pause" -> "duraklatmak"; "resume" -> "devam ettirmek"; else -> "iptal etmek" }
        AlertDialog.Builder(this)
            .setTitle("İş komutu")
            .setMessage("Seçili işi $actionName istediğinizi onaylıyor musunuz?")
            .setNegativeButton("Vazgeç", null)
            .setPositiveButton("Onayla") { _, _ ->
                scope.launch {
                    runCatching {
                        val now = System.currentTimeMillis()
                        when (command) {
                            "pause" -> app.jobCommands.pause(jobId, now)
                            "resume" -> app.jobCommands.resume(jobId, now)
                            else -> app.jobCommands.cancel(jobId, now)
                        }
                    }.onFailure { showMessage(it.message ?: "İş komutu başarısız") }
                }
            }.show()
    }

    private fun requestKill() = reasonDialog("Acil durdurma gerekçesi") { reason ->
        scope.launch {
            runCatching { app.riskCommands.kill(System.currentTimeMillis(), "android-user", reason) }
                .onFailure { showMessage(it.message ?: "Acil durdurma başarısız") }
        }
    }

    private fun requestResume() = reasonDialog("Yeniden başlatma gerekçesi") { reason ->
        AlertDialog.Builder(this)
            .setTitle("İkinci onay")
            .setMessage("Risklerin giderildiğini ve sistemi yeniden etkinleştirmek istediğinizi onaylıyor musunuz?")
            .setNegativeButton("Vazgeç", null)
            .setPositiveButton("ONAYLIYORUM") { _, _ ->
                scope.launch {
                    runCatching {
                        app.riskCommands.resume(
                            System.currentTimeMillis(), "android-user", "android-user",
                            reason, explicitApproval = true
                        )
                    }.onFailure { showMessage(it.message ?: "Yeniden başlatma başarısız") }
                }
            }.show()
    }

    private fun reasonDialog(title: String, onSubmit: (String) -> Unit) {
        val input = EditText(this).apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setNegativeButton("Vazgeç", null)
            .setPositiveButton("Devam") { _, _ ->
                val reason = input.text.toString().trim()
                if (reason.isBlank()) showMessage("Gerekçe zorunludur") else onSubmit(reason)
            }.show()
    }

    private fun showMessage(message: String) = AlertDialog.Builder(this)
        .setMessage(message).setPositiveButton("Tamam", null).show()
}
