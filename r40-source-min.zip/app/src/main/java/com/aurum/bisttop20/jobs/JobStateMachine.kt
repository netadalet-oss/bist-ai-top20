package com.aurum.bisttop20.jobs

enum class JobStatus { WAITING, RUNNING, PAUSED, CANCELLED, FAILED, COMPLETED }
enum class JobCommand { START, PAUSE, RESUME, CANCEL, RETRY, RESTART }

/** Deterministic transition policy for UI controls and WorkManager orchestration. */
object JobStateMachine {
    fun transition(current: JobStatus, command: JobCommand): JobStatus = when (current to command) {
        JobStatus.WAITING to JobCommand.START -> JobStatus.RUNNING
        JobStatus.RUNNING to JobCommand.PAUSE -> JobStatus.PAUSED
        JobStatus.PAUSED to JobCommand.RESUME -> JobStatus.RUNNING
        JobStatus.RUNNING to JobCommand.CANCEL,
        JobStatus.PAUSED to JobCommand.CANCEL,
        JobStatus.WAITING to JobCommand.CANCEL -> JobStatus.CANCELLED
        JobStatus.FAILED to JobCommand.RETRY -> JobStatus.RUNNING
        JobStatus.COMPLETED to JobCommand.RESTART,
        JobStatus.CANCELLED to JobCommand.RESTART,
        JobStatus.FAILED to JobCommand.RESTART -> JobStatus.RUNNING
        else -> throw IllegalStateException("Invalid transition: $current + $command")
    }
}
