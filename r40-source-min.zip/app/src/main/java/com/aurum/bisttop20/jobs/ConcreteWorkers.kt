package com.aurum.bisttop20.jobs

import android.content.Context
import androidx.work.WorkerParameters
import com.aurum.bisttop20.AurumApplication
import com.aurum.bisttop20.data.adapters.*
import com.aurum.bisttop20.data.db.*
import com.aurum.bisttop20.domain.jobs.JobModule
import com.aurum.bisttop20.domain.staging.AdapterRecord
import com.aurum.bisttop20.network.ResilientHttpClient
import java.security.MessageDigest
import java.util.UUID

/** Common staging/publish implementation. No source can bypass Room staging. */
abstract class AtomicModuleWorker(context: Context, params: WorkerParameters) : TrackedDatabaseWorker(context, params) {
    protected val app get() = applicationContext as AurumApplication
    protected open suspend fun fetchRecords(): List<AdapterRecord> = emptyList()

    override suspend fun stageRiskAware(): String {
        ensureActiveJob()
        val records = fetchRecords()
        require(records.isNotEmpty()) { "SOURCE_RETURNED_NO_RECORDS:${module.name}" }
        val batchId = "${module.name.lowercase()}:${UUID.randomUUID()}"
        val cutoff = records.maxOf { it.availableForPredictionAt }
        val batch = StagingBatchEntity(batchId, module.name, System.currentTimeMillis(), cutoff, "OPEN", records.size, null, null, null)
        val rows = records.map { it.toEntity(batchId) }
        app.database.stagingDao().insertBatchAndRecords(batch, rows)
        val hash = payloadSetHash(records)
        check(app.database.stagingDao().markValidated(batchId, hash) == 1) { "STAGING_VALIDATE_TRANSITION_FAILED" }
        return batchId
    }

    override suspend fun validate(stagingId: String) {
        val dao = app.database.stagingDao()
        val batch = requireNotNull(dao.batch(stagingId))
        val rows = dao.records(stagingId)
        require(batch.state == "VALIDATED")
        require(rows.size == batch.expectedRecordCount) { "PARTIAL_BATCH" }
        require(rows.all { it.qualityDecision == "ACCEPT" }) { "QUALITY_GATE" }
    }

    override suspend fun publishRiskAware(stagingId: String) {
        ensureActiveJob()
        val dao = app.database.stagingDao()
        val batch = requireNotNull(dao.batch(stagingId))
        val token = "publish:$stagingId"
        if (dao.receipt(token) != null) return
        val now = System.currentTimeMillis()
        val receipt = PublishReceiptEntity(UUID.randomUUID().toString(), stagingId, token, batch.expectedRecordCount, requireNotNull(batch.validationHashSha256), now)
        dao.publishWithReceipt(receipt, stagingId, token, now)
    }

    private fun AdapterRecord.toEntity(batchId:String)=StagingRecordEntity(
        batchId,recordId,deduplicationKey,sourceId,sourceHashSha256,observedAt,acquiredAt,
        availableForPredictionAt,payloadBase64,payloadHashSha256,qualityDecision.name
    )
    private fun payloadSetHash(records:List<AdapterRecord>):String {
        val material=records.sortedBy{it.deduplicationKey}.joinToString("|"){"${it.deduplicationKey}:${it.payloadHashSha256}"}
        return MessageDigest.getInstance("SHA-256").digest(material.toByteArray()).joinToString(""){"%02x".format(it)}
    }
}

abstract class AdapterWorker(c:Context,p:WorkerParameters):AtomicModuleWorker(c,p){
    protected val http by lazy { ResilientHttpClient() }
}

class PriceCollectionWorker(c: Context, p: WorkerParameters) : AdapterWorker(c, p) {
    override val module = JobModule.PRICE_COLLECTION
    override suspend fun fetchRecords():List<AdapterRecord> {
        val symbols=(inputData.getString("symbols") ?: "THYAO,ASELS,AKBNK").split(',').map{it.trim().uppercase()}.filter{it.matches(Regex("[A-Z0-9]{2,10}"))}
        return IsYatirimPriceAdapter(symbols,http).fetch(Long.MAX_VALUE)
    }
}
class KapScanWorker(c: Context, p: WorkerParameters) : AdapterWorker(c, p) {
    override val module = JobModule.KAP_SCAN
    override suspend fun fetchRecords()=KapDisclosureAdapter(http).fetch(Long.MAX_VALUE)
}
class NewsScanWorker(c: Context, p: WorkerParameters) : AdapterWorker(c, p) {
    override val module = JobModule.NEWS_SCAN
    override suspend fun fetchRecords()=EconomyNewsRssAdapter(http).fetch(Long.MAX_VALUE)
}
class MacroCollectionWorker(c: Context, p: WorkerParameters) : AdapterWorker(c, p) {
    override val module = JobModule.MACRO_COLLECTION
    override suspend fun fetchRecords():List<AdapterRecord> {
        val key=inputData.getString("evdsApiKey").orEmpty()
        val series=inputData.getString("evdsSeries").orEmpty().split(',').map{it.trim()}.filter{it.isNotBlank()}
        return TcmbEvdsMacroAdapter(key,series,http).fetch(Long.MAX_VALUE)
    }
}
class FeatureComputationWorker(c: Context, p: WorkerParameters) : AtomicModuleWorker(c, p) { override val module = JobModule.FEATURE_COMPUTATION }
class FinalRankerWorker(c: Context, p: WorkerParameters) : AtomicModuleWorker(c, p) { override val module = JobModule.FINAL_RANKER }
class OutcomeLinkWorker(c: Context, p: WorkerParameters) : AtomicModuleWorker(c, p) { override val module = JobModule.PERFORMANCE_EVALUATION }
