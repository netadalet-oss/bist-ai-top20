package com.aurum.bisttop20.jobs

import android.content.Context
import androidx.work.WorkerParameters
import com.aurum.bisttop20.AurumApplication
import com.aurum.bisttop20.domain.risk.RiskControlState

abstract class DatabaseRiskAwareWorker(
    context: Context,
    params: WorkerParameters
) : RiskAwareCheckpointWorker(context, params) {
    final override suspend fun currentRiskState(): RiskControlState {
        val app = applicationContext as AurumApplication
        return app.riskStore.read()
    }
}
