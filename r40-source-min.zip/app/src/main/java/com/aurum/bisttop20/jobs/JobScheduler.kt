package com.aurum.bisttop20.jobs

import android.content.Context
import androidx.work.*
import com.aurum.bisttop20.domain.jobs.*
import java.util.concurrent.TimeUnit

class JobScheduler(context: Context) {
    private val workManager = WorkManager.getInstance(context)

    fun enqueue(module: JobModule, jobId: String, periodicMinutes: Long? = null) {
        val spec = WorkSchedulingPolicy.defaultFor(module).copy(periodicIntervalMinutes = periodicMinutes)
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(if (spec.requiresNetwork) NetworkType.CONNECTED else NetworkType.NOT_REQUIRED)
            .setRequiresBatteryNotLow(spec.requiresBatteryNotLow)
            .build()
        val data = workDataOf("jobId" to jobId, "module" to module.name)
        if (periodicMinutes != null) {
            val request = PeriodicWorkRequestBuilderFor(module, periodicMinutes, constraints, data)
            workManager.enqueueUniquePeriodicWork(spec.uniqueName, ExistingPeriodicWorkPolicy.UPDATE, request)
        } else {
            val request = OneTimeWorkRequestBuilderFor(module, constraints, data)
            workManager.enqueueUniqueWork(spec.uniqueName, spec.existingWorkRule.toAndroidPolicy(), request)
        }
    }

    fun cancel(module: JobModule) {
        workManager.cancelUniqueWork(WorkSchedulingPolicy.defaultFor(module).uniqueName)
    }

    private fun ExistingWorkRule.toAndroidPolicy(): ExistingWorkPolicy = when (this) {
        ExistingWorkRule.KEEP -> ExistingWorkPolicy.KEEP
        ExistingWorkRule.REPLACE -> ExistingWorkPolicy.REPLACE
        ExistingWorkRule.APPEND_OR_REPLACE -> ExistingWorkPolicy.APPEND_OR_REPLACE
    }

    private fun OneTimeWorkRequestBuilderFor(
        module: JobModule,
        constraints: Constraints,
        data: Data
    ): OneTimeWorkRequest = OneTimeWorkRequest.Builder(workerClass(module))
        .setConstraints(constraints)
        .setInputData(data)
        .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
        .addTag("aurum-job")
        .addTag("aurum-module:${module.name}")
        .build()

    private fun PeriodicWorkRequestBuilderFor(
        module: JobModule,
        intervalMinutes: Long,
        constraints: Constraints,
        data: Data
    ): PeriodicWorkRequest = PeriodicWorkRequest.Builder(
        workerClass(module), intervalMinutes, TimeUnit.MINUTES
    ).setConstraints(constraints).setInputData(data)
        .addTag("aurum-job")
        .addTag("aurum-module:${module.name}")
        .build()

    private fun workerClass(module: JobModule): Class<out ListenableWorker> = when (module) {
        JobModule.PRICE_COLLECTION -> PriceCollectionWorker::class.java
        JobModule.KAP_SCAN -> KapScanWorker::class.java
        JobModule.NEWS_SCAN -> NewsScanWorker::class.java
        JobModule.MACRO_COLLECTION -> MacroCollectionWorker::class.java
        JobModule.FEATURE_COMPUTATION -> FeatureComputationWorker::class.java
        JobModule.FINAL_RANKER -> FinalRankerWorker::class.java
        JobModule.PERFORMANCE_EVALUATION -> OutcomeLinkWorker::class.java
        else -> GenericModuleWorker::class.java
    }
}

class GenericModuleWorker(c: Context, p: WorkerParameters) : AtomicModuleWorker(c, p) {
    override val module: JobModule = runCatching {
        JobModule.valueOf(inputData.getString("module") ?: "REPORTING")
    }.getOrDefault(JobModule.REPORTING)
}
