package com.aurum.bisttop20.jobs

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/** Publish only after a complete staging pass; cancellation is cooperative and observable. */
abstract class CheckpointWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    protected fun ensureActiveJob() { if (isStopped) throw InterruptedException("Worker cancelled") }
    protected abstract suspend fun stage(): String
    protected abstract suspend fun validate(stagingId: String)
    protected abstract suspend fun publishAtomically(stagingId: String)
    protected open suspend fun onJobStarted() {}
    protected open suspend fun onJobCheckpoint(stagingId: String) {}
    protected open suspend fun onJobCompleted() {}
    protected open suspend fun onJobFailed(error: Throwable, willRetry: Boolean) {}
    protected open suspend fun onJobCancelled(error: Throwable) {}

    final override suspend fun doWork(): Result {
        return try {
            onJobStarted()
            ensureActiveJob()
            val id = stage()
            onJobCheckpoint(id)
            ensureActiveJob()
            validate(id)
            ensureActiveJob()
            publishAtomically(id)
            onJobCompleted()
            Result.success()
        } catch (e: InterruptedException) {
            onJobCancelled(e)
            Result.failure()
        } catch (e: Exception) {
            onJobFailed(e, runAttemptCount < 3)
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }
}
