package com.aurum.bisttop20.core

/** Epoch milliseconds are used in persistence to keep Room migrations deterministic. */
typealias EpochMillis = Long
