package com.aurum.bisttop20.domain.events

sealed interface EventDecision {
    data class AcceptNew(val event: CanonicalEvent) : EventDecision
    data class AcceptRevision(val event: CanonicalEvent) : EventDecision
    data class Duplicate(val existingEventId: String) : EventDecision
    data class Reject(val reasons: Set<String>) : EventDecision
}

class EventIngestionGate {
    fun evaluate(candidate: CanonicalEvent, existingByFingerprint: CanonicalEvent? = null): EventDecision {
        val errors = linkedSetOf<String>()
        if (!candidate.provenance.sourceHashSha256.matches(Regex("[0-9a-fA-F]{64}"))) errors += "INVALID_SOURCE_HASH"
        if (!candidate.contentFingerprintSha256.matches(Regex("[0-9a-fA-F]{64}"))) errors += "INVALID_CONTENT_FINGERPRINT"
        if (candidate.body.isBlank()) errors += "EMPTY_BODY"
        if (candidate.firstPublishedAt > candidate.provenance.observedAt) errors += "OBSERVED_BEFORE_PUBLISHED"
        if (candidate.provenance.observedAt > candidate.provenance.acquiredAt) errors += "ACQUIRED_BEFORE_OBSERVED"
        if (candidate.updatedAt != null && candidate.updatedAt < candidate.firstPublishedAt) errors += "UPDATE_BEFORE_FIRST_PUBLICATION"
        if (candidate.kind == EventKind.MACRO && candidate.referencePeriod.isNullOrBlank()) errors += "MISSING_REFERENCE_PERIOD"
        if (candidate.severity != null && candidate.severity !in 0.0..1.0) errors += "INVALID_SEVERITY"
        if (candidate.novelty != null && candidate.novelty !in 0.0..1.0) errors += "INVALID_NOVELTY"
        if (candidate.pricedIn != null && candidate.pricedIn !in 0.0..1.0) errors += "INVALID_PRICED_IN"
        if (errors.isNotEmpty()) return EventDecision.Reject(errors)
        if (existingByFingerprint == null) return EventDecision.AcceptNew(candidate)
        if (candidate.parentEventId == existingByFingerprint.eventId && candidate.revisionType != RevisionType.ORIGINAL) {
            return EventDecision.AcceptRevision(candidate)
        }
        return EventDecision.Duplicate(existingByFingerprint.eventId)
    }
}

class AiInterpretationGate {
    fun validate(value: AiInterpretation, event: CanonicalEvent): Set<String> {
        val errors = linkedSetOf<String>()
        if (value.eventId != event.eventId) errors += "EVENT_ID_MISMATCH"
        if (value.confidence !in 0.0..1.0) errors += "INVALID_CONFIDENCE"
        if (value.inputCutoffAt > value.requestedAt) errors += "CUTOFF_AFTER_REQUEST"
        if (value.inputCutoffAt < event.firstPublishedAt) errors += "CUTOFF_BEFORE_EVENT"
        if (value.model.isBlank()) errors += "MISSING_MODEL"
        if (value.outputVersion.isBlank()) errors += "MISSING_OUTPUT_VERSION"
        if (value.structuredOutputJson.isBlank()) errors += "EMPTY_OUTPUT"
        return errors
    }
}
