package com.aurum.bisttop20.domain.events

fun main() {
    val hash = "a".repeat(64)
    val fp = EventFingerprint.sha256(EventKind.NEWS, "src", "Başlık", "Aynı haber", 1000)
    val base = CanonicalEvent("e1", EventKind.NEWS, "i1", "AAA", "EARNINGS", "Başlık", "Aynı haber", 1000, null, null, null, null, null, null, Direction.POSITIVE, .8, .9, .2, 120, fp, SourceProvenance("src", hash, 1000, 1010, 1020), RevisionType.ORIGINAL)
    check(EventIngestionGate().evaluate(base) is EventDecision.AcceptNew)
    check(EventIngestionGate().evaluate(base.copy(eventId="e2"), base) is EventDecision.Duplicate)
    val rev = base.copy(eventId="e3", updatedAt=1200, revisionType=RevisionType.CORRECTION, parentEventId="e1")
    check(EventIngestionGate().evaluate(rev, base) is EventDecision.AcceptRevision)
    val ai = AiInterpretation("ai1","e1","model-x",1300,1200,.7,listOf("src"),"1","{}")
    check(AiInterpretationGate().validate(ai, base).isEmpty())
    println("R31_EVENT_SYSTEM_PASS")
}
