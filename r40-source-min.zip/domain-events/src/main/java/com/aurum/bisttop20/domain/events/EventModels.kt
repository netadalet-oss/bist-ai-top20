package com.aurum.bisttop20.domain.events

import java.security.MessageDigest

enum class EventKind { KAP_DISCLOSURE, NEWS, MACRO }
enum class Direction { POSITIVE, NEGATIVE, NEUTRAL, MIXED, UNKNOWN }
enum class RevisionType { ORIGINAL, CORRECTION, UPDATE, REVISION }

data class SourceProvenance(
    val sourceId: String,
    val sourceHashSha256: String,
    val publishedAt: Long,
    val observedAt: Long,
    val acquiredAt: Long
)

data class CanonicalEvent(
    val eventId: String,
    val kind: EventKind,
    val instrumentId: String?,
    val symbol: String?,
    val eventType: String,
    val title: String?,
    val body: String,
    val firstPublishedAt: Long,
    val updatedAt: Long?,
    val referencePeriod: String?,
    val initiallyReportedValue: Double?,
    val revisedValue: Double?,
    val expectation: Double?,
    val surprise: Double?,
    val direction: Direction,
    val severity: Double?,
    val novelty: Double?,
    val pricedIn: Double?,
    val estimatedImpactMinutes: Long?,
    val contentFingerprintSha256: String,
    val provenance: SourceProvenance,
    val revisionType: RevisionType,
    val parentEventId: String? = null,
    val attachmentHashes: List<String> = emptyList()
)

data class AiInterpretation(
    val interpretationId: String,
    val eventId: String,
    val model: String,
    val requestedAt: Long,
    val inputCutoffAt: Long,
    val confidence: Double,
    val sourceIds: List<String>,
    val outputVersion: String,
    val structuredOutputJson: String,
    val tokenInput: Long? = null,
    val tokenOutput: Long? = null,
    val costMicros: Long? = null
)

object EventFingerprint {
    private fun normalized(s: String): String = s.lowercase().replace(Regex("\\s+"), " ").trim()
    fun sha256(kind: EventKind, sourceId: String, title: String?, body: String, firstPublishedAt: Long): String {
        val material = listOf(kind.name, sourceId, title.orEmpty(), body, firstPublishedAt.toString())
            .joinToString("|") { normalized(it) }
        return MessageDigest.getInstance("SHA-256").digest(material.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}
