#!/usr/bin/env bash
set -euo pipefail
: "${1:?unsigned apk}"; : "${2:?signed apk}"
: "${AURUM_KEYSTORE_PATH:?required}"; : "${AURUM_KEYSTORE_PASSWORD:?required}"
: "${AURUM_KEY_ALIAS:=aurum-release}"; : "${AURUM_KEY_PASSWORD:=$AURUM_KEYSTORE_PASSWORD}"
TMP="${2%.apk}.aligned.apk"
zipalign -f -p 4 "$1" "$TMP"
apksigner sign --ks "$AURUM_KEYSTORE_PATH" --ks-pass env:AURUM_KEYSTORE_PASSWORD \
 --ks-key-alias "$AURUM_KEY_ALIAS" --key-pass env:AURUM_KEY_PASSWORD \
 --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true --out "$2" "$TMP"
apksigner verify --verbose --print-certs "$2" | tee "${2}.signature.txt"
sha256sum "$2" | tee "${2}.sha256"
rm -f "$TMP"
