#!/usr/bin/env bash
set -euo pipefail
: "${ANDROID_HOME:?ANDROID_HOME required}"
: "${AURUM_STORE_FILE:?AURUM_STORE_FILE required}"
: "${AURUM_STORE_PASSWORD:?AURUM_STORE_PASSWORD required}"
: "${AURUM_KEY_ALIAS:?AURUM_KEY_ALIAS required}"
: "${AURUM_KEY_PASSWORD:?AURUM_KEY_PASSWORD required}"
GRADLE_BIN=${GRADLE_BIN:-gradle}
BUILD_TOOLS=${BUILD_TOOLS:-35.0.0}
"$GRADLE_BIN" --no-daemon clean test assembleDebug assembleRelease bundleRelease
APK=$(find app/build/outputs/apk/release -name '*.apk' | head -1)
AAB=$(find app/build/outputs/bundle/release -name '*.aab' | head -1)
"$ANDROID_HOME/build-tools/$BUILD_TOOLS/apksigner" verify --verbose --print-certs "$APK" | tee APK_SIGNATURE_REPORT.txt
sha256sum "$APK" "$AAB" app/build/outputs/apk/debug/*.apk | tee RELEASE_SHA256.txt
if command -v adb >/dev/null && adb get-state >/dev/null 2>&1; then
  adb install -r "$APK"
  adb shell am force-stop com.aurum.bisttop20 || true
  adb shell monkey -p com.aurum.bisttop20 -c android.intent.category.LAUNCHER 1
  sleep 3
  adb logcat -d | grep -E 'FATAL EXCEPTION|AndroidRuntime' && exit 1 || true
fi
