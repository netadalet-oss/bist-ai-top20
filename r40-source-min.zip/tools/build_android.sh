#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
./tools/android_env_check.sh
chmod +x gradlew
./gradlew --no-daemon --stacktrace clean test :app:assembleDebug :app:assembleRelease :app:bundleRelease
sha256sum app/build/outputs/apk/debug/*.apk app/build/outputs/apk/release/*.apk app/build/outputs/bundle/release/*.aab
