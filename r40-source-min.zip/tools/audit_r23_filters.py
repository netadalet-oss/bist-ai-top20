from openpyxl import load_workbook
from pathlib import Path
from datetime import datetime,date,timedelta
import re,json,sys,hashlib
p=Path(sys.argv[1]); out=Path(sys.argv[2])
wb=load_workbook(p,data_only=True,read_only=False); ws=wb['Veriler']
def norm(v):
 s=re.sub(r'[\u200b\u200c\u200d\u2060\ufeff\n\r]','',str(v or '')).lower()
 tr=str.maketrans('ğüşıöç','gusioc'); s=s.translate(tr)
 return re.sub(r'[^a-z0-9%]+','',s)
H=[norm(c.value) for c in ws[1]]; idx={h:i for i,h in enumerate(H)}
def val(r,*aliases):
 for a in aliases:
  k=norm(a)
  if k in idx:return r[idx[k]]
 return None
def num(v):
 if v is None or v=='':return None
 if isinstance(v,(int,float)): return float(v) if abs(float(v))!=float('inf') else None
 try:return float(str(v).replace('.','').replace(',','.'))
 except:return None
def dt(v):
 if isinstance(v,datetime):return v.date()
 if isinstance(v,date):return v
 s=str(v or '').strip()
 for f in ('%d-%m-%Y','%d.%m.%Y','%Y-%m-%d'):
  try:return datetime.strptime(s,f).date()
  except:pass
 return None
ref=date(2026,7,22); tm2=date(2026,7,20)
critical=[('Kapanis_T0','Kapanis_T'),('EMA20_T0','EMA20'),('EMA50_T0','EMA50'),('EMA200_T0','EMA200'),('RSI14_T0','RSI14'),('Volatilite5G_T0','Vol5'),('Volatilite21G_T0','Vol21'),('Volatilite63G_T0','Vol63'),('Hacim_T0','Hacim_T'),('F/K_T0','F_K'),('PD/DD_T0','PDDD'),('Beta_T0','Beta'),('ROE_T0','ROE')]
counts={}; accepted=[]; rejected=[]
for r in ws.iter_rows(min_row=2,values_only=True):
 sym=str(val(r,'Hisse','Sembol','Kod') or '').strip()
 if not sym:continue
 reasons=[]
 dm=num(val(r,'AnlikDegisim%','AnlikDegisim(%)','AnlikDegisim%_T0')); tm=num(val(r,'FiyatDegisim%_T0','FiyatDegisim(%)_T0','FiyatDegisim%_T'))
 if (dm is not None and abs(dm)>=15) or (tm is not None and abs(tm)>=15):reasons.append('EXTREME_MOVE')
 missing=0
 for aliases in critical:
  exists=any(norm(a) in idx for a in aliases)
  if exists and num(val(r,*aliases)) is None: missing+=1
 if missing>=3:reasons.append(f'MISSING_CRITICAL_{missing}')
 d=dt(val(r,'KapanisTarihi_T0','KapanisTarihi_T'))
 if d and d<tm2:reasons.append('STALE_T0')
 if reasons:
  rejected.append({'symbol':sym,'reasons':reasons})
  for x in reasons: counts[x]=counts.get(x,0)+1
 else: accepted.append(sym)
report={'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'reference_t0':str(ref),'t_minus_2':str(tm2),'total':len(accepted)+len(rejected),'accepted':len(accepted),'rejected':len(rejected),'reason_counts':counts,'accepted_symbols_first50':accepted[:50],'rejected_first50':rejected[:50]}
out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:report[k] for k in ('total','accepted','rejected','reason_counts')},ensure_ascii=False))
