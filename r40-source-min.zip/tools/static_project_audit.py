#!/usr/bin/env python3
import json, re, sys
from pathlib import Path
root=Path(sys.argv[1])
checks={}
text='\n'.join(p.read_text(errors='ignore') for p in root.rglob('*.kt'))
entities=re.findall(r'@Entity\(tableName="([^"]+)"', text)
required=['instruments','symbol_history','trading_calendar','market_snapshots','price_bars','order_book_snapshots','corporate_actions','kap_disclosures','news_events','macro_observations','fundamental_observations','feature_snapshots','stock_dna_profiles','market_regimes','prediction_runs','prediction_items','prediction_revisions','actual_outcomes','trade_cost_estimates','model_versions','feature_versions','universe_versions','data_sources','source_health','source_conflicts','data_quality_issues','job_executions','audit_events','champion_challenger_evaluations']
checks['required_room_tables']={'pass':set(required)<=set(entities),'missing':sorted(set(required)-set(entities)),'count':len(set(entities))}
checks['no_prediction_update_dao']={'pass':not bool(re.search(r'@Update|DELETE FROM prediction_(runs|items)|UPDATE prediction_(runs|items)', (root/'app/src/main/java/com/aurum/bisttop20/data/db/PredictionDao.kt').read_text(), re.I))}
checks['sql_immutability_triggers']={'pass':'prediction_runs_no_update' in text and 'prediction_items_no_delete' in text}
checks['model_activation_gate']={'pass':'object ModelActivationPolicy' in text and 'ModelStage.ACCEPTED' in text}
checks['point_in_time_gate']={'pass':'PointInTimeGuard' in text and 'dataCutoffTimestamp' in text}
checks['cleartext_disabled']={'pass':'cleartextTrafficPermitted="false"' in (root/'app/src/main/res/xml/network_security_config.xml').read_text()}
checks['backup_disabled']={'pass':'android:allowBackup="false"' in (root/'app/src/main/AndroidManifest.xml').read_text()}
checks['overall_pass']=all(v.get('pass',True) for v in checks.values() if isinstance(v,dict))
print(json.dumps(checks,ensure_ascii=False,indent=2))
sys.exit(0 if checks['overall_pass'] else 1)
