#!/usr/bin/env python3
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
checks={
 'locale_parser':(root/'data-excel/src/main/java/com/aurum/bisttop20/data/excel/LocaleNumberParser.kt').exists(),
 'quarantine':(root/'data-excel/src/main/java/com/aurum/bisttop20/data/excel/Quarantine.kt').exists(),
 'import_pipeline':(root/'data-excel/src/main/java/com/aurum/bisttop20/data/excel/ExcelImportPipeline.kt').exists(),
 'column_mapping':(root/'data-excel/src/main/java/com/aurum/bisttop20/data/excel/ColumnMapping.kt').exists(),
 'formula_inventory':(root/'docs/FORMULA_INVENTORY_R20.json').exists(),
 'runtime_validation':(root/'docs/R20_EXCEL_PIPELINE_VALIDATION.txt').read_text().strip()=='R20_EXCEL_PIPELINE_PASS',
}
result={'checks':checks,'pass':all(checks.values())}
print(json.dumps(result,indent=2))
raise SystemExit(0 if result['pass'] else 1)
