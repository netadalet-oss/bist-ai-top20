from pathlib import Path
import json,re,sys
r=Path(__file__).resolve().parents[1]
mods=["app","core-model","core-database","domain-quality","domain-prediction","data-excel"]
checks={"modules_present":all((r/m/'build.gradle.kts').exists() for m in mods),"settings_includes":all(f'":{m}"' in (r/'settings.gradle.kts').read_text() for m in mods),"room_entities_29":len(set(re.findall(r'@Entity\(tableName="([^"]+)"',(r/'core-database/src/main/java/com/aurum/bisttop20/data/db/Entities.kt').read_text())))==29,"append_repository":(r/'core-database/src/main/java/com/aurum/bisttop20/data/db/RepositoryContracts.kt').exists(),"excel_contract":(r/'data-excel/src/main/java/com/aurum/bisttop20/data/excel/ExcelSchemaContract.kt').exists(),"no_prediction_update":'@Update' not in (r/'core-database/src/main/java/com/aurum/bisttop20/data/db/PredictionDao.kt').read_text()}
out={"release":"R19","checks":checks,"pass":all(checks.values())}; print(json.dumps(out,indent=2)); sys.exit(0 if out['pass'] else 1)
