#!/usr/bin/env python3
import json, re, sys, zipfile
from collections import Counter, defaultdict
from pathlib import Path
from xml.etree import ElementTree as ET
NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
PKG='http://schemas.openxmlformats.org/package/2006/relationships'

def inventory(path):
    with zipfile.ZipFile(path) as z:
        wb=ET.fromstring(z.read('xl/workbook.xml'))
        rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        targets={x.attrib['Id']:x.attrib['Target'] for x in rels.findall(f'{{{PKG}}}Relationship')}
        out={'file':str(path),'sheets':{},'total_formulas':0}
        for s in wb.find('m:sheets',NS):
            name=s.attrib['name']; rid=s.attrib[f'{{{NS["r"]}}}id']; target=targets[rid]
            if target.startswith('/'): target=target.lstrip('/')
            elif not target.startswith('xl/'): target='xl/'+target
            root=ET.fromstring(z.read(target))
            formulas=[]; functions=Counter(); refs=Counter()
            for c in root.findall('.//m:c',NS):
                f=c.find('m:f',NS)
                if f is None or not (f.text or '').strip(): continue
                expr=(f.text or '').strip(); formulas.append({'cell':c.attrib.get('r'),'formula':expr})
                for fn in re.findall(r'(?<![A-Z0-9_])([A-Z][A-Z0-9_.]+)\s*\(',expr.upper()): functions[fn]+=1
                for ref in re.findall(r"(?:'([^']+)'|([A-Za-z0-9_]+))!\$?[A-Z]{1,3}\$?\d+",expr): refs[(ref[0] or ref[1])]+=1
            out['sheets'][name]={'formula_count':len(formulas),'functions':dict(functions.most_common()),'sheet_references':dict(refs.most_common()),'examples':formulas[:30]}
            out['total_formulas']+=len(formulas)
        return out
if __name__=='__main__':
    result=[inventory(Path(p)) for p in sys.argv[1:]]
    print(json.dumps(result,ensure_ascii=False,indent=2))
