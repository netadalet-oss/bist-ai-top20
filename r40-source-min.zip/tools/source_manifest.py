#!/usr/bin/env python3
import csv, hashlib, os, sys
from datetime import datetime, timezone
from pathlib import Path

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def main(out, *inputs):
    acquired=datetime.now(timezone.utc).isoformat()
    rows=[]
    for raw in inputs:
        p=Path(raw)
        st=p.stat()
        rows.append({
            'source_id': hashlib.sha256(str(p.resolve()).encode()).hexdigest()[:16],
            'source_type': p.suffix.lower().lstrip('.') or 'file',
            'original_name': p.name,
            'observed_name': p.name,
            'drive_file_id': '',
            'sha256': sha256(p),
            'file_size': st.st_size,
            'modified_timestamp': datetime.fromtimestamp(st.st_mtime, timezone.utc).isoformat(),
            'acquired_timestamp': acquired,
            'schema_version': '1',
            'accessibility_status': 'LOCAL_READABLE',
        })
    with open(out,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
if __name__=='__main__': main(*sys.argv[1:])
