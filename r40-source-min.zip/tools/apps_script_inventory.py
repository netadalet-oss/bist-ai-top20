#!/usr/bin/env python3
import re, json, hashlib, csv
from pathlib import Path
src=Path('/mnt/data/V_141225.txt')
out=Path(__file__).resolve().parents[1]/'docs'
text=src.read_text(encoding='utf-8-sig', errors='replace')
# Function declarations and variable-assigned functions
pat=re.compile(r'(?m)^\s*(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(([^)]*)\)\s*\{')
funcs=[]
for m in pat.finditer(text):
    name=m.group(1); params=[x.strip() for x in m.group(2).split(',') if x.strip()]
    start=m.start(); brace=text.find('{',m.end()-1); depth=0; end=len(text)
    for i in range(brace,len(text)):
        if text[i]=='{': depth+=1
        elif text[i]=='}':
            depth-=1
            if depth==0: end=i+1; break
    body=text[brace+1:end-1]
    funcs.append({'name':name,'params':params,'line':text.count('\n',0,start)+1,'body':body})
names={f['name'] for f in funcs}
call_re=re.compile(r'\b([A-Za-z_$][\w$]*)\s*\(')
for f in funcs:
    calls=sorted({c for c in call_re.findall(f['body']) if c in names and c!=f['name']})
    f['calls']=calls
    f['body_sha256']=hashlib.sha256(f['body'].encode()).hexdigest()
    del f['body']
urls=sorted(set(re.findall(r'https?://[^\s\'"`]+',text)))
services=sorted(set(re.findall(r'\b(SpreadsheetApp|PropertiesService|UrlFetchApp|ScriptApp|Utilities|LockService|CacheService|DriveApp)\b',text)))
summary={'source_file':src.name,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'size':src.stat().st_size,'function_count':len(funcs),'functions':funcs,'external_urls':urls,'google_services':services}
(out/'APPS_SCRIPT_INVENTORY_R21.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
with (out/'APPS_SCRIPT_FUNCTIONS_R21.csv').open('w',newline='',encoding='utf-8') as fh:
    w=csv.writer(fh); w.writerow(['function','line','parameters','calls','body_sha256'])
    for f in funcs:w.writerow([f['name'],f['line'],'|'.join(f['params']),'|'.join(f['calls']),f['body_sha256']])
# Graphviz DOT
with (out/'APPS_SCRIPT_DEPENDENCY_GRAPH_R21.dot').open('w',encoding='utf-8') as fh:
    fh.write('digraph AppsScript {\n  rankdir=LR;\n')
    for f in funcs: fh.write(f'  "{f["name"]}";\n')
    for f in funcs:
        for c in f['calls']: fh.write(f'  "{f["name"]}" -> "{c}";\n')
    fh.write('}\n')
print(json.dumps({'functions':len(funcs),'urls':len(urls),'services':services},ensure_ascii=False))
