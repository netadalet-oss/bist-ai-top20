#!/usr/bin/env bash
set -euo pipefail
for c in java adb zipalign apksigner; do command -v "$c" >/dev/null || { echo "MISSING:$c"; exit 2; }; done
: "${ANDROID_SDK_ROOT:?ANDROID_SDK_ROOT required}"
test -f gradle/wrapper/gradle-wrapper.jar || { echo 'MISSING:gradle-wrapper.jar'; exit 2; }
echo ANDROID_ENV_OK
