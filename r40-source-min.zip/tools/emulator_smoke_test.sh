#!/usr/bin/env bash
set -euo pipefail
: "${1:?apk path}"
adb wait-for-device
adb install -r "$1"
adb shell am force-stop com.aurum.bisttop20.debug || true
adb shell monkey -p com.aurum.bisttop20.debug -c android.intent.category.LAUNCHER 1
sleep 5
adb shell pidof com.aurum.bisttop20.debug
adb logcat -d -t 500 | grep -E 'FATAL EXCEPTION|AndroidRuntime' && exit 3 || true
echo EMULATOR_SMOKE_PASS
