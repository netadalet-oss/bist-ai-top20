#!/usr/bin/env bash
set -euo pipefail
: "${AURUM_KEYSTORE_PATH:?required}"
: "${AURUM_KEYSTORE_PASSWORD:?required}"
: "${AURUM_KEY_ALIAS:=aurum-release}"
: "${AURUM_KEY_PASSWORD:=$AURUM_KEYSTORE_PASSWORD}"
keytool -genkeypair -v -keystore "$AURUM_KEYSTORE_PATH" -storepass "$AURUM_KEYSTORE_PASSWORD" \
 -alias "$AURUM_KEY_ALIAS" -keypass "$AURUM_KEY_PASSWORD" -keyalg RSA -keysize 4096 -validity 9125 \
 -dname "CN=Aurum BIST Top 20, OU=Release, O=Aurum, L=Istanbul, C=TR"
