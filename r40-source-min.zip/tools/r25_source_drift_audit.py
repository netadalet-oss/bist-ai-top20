from pathlib import Path
import re,json,hashlib,sys
source=Path(sys.argv[1]).read_text(encoding='utf-8-sig')
root=Path(sys.argv[2]); out=root/'docs';out.mkdir(exist_ok=True)
def body(name):
 m=re.search(r'function\s+'+re.escape(name)+r'\s*\([^)]*\)\s*\{',source)
 if not m:return ''
 i=m.end();d=1;j=i
 while j<len(source) and d:
  if source[j]=='{':d+=1
  elif source[j]=='}':d-=1
  j+=1
 return source[i:j-1]
reader=body('KS_readVerilerAsObjects_')
models={k:body('KS_build_'+k) for k in ['K1','K2']}
fields={
 'vol63':{'consumers':['K1']},'hacimdeg':{'consumers':['K1']},'hacimdeg_T':{'consumers':['K1']},'momentum10':{'consumers':['K2']}
}
for f,v in fields.items():
 v['referenced']=any(re.search(r'\bo\.'+re.escape(f)+r'\b',models[k]) for k in v['consumers'])
 v['populated_in_reader']=bool(re.search(r'(^|[,{\n]\s*)'+re.escape(f)+r'\s*:',reader))
 v['status']='OK' if v['populated_in_reader'] else 'REFERENCED_BUT_UNPOPULATED'
report={
 'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
 'reader_function':'KS_readVerilerAsObjects_',
 'fields':fields,
 'conclusion':'CURRENT_SOURCE_CANNOT_REPRODUCE_WORKBOOK_K1_K2_AS_IS' if any(not x['populated_in_reader'] for x in fields.values()) else 'NO_FIELD_DRIFT_FOUND',
 'stale_rule':{'reader':'date <= T-2 is rejected','global_filter':'date < T-2 is rejected','effective_behavior':'reader <= rule applies first'}
}
(out/'SOURCE_OUTPUT_DRIFT_R25.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
