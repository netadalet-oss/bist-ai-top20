from openpyxl import load_workbook
from pathlib import Path
import csv,json,re,hashlib,sys
src=Path(sys.argv[1]); out=Path(sys.argv[2]); out.mkdir(parents=True,exist_ok=True)
wb=load_workbook(src,data_only=True,read_only=False)
def norm(v): return re.sub(r'[\u200b\u200c\u200d\u2060\ufeff\n\r]','',str(v or '')).strip()
ws=wb['Veriler']; headers=[norm(c.value) for c in ws[1]]
selected=['Hisse','VeriZamani','Anlik','AnlikDegisim%','Degisim3Gun(%)_T0','Destekler(3)_T0','Direncler(3)_T0','KapanisTarihi_T0','FiyatDegisim%_T0','Kapanis_T0','Hacim_T0','HacimDegisim%_T0','EMA20_T0','EMA50_T0','EMA200_T0','MACDHist_T0','RSI14_T0','Momentum10_T0','Volatilite5G_T0','Volatilite21G_T0','Volatilite63G_T0']
idx={h:i for i,h in enumerate(headers)}
rows=[]
for r in ws.iter_rows(min_row=2,values_only=True):
    sym=r[idx['Hisse']] if 'Hisse' in idx else None
    if not sym: continue
    d={k:(r[idx[k]] if k in idx else None) for k in selected}
    for k,v in list(d.items()):
        if hasattr(v,'isoformat'): d[k]=v.isoformat()
    rows.append(d)
    if len(rows)>=100: break
(out/'veriler_first100.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
for sheet in ['K1','K2','K3','K4','K5']:
    sh=wb[sheet]; hdr=[norm(c.value) for c in sh[1]]
    sym_i=hdr.index('Hisse'); score_i=hdr.index('Skor')
    vals=[]
    for rank,r in enumerate(sh.iter_rows(min_row=2,values_only=True),1):
        if not r[sym_i]: continue
        vals.append({'rank':rank,'symbol':r[sym_i],'score':r[score_i]})
    (out/f'{sheet.lower()}_expected.json').write_text(json.dumps(vals,ensure_ascii=False,indent=2),encoding='utf-8')
manifest=[]
for p in sorted(out.glob('*.json')):
    manifest.append({'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('R23_FIXTURES_PASS',len(rows))
