from openpyxl import load_workbook
from pathlib import Path
import json, re, math, statistics, hashlib, sys

src=Path(sys.argv[1]); root=Path(sys.argv[2]); out=root/'docs'; out.mkdir(parents=True,exist_ok=True)
wb=load_workbook(src,data_only=True,read_only=True)

def norm(v):
    s=re.sub(r'[\u200b\u200c\u200d\u2060\ufeff\n\r]','',str(v or '')).strip().lower()
    tr=str.maketrans('ğüşıöç','gusioc'); s=s.translate(tr)
    s=re.sub(r'[()\[\]{}]','',s); s=re.sub(r'[_\-]+',' ',s); s=re.sub(r'\s+',' ',s).strip()
    return s

def key(v): return re.sub(r'[^a-z0-9%]+','',norm(v))
def num(v):
    if v is None or v=='': return None
    if isinstance(v,(int,float)) and not isinstance(v,bool): return float(v) if math.isfinite(float(v)) else None
    s=str(v).strip().replace('\u2060','')
    try: return float(s.replace(',','.'))
    except: return None

def q(xs,p):
    ys=sorted(x for x in xs if x is not None and math.isfinite(x))
    if not ys:return None
    pos=(len(ys)-1)*p;i=math.floor(pos);f=pos-i
    return ys[i]*(1-f)+ys[i+1]*f if i+1<len(ys) else ys[i]
def score1(vals,invert=False,low=.05,high=.95):
    lo=q(vals,low);hi=q(vals,high)
    if lo is None or hi is None:return [None]*len(vals)
    if abs(hi-lo)<1e-12:return [None if v is None else .5 for v in vals]
    out=[]
    for v in vals:
        if v is None or not math.isfinite(v):out.append(None);continue
        t=max(0,min(1,(v-lo)/(hi-lo)));out.append(1-t if invert else t)
    return out
def minmax(vals,invert=False):
    ys=[x for x in vals if x is not None and math.isfinite(x)]
    if not ys:return [None]*len(vals)
    lo=min(ys);hi=max(ys)
    if hi==lo:return [None if v is None else .5 for v in vals]
    return [None if v is None else (1-(v-lo)/(hi-lo) if invert else (v-lo)/(hi-lo)) for v in vals]
def avg(*cols):
    return [statistics.mean([c[i] for c in cols if c[i] is not None]) if any(c[i] is not None for c in cols) else None for i in range(len(cols[0]))]
def ties(base,*epscols):
    ep=avg(*epscols) if epscols else []
    buckets={}
    for i,v in enumerate(base): buckets.setdefault('NA' if v is None else f'{v:.4f}',[]).append(i)
    out=list(base)
    for ids in buckets.values():
        if len(ids)>1:
            for i in ids:
                if out[i] is not None and ep[i] is not None:out[i]+=ep[i]
    return out

ws=wb['Veriler']; headers=[str(c.value or '') for c in ws[1]]; by={key(h):i for i,h in enumerate(headers)}
def get(row,*aliases):
    for a in aliases:
        i=by.get(key(a))
        if i is not None:return row[i]
    return None
rows=[]
for rr in ws.iter_rows(min_row=2,values_only=True):
    sym=str(get(rr,'Hisse','Sembol','Kod') or '').strip()
    if not sym:continue
    # Apply audited exclusions from R23 using current source rules.
    an=num(get(rr,'AnlikDegisim%','AnlikDegisim(%)','AnlikDegisim%_T0')); fm=num(get(rr,'FiyatDegisim%_T0','FiyatDegisim(%)_T0'))
    critical=[('Kapanis_T0',),('EMA20_T0',),('EMA50_T0',),('EMA200_T0',),('RSI14_T0',),('Volatilite5G_T0',),('Volatilite21G_T0',),('Volatilite63G_T0',),('Hacim_T0',),('F/K_T0',),('PD/DD_T0',),('Beta_T0',),('ROE_T0',)]
    missing=sum(1 for aliases in critical if any(key(a) in by for a in aliases) and num(get(rr,*aliases)) is None)
    if (an is not None and abs(an)>=15) or (fm is not None and abs(fm)>=15) or missing>=3:continue
    def hist(prefix,maxlag=30):return [num(get(rr,f'{prefix}_T{i}',f'{prefix}T{i}')) for i in range(maxlag+1)]
    d={
      'symbol':sym,'vol5':num(get(rr,'Volatilite5G_T0')),'vol21':num(get(rr,'Volatilite21G_T0')),'vol63':num(get(rr,'Volatilite63G_T0')),
      'bu':num(get(rr,'Boll_Ust_T0','BollingerUst_T0')),'bl':num(get(rr,'Boll_Alt_T0','BollingerAlt_T0')),'close':num(get(rr,'Kapanis_T0')),
      'vchg':num(get(rr,'HacimDegisim%_T0')),'rsi':num(get(rr,'RSI14_T0')),'m3':num(get(rr,'Degisim3Gun(%)_T0')),'an':an,
      'e20':num(get(rr,'EMA20_T0')),'e50':num(get(rr,'EMA50_T0')),'e200':num(get(rr,'EMA200_T0')),'macd':num(get(rr,'MACDHist_T0')),'mom':num(get(rr,'Momentum10_T0')),
      'r1':num(get(rr,'Getiri_TL_1A_T0','Getiri1A(%)')),'r3':num(get(rr,'Getiri_TL_3A_T0','Getiri3A(%)')),'r6':num(get(rr,'Getiri_TL_6A_T0','Getiri6A(%)')),
      'hc':hist('Kapanis'),'chg':hist('FiyatDegisim%'),'hv':hist('HacimDegisim%')
    };rows.append(d)

def result(symbols,scores,n=24):
    return sorted([{'symbol':s,'score':round(v+1e-12,2)} for s,v in zip(symbols,scores) if v is not None],key=lambda x:-x['score'])[:n]
sy=[r['symbol'] for r in rows]
# K1
v5=[r['vol5'] for r in rows];v21=[r['vol21'] for r in rows];v63=[r['vol63'] for r in rows]
r1=[a/b if a is not None and b not in (None,0) else None for a,b in zip(v5,v21)];r2=[a/b if a is not None and b not in (None,0) else None for a,b in zip(v21,v63)]
rw=[(r['bu']-r['bl'])/abs(r['bu']) if r['bu'] not in (None,0) and r['bl'] is not None else None for r in rows]
near=[(r['close']-r['bl'])/(abs(r['bu']-r['bl']) or 1e-6) if None not in (r['close'],r['bl'],r['bu']) else None for r in rows]
rsi50=[abs(r['rsi']-50) if r['rsi'] is not None else None for r in rows];pf=[None if r['m3'] is None and r['an'] is None else float((r['m3'] or 0)>0)+float((r['an'] or 0)>0) for r in rows];vf=[None if r['vchg'] is None else float(r['vchg']>0) for r in rows]
sv5,sv21,sv63,sr1,sr2=[minmax(x) for x in [v5,v21,v63,r1,r2]];srange=minmax(rw);svchg=minmax([r['vchg'] for r in rows]);snear=minmax(near,True);srsi=minmax(rsi50,True);sm3=minmax([r['m3'] for r in rows]);san=minmax([r['an'] for r in rows]);spf=minmax(pf);svf=minmax(vf)
z=lambda x:0.0 if x is None else x
vs=[.35*z(sv5[i])+.35*z(sr1[i])+.15*z(sv21[i])+.10*z(sr2[i])+.05*z(sv63[i]) for i in range(len(rows))];dip=[.25*z(srange[i])+.35*z(svchg[i])+.40*z(snear[i]) for i in range(len(rows))];mom=[.50*z(sm3[i])+.35*z(san[i])+.15*z(srsi[i]) for i in range(len(rows))];up=avg(spf,svf);k1=result(sy,ties([(0.25*vs[i]+.20*dip[i]+.35*mom[i]+.20*z(up[i]))*100 for i in range(len(rows))],up,sm3))
# K2
stack=[1. if None not in (r['e20'],r['e50'],r['e200']) and r['e20']>r['e50']>r['e200'] else 0. for r in rows];g1=[r['e20']/r['e50']-1 if r['e20'] is not None and r['e50'] not in (None,0) else None for r in rows];g2=[r['e50']/r['e200']-1 if r['e50'] is not None and r['e200'] not in (None,0) else None for r in rows];rd=[abs(r['rsi']-55) if r['rsi'] is not None else None for r in rows]
ss,s1,s2,sm,sr,smo=[score1(x,inv) for x,inv in [(stack,False),(g1,False),(g2,False),([r['macd'] for r in rows],False),(rd,True),([r['mom'] for r in rows],False)]];k2=result(sy,ties([(.25*z(ss[i])+.20*z(s1[i])+.10*z(s2[i])+.25*z(sm[i])+.10*z(sr[i])+.10*z(smo[i]))*100 for i in range(len(rows))],sm,ss))
# K3
configs=[(10,3),(15,5),(20,7),(30,10)]
def detect(r,dw,rw):
    close,chg,vol=r['hc'],r['chg'],r['hv'];w=min(dw,len(close))
    if w<3 or close[0] is None:return None
    dips=[d for d in range(1,w-1) if None not in (close[d],close[d+1],close[d-1]) and close[d]<=close[d+1] and close[d]<=close[d-1]]
    di=min(dips) if dips else min((d for d in range(w) if close[d] is not None),key=lambda d:close[d],default=None)
    if di is None:return None
    peaks=[d for d in range(di+1,w) if close[d] is not None]
    if not peaks:return None
    pi=max(peaks,key=lambda d:close[d]);drop=(close[pi]-close[di])/close[pi]
    if drop<=.03:return None
    ri=None
    for off in range(1,min(rw,di)+1):
        d=di-off
        if None not in (close[d],chg[d],vol[d]) and chg[d]>0 and vol[d]>0 and close[d]>close[di]:ri=d;break
    if ri is None:return None
    return {'depth':drop,'bounce':close[0]/close[di]-1,'recency':float(ri),'vol':vol[ri]}
pat=None
for cfg in configs:
    cand=[detect(r,*cfg) for r in rows]
    if any(cand):pat=cand;break
if pat is None:pat=[detect(r,*configs[-1]) for r in rows]
sd,sb,srec,svol=[score1(x,inv) for x,inv in [([p['depth'] if p else None for p in pat],False),([p['bounce'] if p else None for p in pat],False),([p['recency'] if p else None for p in pat],True),([p['vol'] if p else None for p in pat],False)]]
k3=result(sy,ties([None if pat[i] is None else (.4*z(sd[i])+.3*z(sb[i])+.2*z(srec[i])+.1*z(svol[i]))*100 for i in range(len(rows))],sb,srec))
# K4
rr1=[r['r1'] for r in rows];rr3=[r['r3'] for r in rows];rr6=[r['r6'] for r in rows];stab=[r['vol21']/abs(r['r1']) if r['vol21'] is not None and r['r1'] not in (None,0) else None for r in rows]
sg1,sg3,sg6,sst=[score1(x,inv) for x,inv in [(rr1,False),(rr3,False),(rr6,False),(stab,True)]];pts=avg(sg1,sg3,sg6);eps=avg(score1([r['m3'] for r in rows]),score1([abs(r['rsi']-55) if r['rsi'] is not None else None for r in rows],True));k4=result(sy,ties([(.45*z(pts[i])+.30*z(sst[i])+.25*z(eps[i]))*100 for i in range(len(rows))],sg6,sst))
computed={'K1':k1,'K2':k2,'K3':k3,'K4':k4}
# K5 computed from workbook expected K1-K4 to isolate consensus parity.
pool={}
for name in ['K1','K2','K3','K4']:
    data=json.loads((root/'fixtures/r24'/f'{name.lower()}_expected_top20.json').read_text())
    for x in data:
        if x.get('score') is not None: pool.setdefault(x['symbol'],[]).append(float(x['score']))
k5=sorted([{'symbol':s,'score':round(statistics.mean(v),2)} for s,v in pool.items()],key=lambda x:-x['score'])[:24];computed['K5']=k5

report={'workbook':str(src),'universe_rows':len(rows),'models':{}}
for name,got in computed.items():
    exp=json.loads((root/'fixtures/r24'/f'{name.lower()}_expected_top20.json').read_text())
    em={x['symbol']:x for x in exp};gm={x['symbol']:x for x in got}
    overlap=set(em)&set(gm); top20_overlap=len(set(x['symbol'] for x in exp[:20])&set(x['symbol'] for x in got[:20]))
    score_diffs=[abs(float(em[s]['score'])-float(gm[s]['score'])) for s in overlap if em[s]['score'] is not None]
    rank_diffs=[abs(int(em[s]['rank'])-(next(i+1 for i,x in enumerate(got) if x['symbol']==s))) for s in overlap]
    report['models'][name]={
      'expected_count':len(exp),'computed_count':len(got),'symbol_overlap':len(overlap),'top20_overlap':top20_overlap,
      'exact_symbol_order': [x['symbol'] for x in exp]==[x['symbol'] for x in got[:len(exp)]],
      'max_abs_score_diff':max(score_diffs) if score_diffs else None,'mean_abs_score_diff':statistics.mean(score_diffs) if score_diffs else None,
      'mean_abs_rank_diff':statistics.mean(rank_diffs) if rank_diffs else None,
      'missing_expected_symbols':sorted(set(em)-set(gm)),'unexpected_symbols':sorted(set(gm)-set(em)),
      'computed_top24':got
    }
(out/'KMODEL_PARITY_AUDIT_R24.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(root/'fixtures/r24').mkdir(parents=True,exist_ok=True)
(root/'fixtures/r24'/'computed_outputs.json').write_text(json.dumps(computed,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:{z:v[z] for z in ['symbol_overlap','top20_overlap','exact_symbol_order','mean_abs_score_diff']} for k,v in report['models'].items()},ensure_ascii=False,indent=2))
