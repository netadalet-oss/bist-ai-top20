#!/usr/bin/env python3
"""Read-only OOXML audit. Uses only Python stdlib and never rewrites the workbook."""
from __future__ import annotations
import argparse, hashlib, json, re, unicodedata, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main", "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
REL_NS = {"p": "http://schemas.openxmlformats.org/package/2006/relationships"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def shared_strings(z: zipfile.ZipFile) -> list[str]:
    try: root = ET.fromstring(z.read("xl/sharedStrings.xml"))
    except KeyError: return []
    return ["".join(t.text or "" for t in si.findall(".//m:t", NS)) for si in root.findall("m:si", NS)]


def cell_text(cell: ET.Element, strings: list[str]) -> str:
    typ = cell.attrib.get("t")
    value = cell.find("m:v", NS)
    if typ == "inlineStr": return "".join(t.text or "" for t in cell.findall(".//m:t", NS))
    if value is None: return ""
    raw = value.text or ""
    if typ == "s" and raw.isdigit() and int(raw) < len(strings): return strings[int(raw)]
    return raw


def invisible_codepoints(text: str) -> list[str]:
    return sorted({f"U+{ord(ch):04X}" for ch in text if unicodedata.category(ch) in {"Cf", "Cc"} and ch not in "\t\r\n"})


def audit(path: Path) -> dict:
    with zipfile.ZipFile(path) as z:
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        targets = {x.attrib["Id"]: x.attrib["Target"] for x in rels.findall("p:Relationship", REL_NS)}
        strings = shared_strings(z)
        sheets = []
        for sh in wb.findall("m:sheets/m:sheet", NS):
            name = sh.attrib["name"]
            rid = sh.attrib[f"{{{NS['r']}}}id"]
            target = targets[rid].lstrip("/")
            if not target.startswith("xl/"): target = "xl/" + target
            root = ET.fromstring(z.read(target))
            rows = root.findall("m:sheetData/m:row", NS)
            first = rows[0] if rows else None
            headers = [cell_text(c, strings) for c in first.findall("m:c", NS)] if first is not None else []
            sheets.append({
                "name": name,
                "row_count_xml": len(rows),
                "header_count": len(headers),
                "headers": headers,
                "headers_with_invisible_unicode": [
                    {"header": h, "codepoints": invisible_codepoints(h)} for h in headers if invisible_codepoints(h)
                ],
            })
        return {"file": str(path), "size": path.stat().st_size, "sha256": sha256(path), "sheets": sheets}


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("workbooks", nargs="+")
    p.add_argument("--out", required=True)
    args = p.parse_args()
    reports = [audit(Path(x)) for x in args.workbooks]
    Path(args.out).write_text(json.dumps(reports, ensure_ascii=False, indent=2), encoding="utf-8")

if __name__ == "__main__": main()
