#!/usr/bin/env python3
import openpyxl, csv, json, hashlib, re
from pathlib import Path
out=Path(__file__).resolve().parents[1]/'docs'
files=[Path('/mnt/data/V_141225_r21.xlsx'),Path('/mnt/data/BIST_DNA_Nihai_Tum_Calismalar_2026-07-28.xlsx')]
rows=[]; summaries=[]
for fp in files:
    wb=openpyxl.load_workbook(fp, read_only=True, data_only=False)
    fs={'file':fp.name,'sha256':hashlib.sha256(fp.read_bytes()).hexdigest(),'sheets':[]}
    for ws in wb.worksheets:
        # pick first row among first 12 with maximum nonempty textual/numeric cells
        candidates=[]
        max_row = ws.max_row or 1
        for ri,row in enumerate(ws.iter_rows(min_row=1,max_row=min(12,max_row),values_only=True),1):
            vals=[v for v in row if v is not None and str(v).strip()!='']
            candidates.append((len(vals),ri,row))
        _,hr,header=max(candidates,key=lambda x:x[0]) if candidates else (0,1,())
        headers=[]
        for ci,v in enumerate(header,1):
            if v is None or str(v).strip()=='': continue
            raw=str(v); norm=re.sub('[\u200b\u200c\u200d\u2060\ufeff]','',raw).strip()
            headers.append({'column_index':ci,'raw':raw,'normalized':norm})
            rows.append([fp.name,fs['sha256'],ws.title,hr,ci,raw,norm,'inferred_header'])
        fs['sheets'].append({'name':ws.title,'max_row':ws.max_row or 0,'max_column':ws.max_column or 0,'inferred_header_row':hr,'header_count':len(headers),'headers':headers})
    summaries.append(fs)
(out/'WORKBOOK_DATA_DICTIONARY_R21.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2),encoding='utf-8')
with (out/'WORKBOOK_COLUMNS_R21.csv').open('w',newline='',encoding='utf-8') as fh:
    w=csv.writer(fh); w.writerow(['workbook','sha256','sheet','header_row','column_index','raw_header','normalized_header','status']);w.writerows(rows)
print(json.dumps({'workbooks':len(summaries),'sheets':sum(len(x['sheets']) for x in summaries),'columns':len(rows)}))
