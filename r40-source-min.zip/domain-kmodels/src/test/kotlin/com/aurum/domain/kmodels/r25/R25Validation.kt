package com.aurum.domain.kmodels.r25

import com.aurum.domain.kmodels.io.*
import java.time.LocalDate

fun main() {
    check(JsNumberSemantics.toFiniteDouble("2744.17") == 2744.17)
    check(JsNumberSemantics.toFiniteDouble("2.744,17") == null) // Number() does not parse locale text
    check(JsNumberSemantics.toFiniteDouble(12) == 12.0)
    check(LegacySourceFieldAudit.contracts.size == 4)
    val row=VerilerRow(mapOf("KapanisTarihi_T0" to "29-07-2026"))
    val ref=FilterReference(LocalDate.of(2026,7,31), LocalDate.of(2026,7,29))
    check(!GlobalFilterPolicy.evaluate(row,ref).accepted)
    println("R25_SOURCE_COMPATIBILITY_PASS")
}
