package com.aurum.domain.kmodels.r23
import com.aurum.domain.kmodels.io.*
import java.time.LocalDate

fun main(){
 val headers=mapOf<String,Any?>(
  "H\u2060i\u2060s\u2060s\u2060e" to "TEST",
  "A\u2060n\u2060l\u2060i\u2060k\u2060D\u2060e\u2060g\u2060i\u2060s\u2060i\u2060m\u2060%" to 10.0,
  "FiyatDegisim%_T0" to 9.0, "KapanisTarihi_T0" to "21-07-2026",
  "Kapanis_T0" to 100.0, "EMA20_T0" to 101.0, "EMA50_T0" to 99.0, "EMA200_T0" to 90.0,
  "RSI14_T0" to 55.0, "Volatilite5G_T0" to 2.0, "Volatilite21G_T0" to 3.0, "Volatilite63G_T0" to 4.0,
  "Hacim_T0" to 1000.0, "F/K_T0" to 5.0, "PD/DD_T0" to 1.2, "Beta_T0" to 1.0, "ROE_T0" to 15.0
 )
 val row=VerilerRow(headers); val ref=FilterReference(LocalDate.of(2026,7,22),LocalDate.of(2026,7,20))
 check(GlobalFilterPolicy.evaluate(row,ref).accepted)
 check(KModelInputMapper.map(row).symbol=="TEST")
 check(!GlobalFilterPolicy.evaluate(VerilerRow(headers+mapOf("AnlikDegisim%" to 15.0)),ref).accepted)
 check(!GlobalFilterPolicy.evaluate(VerilerRow(headers+mapOf("KapanisTarihi_T0" to "17-07-2026")),ref).accepted)
 println("R23_VERILER_FILTER_PASS")
}
