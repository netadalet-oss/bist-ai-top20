package com.aurum.domain.kmodels.r27

import com.aurum.domain.kmodels.*

private fun requireKeys(result: KModelResult, keys: Set<String>) {
    require(result.reasonFields.keys.containsAll(keys)) { "${result.model} missing ${keys-result.reasonFields.keys}" }
}

fun main() {
    val rows = listOf(
        KModelInput("AAA",vol5=3.0,vol21=2.0,vol63=1.0,bollUpper=12.0,bollLower=8.0,closeT=9.0,volumeChange=5.0,rsi14=52.0,change3d=2.0,intradayChange=1.0,ema20=12.0,ema50=11.0,ema200=10.0,macdHist=1.0,momentum10=2.0,return1m=3.0,return3m=5.0,return6m=8.0,sourceSnapshotSha256="a".repeat(64)),
        KModelInput("BBB",vol5=2.0,vol21=2.0,vol63=2.0,bollUpper=11.0,bollLower=7.0,closeT=8.0,volumeChange=1.0,rsi14=48.0,change3d=1.0,intradayChange=.5,ema20=11.0,ema50=10.0,ema200=9.0,macdHist=.5,momentum10=1.0,return1m=2.0,return3m=4.0,return6m=6.0,sourceSnapshotSha256="b".repeat(64))
    )
    requireKeys(KModels.k1(rows,1).first(), setOf("Vol5","Score_Vol5","Score_YukariSignal"))
    requireKeys(KModels.k2(rows,1).first(), setOf("EMA_Stack_Flagi","Score_EMA_Stack","Score_Mom10"))
    requireKeys(KModels.k4(rows,1).first(), setOf("Getiri1A","Score_Stabilite","Score_EPS_Blok"))
    val k5=KModels.k5(listOf(ConsensusInput("AAA","K1",80.0,"8","12",10.0),ConsensusInput("AAA","K2",90.0,"8","12",10.0)),1).first()
    requireKeys(k5,setOf("K_Adet","K_Listesi","SkorOrt","K_SkorListesi"))
    require(k5.reasonFields["K_SkorListesi"] is List<*>)
    println("R27_REASON_SCHEMA_PASS")
}
