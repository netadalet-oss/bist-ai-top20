package com.aurum.domain.kmodels

fun main(){
    val rows=listOf(
        KModelInput("AAA",vol5=3.0,vol21=2.0,vol63=1.5,bollUpper=12.0,bollLower=8.0,closeT=9.0,volumeChange=20.0,rsi14=51.0,change3d=5.0,intradayChange=2.0,ema20=11.0,ema50=10.0,ema200=9.0,macdHist=.8,momentum10=4.0,return1m=8.0,return3m=15.0,return6m=30.0),
        KModelInput("BBB",vol5=1.0,vol21=2.0,vol63=3.0,bollUpper=12.0,bollLower=8.0,closeT=11.5,volumeChange=-5.0,rsi14=75.0,change3d=-2.0,intradayChange=-1.0,ema20=9.0,ema50=10.0,ema200=11.0,macdHist=-.4,momentum10=-2.0,return1m=-3.0,return3m=2.0,return6m=5.0)
    )
    check(KModels.k1(rows).first().symbol=="AAA")
    check(KModels.k2(rows).first().symbol=="AAA")
    check(KModels.k4(rows).first().symbol=="AAA")
    val k5=KModels.k5(listOf(ConsensusInput("AAA","K1",80.0,"9 / 8","12 / 13",10.0),ConsensusInput("AAA","K2",60.0,"9 / 8","12 / 13",10.0)))
    check(k5.single().score==70.0)
    check(k5.single().reasonFields["K_SkorListesi"] is List<*>)
    val dip=KModelInput("DIP",historyClose=listOf(11.0,10.0,8.0,9.5,11.0),historyChangePct=listOf(2.0,5.0,-10.0,-3.0,1.0),historyVolumeChangePct=listOf(3.0,20.0,-5.0,1.0,2.0))
    check(K3DipRecovery.detect(dip)!=null)
    println("R22_KMODELS_PASS")
}
