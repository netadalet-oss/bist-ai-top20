package com.aurum.domain.kmodels.r26

import com.aurum.domain.kmodels.*
import com.aurum.domain.kmodels.diagnostics.*

fun main() {
    val parsed=ReasonFieldParser.parse("Vol5: 9.72 | Score Vol5: 1.00 | EMA Stack: evet")
    check(parsed["vol5"]=="9.72")
    check(parsed["score_vol5"]=="1.00")
    val result=KModelResult("TEST",55.0,"K1",mapOf("Vol5" to 9.72,"Score_Vol5" to 1.0))
    val cmp=ReasonFieldComparator.compare(result,"Vol5: 9.72 | Score Vol5: 1.00")
    check(cmp.numericMatches==2)
    val bad=KModelInput("BAD",criticalFieldsPresent=false,sourceSnapshotSha256="x")
    val decision=GlobalModelFilters.evaluate(bad)
    check(!decision.accepted)
    check(GlobalModelFilters.RejectionReason.MISSING_CRITICAL_DATA in decision.reasons)
    check(GlobalModelFilters.RejectionReason.INVALID_SOURCE_HASH in decision.reasons)
    val stale=KModelInput("OLD",dataTimestampEpochMillis=200_000_000,t0TimestampEpochMillis=0,sourceSnapshotSha256="a".repeat(64))
    check(GlobalModelFilters.RejectionReason.STALE_T0 in GlobalModelFilters.evaluate(stale).reasons)
    println("R26_REASON_AND_FILTER_GATES_PASS")
}
