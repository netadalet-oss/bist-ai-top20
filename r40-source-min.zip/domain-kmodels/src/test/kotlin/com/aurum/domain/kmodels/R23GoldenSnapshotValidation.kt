package com.aurum.domain.kmodels

import java.io.File
import java.security.MessageDigest

object R23GoldenSnapshotValidation {
    private val models = listOf("K1","K2","K3","K4","K5","S")
    @JvmStatic fun main(args: Array<String>) {
        val base = File(args.firstOrNull() ?: "domain-kmodels/src/test/resources/golden")
        models.forEach { model ->
            val f = File(base, "${model}_EXPECTED_SYMBOLS_R23.txt")
            require(f.isFile) { "Missing golden symbol file: $f" }
            val symbols = f.readLines(Charsets.UTF_8).map { it.trim() }.filter { it.isNotBlank() }
            require(symbols.isNotEmpty()) { "$model has no expected rows" }
            require(symbols.size == symbols.distinct().size) { "$model duplicate symbols" }
            require(symbols.size <= 20) { "$model expected Top20 overflow" }
            symbols.forEach { require(it.matches(Regex("[A-Z0-9]{3,8}"))) { "$model invalid symbol $it" } }
            require(sha256(f.readBytes()).length == 64)
        }
        println("R23_GOLDEN_SNAPSHOT_PASS")
    }
    private fun sha256(bytes: ByteArray)=MessageDigest.getInstance("SHA-256").digest(bytes).joinToString(""){"%02x".format(it)}
}
