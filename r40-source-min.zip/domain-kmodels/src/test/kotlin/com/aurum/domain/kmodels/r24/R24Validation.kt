package com.aurum.domain.kmodels.r24

import com.aurum.domain.kmodels.*

fun main() {
    val rows = listOf(
        KModelInput("A", historyClose=listOf(12.0,11.0,8.0,9.0,13.0), historyChangePct=listOf(2.0,4.0,-5.0,-2.0,1.0), historyVolumeChangePct=listOf(3.0,10.0,-4.0,1.0,2.0)),
        KModelInput("B", historyClose=listOf(12.0,11.0,8.0,9.0,13.0), historyChangePct=listOf(2.0,4.0,-5.0,-2.0,1.0), historyVolumeChangePct=listOf(3.0,10.0,-4.0,1.0,2.0))
    )
    val ranked = K3DipRecovery.rank(rows, 2)
    check(ranked.size == 2)
    check(ranked.all { it.score.isFinite() })
    println("R24_KMODEL_TIEBREAK_PASS")
}
