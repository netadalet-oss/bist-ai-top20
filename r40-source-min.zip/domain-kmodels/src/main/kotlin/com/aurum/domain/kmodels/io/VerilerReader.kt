package com.aurum.domain.kmodels.io

import com.aurum.domain.kmodels.KModelInput
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.abs

object HeaderNormalizer {
    private val invisibles = Regex("[\\u200B\\u200C\\u200D\\u2060\\uFEFF\\n\\r]")
    fun normalize(value: Any?): String = value?.toString().orEmpty()
        .replace(invisibles, "")
        .lowercase()
        .replace('ğ','g').replace('ü','u').replace('ş','s').replace('ı','i').replace('ö','o').replace('ç','c')
        .replace(Regex("[()\\[\\]{}]"), "")
        .replace(Regex("[_\\-]+"), " ")
        .replace(Regex("\\s+"), " ").trim()
    fun key(value: Any?): String = normalize(value).replace(Regex("[^a-z0-9%]+"), "")
}

data class VerilerRow(val raw: Map<String, Any?>) {
    fun value(vararg aliases: String): Any? {
        val byKey = raw.entries.associateBy { HeaderNormalizer.key(it.key) }
        return aliases.firstNotNullOfOrNull { byKey[HeaderNormalizer.key(it)]?.value }
    }
    fun number(vararg aliases: String): Double? = when (val v=value(*aliases)) {
        is Number -> v.toDouble().takeIf { it.isFinite() }
        else -> v?.toString()?.trim()?.replace(".", "")?.replace(',', '.')?.toDoubleOrNull()?.takeIf { it.isFinite() }
    }
    fun text(vararg aliases: String): String? = value(*aliases)?.toString()?.trim()?.takeIf { it.isNotEmpty() }
}

data class FilterReference(val refT0: LocalDate, val tMinus2: LocalDate)
data class FilterDecision(val accepted: Boolean, val reasons: List<String>)

object GlobalFilterPolicy {
    private val criticalAliases = listOf(
        listOf("Kapanis_T0","Kapanis_T"), listOf("EMA20_T0","EMA20"), listOf("EMA50_T0","EMA50"), listOf("EMA200_T0","EMA200"),
        listOf("RSI14_T0","RSI14"), listOf("Volatilite5G_T0","Vol5"), listOf("Volatilite21G_T0","Vol21"), listOf("Volatilite63G_T0","Vol63"),
        listOf("Hacim_T0","Hacim_T"), listOf("F/K_T0","F_K"), listOf("PD/DD_T0","PDDD"), listOf("Beta_T0","Beta"), listOf("ROE_T0","ROE")
    )
    fun evaluate(row: VerilerRow, ref: FilterReference): FilterDecision {
        val reasons=mutableListOf<String>()
        val dayMove=row.number("AnlikDegisim%", "AnlikDegisim(%)", "AnlikDegisim%_T0")
        val tMove=row.number("FiyatDegisim%_T0", "FiyatDegisim(%)_T0", "FiyatDegisim%_T")
        if ((dayMove!=null && abs(dayMove)>=15.0) || (tMove!=null && abs(tMove)>=15.0)) reasons += "EXTREME_MOVE"
        var missing=0
        for (aliases in criticalAliases) {
            val exists=aliases.any { a -> row.raw.keys.any { HeaderNormalizer.key(it)==HeaderNormalizer.key(a) } }
            if (exists && row.number(*aliases.toTypedArray())==null) missing++
        }
        if (missing>=3) reasons += "MISSING_CRITICAL_$missing"
        val closeDate=parseDate(row.text("KapanisTarihi_T0","KapanisTarihi_T"))
        if (closeDate!=null && closeDate.isBefore(ref.tMinus2)) reasons += "STALE_T0"
        return FilterDecision(reasons.isEmpty(), reasons)
    }
    private fun parseDate(v:String?):LocalDate? {
        if(v==null)return null
        val formats=listOf("dd-MM-yyyy","dd.MM.yyyy","yyyy-MM-dd")
        for(f in formats) try{return LocalDate.parse(v,DateTimeFormatter.ofPattern(f))}catch(_:Exception){}
        return null
    }
}

object KModelInputMapper {
    fun map(row: VerilerRow, maxLag:Int=30): KModelInput {
        fun n(vararg a:String)=row.number(*a)
        fun hist(prefix:String)= (0..maxLag).map { lag -> n("${prefix}_T$lag", "${prefix}T$lag") }
        val symbol=row.text("Hisse","Sembol","Kod").orEmpty()
        return KModelInput(
            symbol=symbol,
            vol5=n("Volatilite5G_T0","Vol5"), vol21=n("Volatilite21G_T0","Vol21"), vol63=n("Volatilite63G_T0","Vol63"),
            bollUpper=n("BollingerUst_T0","BollUpper"), bollLower=n("BollingerAlt_T0","BollLower"), closeT=n("Kapanis_T0","Kapanis_T"),
            volumeChange=n("HacimDegisim%_T0","HacimDegisim%_T"), rsi14=n("RSI14_T0","RSI14"), change3d=parseFirst(row.text("Degisim3Gun%_T0","Degisim3Gun(%)_T0")),
            intradayChange=n("AnlikDegisim%","AnlikDegisim(%)","AnlikDegisim%_T0"), ema20=n("EMA20_T0","EMA20"), ema50=n("EMA50_T0","EMA50"),
            ema200=n("EMA200_T0","EMA200"), macdHist=n("MACDHist_T0","MACDHist"), momentum10=n("Momentum10_T0","Momentum10"),
            return1m=n("Getiri1A_T0","Getiri1A"), return3m=n("Getiri3A_T0","Getiri3A"), return6m=n("Getiri6A_T0","Getiri6A"),
            historyClose=hist("Kapanis"), historyChangePct=hist("FiyatDegisim%"), historyVolumeChangePct=hist("HacimDegisim%"),
            supportText=row.text("Destekler3_T0","Destekler(3)_T0"), resistanceText=row.text("Direncler3_T0","Direncler(3)_T0"),
            lastPrice=n("Anlik","Kapanis_T0")
        )
    }
    private fun parseFirst(v:String?):Double? = v?.split('|','/',';')?.firstOrNull()?.trim()?.replace(',','.')?.toDoubleOrNull()
}
