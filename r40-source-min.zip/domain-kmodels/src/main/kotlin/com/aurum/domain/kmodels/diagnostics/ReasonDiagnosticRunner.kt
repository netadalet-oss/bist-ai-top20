package com.aurum.domain.kmodels.diagnostics

import com.aurum.domain.kmodels.*
import com.aurum.domain.kmodels.replay.CsvSupport
import com.aurum.domain.kmodels.replay.GoldenInputLoader
import java.nio.file.Files
import java.nio.file.Path

object ReasonDiagnosticRunner {
    data class Row(val symbol:String,val reason:String?)
    fun run(veriler:Path,goldenDir:Path):String {
        val inputs=GoldenInputLoader.load(veriler).inputs
        val actual=linkedMapOf("K1" to KModels.k1(inputs),"K2" to KModels.k2(inputs),"K3" to K3DipRecovery.rank(inputs),"K4" to KModels.k4(inputs))
        val consensus=actual.flatMap{(m,rs)->rs.map{r->inputs.first{it.symbol==r.symbol}.let{i->ConsensusInput(r.symbol,m,r.score,i.supportText,i.resistanceText,i.lastPrice)}}}
        actual["K5"]=KModels.k5(consensus)
        val summaries=actual.map{(model,results)->
            val expected=read(goldenDir.resolve("${model}_EXPECTED_TOP20_R23.csv")).associateBy{it.symbol}
            val comparisons=results.mapNotNull{r->expected[r.symbol]?.let{ReasonFieldComparator.compare(r,it.reason)}}
            val fields=comparisons.sumOf{it.comparedFields}; val numeric=comparisons.sumOf{it.numericMatches}; val exact=comparisons.sumOf{it.exactMatches}
            val missing=comparisons.flatMap{it.missingExpectedFields}.groupingBy{it}.eachCount().entries.sortedByDescending{it.value}.take(20)
            """{"model":"$model","overlapRows":${comparisons.size},"expectedFieldInstances":$fields,"exactMatches":$exact,"numericMatches":$numeric,"numericMatchRate":${if(fields==0)0.0 else numeric.toDouble()/fields},"topMissingFields":[${missing.joinToString(","){"{\"field\":\"${it.key}\",\"count\":${it.value}}"}}]}"""
        }
        return "[${summaries.joinToString(",")}]"
    }
    private fun read(path:Path):List<Row>{
        val rows=CsvSupport.parse(Files.readString(path)); if(rows.size<2)return emptyList()
        val h=rows.first().map(CsvSupport::normalizeHeader); val si=h.indexOf("hisse"); val ri=h.indexOfFirst{it.startsWith("gerekce")}
        return rows.drop(1).mapNotNull{r->r.getOrNull(si)?.takeIf{it.isNotBlank()}?.let{Row(it,r.getOrNull(ri))}}
    }
}

fun main(args:Array<String>){ require(args.size==2); println(ReasonDiagnosticRunner.run(Path.of(args[0]),Path.of(args[1]))) }
