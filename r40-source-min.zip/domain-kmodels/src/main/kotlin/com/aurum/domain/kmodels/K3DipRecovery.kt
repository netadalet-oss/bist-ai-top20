package com.aurum.domain.kmodels

object K3DipRecovery {
    data class Pattern(val depth:Double,val bounce:Double,val recency:Int,val volumeUp:Double,val dipIndex:Int,val peakIndex:Int,val recoveryIndex:Int,val window:String)
    private val configs=listOf(10 to 3,15 to 5,20 to 7,30 to 10)
    fun detect(row:KModelInput):Pattern? {
        for ((dipWindow, recWindow) in configs) {
            val found = detectWithConfig(row, dipWindow, recWindow)
            if (found != null) return found
        }
        return null
    }

    private fun detectWithConfig(row:KModelInput, dipWindow:Int, recWindow:Int):Pattern? {
            val close=row.historyClose; val chg=row.historyChangePct; val vol=row.historyVolumeChangePct; val w=minOf(dipWindow,close.size)
            if(w<3||close.getOrNull(0)==null) return null
            var dip:Int?=null
            for(d in 1 until w-1){ val c=close[d]; val prev=close[d+1]; val next=close[d-1]; if(c!=null&&prev!=null&&next!=null&&c<=prev&&c<=next&&(dip==null||d<dip)) dip=d }
            if(dip==null) dip=(0 until w).filter{close[it]!=null}.minByOrNull{close[it]!!}
            val di=dip?:return null; val dc=close[di]?:return null
            var pi:Int?=null; var pc:Double?=null
            for(d in di+1 until w){ val c=close[d]?:continue; if(pc==null||c>pc){pc=c;pi=d} }
            val peak=pc?:return null; val pidx=pi?:return null; val drop=(peak-dc)/peak; if(drop<=0.03)return null
            var ri:Int?=null
            for(offset in 1..minOf(recWindow,di)){ val d=di-offset; val cp=close.getOrNull(d); val c=chg.getOrNull(d); val v=vol.getOrNull(d); if(cp!=null&&c!=null&&v!=null&&c>0&&v>0&&cp>dc){ri=d;break} }
            val ridx=ri?:return null; val today=close[0]?:return null
            return Pattern(drop,today/dc-1,ridx,vol[ridx]!!,di,pidx,ridx,"$dipWindow/$recWindow")
    }
    fun rank(rows:List<KModelInput>,topN:Int=20):List<KModelResult>{
        // Apps Script paritesi: konfigürasyon hisse bazında değil, tüm evrende ilk aday üreten pencere olarak seçilir.
        var chosen: Pair<Int,Int>? = null
        var p: List<Pattern?> = emptyList()
        for (cfg in configs) {
            val candidate = rows.map { detectWithConfig(it, cfg.first, cfg.second) }
            if (candidate.any { it != null }) { chosen = cfg; p = candidate; break }
        }
        if (chosen == null) { val cfg=configs.last(); p=rows.map { detectWithConfig(it,cfg.first,cfg.second) } }
        val sd=Scoring.robustRange(p.map{it?.depth}); val sb=Scoring.robustRange(p.map{it?.bounce}); val sr=Scoring.robustRange(p.map{it?.recency?.toDouble()},true); val sv=Scoring.robustRange(p.map{it?.volumeUp})
        val cfg = chosen ?: configs.last()
        return rows.indices.mapNotNull{i->
            val x=p[i]?:return@mapNotNull null
            val base=.40*(sd[i]?:0.0)+.30*(sb[i]?:0.0)+.20*(sr[i]?:0.0)+.10*(sv[i]?:0.0)
            val score=base*100
            KModelResult(rows[i].symbol,kotlin.math.round(score*100)/100,"K3",linkedMapOf(
                "DipGun_Index" to x.dipIndex,"TepeGun_Index" to x.peakIndex,"KalkisGun_Index" to x.recoveryIndex,
                "DipDerinligi" to x.depth,"DiptenToparlanma" to x.bounce,"KalkisGunu_Yakinlik" to x.recency,
                "HacimArtisi_Kalkis" to x.volumeUp,"Score_DipDerinligi" to sd[i],"Score_DiptenToparlanma" to sb[i],
                "Score_KalkisYakinlik" to sr[i],"Score_HacimArtisi" to sv[i],"Score_Total_Base" to base,
                "Param_DipWindow" to cfg.first,"Param_RecWindow" to cfg.second
            ))
        }.sortedByDescending{it.score}.take(topN)
    }
}
