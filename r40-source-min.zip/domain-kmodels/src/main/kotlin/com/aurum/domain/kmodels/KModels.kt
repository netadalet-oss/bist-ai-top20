package com.aurum.domain.kmodels

import kotlin.math.abs

object KModels {
    fun k1(rows: List<KModelInput>, topN: Int = 20): List<KModelResult> {
        val filtered = GlobalModelFilters.apply(rows)
        val r1 = filtered.map { if (it.vol5 != null && it.vol21 != null && it.vol21 != 0.0) it.vol5 / it.vol21 else null }
        val r2 = filtered.map { if (it.vol21 != null && it.vol63 != null && it.vol63 != 0.0) it.vol21 / it.vol63 else null }
        val rangeWidth = filtered.map { if (it.bollUpper != null && it.bollLower != null && it.bollUpper != 0.0) (it.bollUpper-it.bollLower)/abs(it.bollUpper) else null }
        val nearLB = filtered.map { if (it.bollLower != null && it.bollUpper != null && it.closeT != null) (it.closeT-it.bollLower)/(abs(it.bollUpper-it.bollLower).takeIf { x -> x != 0.0 } ?: 1e-6) else null }
        val rsiDist = filtered.map { it.rsi14?.let { x -> abs(x-50.0) } }
        val priceFlag = filtered.map { r -> if (r.change3d == null && r.intradayChange == null) null else listOf(r.change3d, r.intradayChange).count { (it ?: 0.0) > 0 }.toDouble() }
        val volFlag = filtered.map { it.volumeChange?.let { x -> if (x > 0) 1.0 else 0.0 } }
        val sv5=Scoring.minMax(filtered.map{it.vol5}); val sv21=Scoring.minMax(filtered.map{it.vol21}); val sv63=Scoring.minMax(filtered.map{it.vol63})
        val sr1=Scoring.minMax(r1); val sr2=Scoring.minMax(r2); val sRange=Scoring.minMax(rangeWidth); val sVol=Scoring.minMax(filtered.map{it.volumeChange}); val sNear=Scoring.minMax(nearLB,true)
        val sRsi=Scoring.minMax(rsiDist,true); val sM3=Scoring.minMax(filtered.map{it.change3d}); val sAn=Scoring.minMax(filtered.map{it.intradayChange}); val sPF=Scoring.minMax(priceFlag); val sVF=Scoring.minMax(volFlag)
        val volStruct=filtered.indices.map { .35*(sv5[it]?:0.0)+.35*(sr1[it]?:0.0)+.15*(sv21[it]?:0.0)+.10*(sr2[it]?:0.0)+.05*(sv63[it]?:0.0) }
        val dip=filtered.indices.map { .25*(sRange[it]?:0.0)+.35*(sVol[it]?:0.0)+.40*(sNear[it]?:0.0) }
        val mom=filtered.indices.map { .50*(sM3[it]?:0.0)+.35*(sAn[it]?:0.0)+.15*(sRsi[it]?:0.0) }
        val up=Scoring.average(sPF,sVF)
        val base=filtered.indices.map { (0.25*volStruct[it]+0.20*dip[it]+0.35*mom[it]+0.20*(up[it]?:0.0))*100 }
        val final=Scoring.breakTies(base,up,sM3)
        return filtered.indices.map { i ->
            val o=filtered[i]
            KModelResult(o.symbol, round2(final[i]!!), "K1", linkedMapOf(
                "Vol5" to o.vol5,"Vol21" to o.vol21,"Vol63" to o.vol63,
                "VolOran1" to r1[i],"VolOran2" to r2[i],"RangeWidth" to rangeWidth[i],
                "HacimDegisim" to o.volumeChange,"AltBant_Yakinlik" to nearLB[i],"RSI14" to o.rsi14,
                "Degisim3Gun" to o.change3d,"HacimArtis_Flagi" to volFlag[i],"FiyatYukari_Flagi" to priceFlag[i],
                "Score_Vol5" to sv5[i],"Score_Vol21" to sv21[i],"Score_Vol63" to sv63[i],
                "Score_VolOran1" to sr1[i],"Score_VolOran2" to sr2[i],"Score_RangeWidth" to sRange[i],
                "Score_HacimDegisim" to sVol[i],"Score_AltBant_Yakinlik" to sNear[i],"Score_RSI_Merkez" to sRsi[i],
                "Score_Mom3Gun" to sM3[i],"Score_AnlikDegisim" to sAn[i],"Score_HacimArtis_Flagi" to sVF[i],
                "Score_FiyatYukari_Flagi" to sPF[i],"Score_VolStruct" to volStruct[i],"Score_DipBlock" to dip[i],
                "Score_MomBlock" to mom[i],"Score_YukariSignal" to up[i]
            ))
        }.sortedByDescending{it.score}.take(topN)
    }

    fun k2(rows: List<KModelInput>, topN: Int = 20): List<KModelResult> {
        val filtered = GlobalModelFilters.apply(rows)
        val stack=filtered.map { if(it.ema20!=null&&it.ema50!=null&&it.ema200!=null&&it.ema20>it.ema50&&it.ema50>it.ema200)1.0 else 0.0 }
        val g1=filtered.map { if(it.ema20!=null&&it.ema50!=null&&it.ema50!=0.0) it.ema20/it.ema50-1 else null }
        val g2=filtered.map { if(it.ema50!=null&&it.ema200!=null&&it.ema200!=0.0) it.ema50/it.ema200-1 else null }
        val rsiDist=filtered.map { it.rsi14?.let{x->abs(x-55)} }
        val ss=Scoring.robustRange(stack); val s1=Scoring.robustRange(g1); val s2=Scoring.robustRange(g2); val sm=Scoring.robustRange(filtered.map{it.macdHist}); val sr=Scoring.robustRange(rsiDist,true); val smo=Scoring.robustRange(filtered.map{it.momentum10})
        val base=filtered.indices.map { (0.25*(ss[it]?:0.0)+0.20*(s1[it]?:0.0)+0.10*(s2[it]?:0.0)+0.25*(sm[it]?:0.0)+0.10*(sr[it]?:0.0)+0.10*(smo[it]?:0.0))*100 }
        val final=Scoring.breakTies(base,sm,ss)
        return filtered.indices.map{i->
            val o=filtered[i]
            KModelResult(o.symbol,round2(final[i]!!),"K2",linkedMapOf(
                "EMA_Stack_Flagi" to stack[i],"EMA_Stack" to if(stack[i]>0)"evet" else "hayır",
                "EMA20_50_Gap" to g1[i],"EMA50_200_Gap" to g2[i],"MACD_Hist" to o.macdHist,
                "RSI14" to o.rsi14,"Mom10" to o.momentum10,"Degisim3Gun" to o.change3d,
                "Score_EMA_Stack" to ss[i],"Score_EMA20_50_Gap" to s1[i],"Score_EMA50_200_Gap" to s2[i],
                "Score_MACD_Hist" to sm[i],"Score_RSI_Dist55" to sr[i],"Score_Mom10" to smo[i]
            ))
        }.sortedByDescending{it.score}.take(topN)
    }

    fun k4(rows: List<KModelInput>, topN: Int = 20): List<KModelResult> {
        val filtered = GlobalModelFilters.apply(rows)
        val s1=Scoring.robustRange(filtered.map{it.return1m}); val s3=Scoring.robustRange(filtered.map{it.return3m}); val s6=Scoring.robustRange(filtered.map{it.return6m})
        val stab=filtered.map { if(it.vol21==null||it.return1m==null||it.return1m==0.0)null else it.vol21/abs(it.return1m) }
        val sSt=Scoring.robustRange(stab,true); val ts=Scoring.average(s1,s3,s6)
        val eps=Scoring.average(Scoring.robustRange(filtered.map{it.change3d}),Scoring.robustRange(filtered.map{it.rsi14?.let{x->abs(x-55)}},true))
        val base=filtered.indices.map{(0.45*(ts[it]?:0.0)+0.30*(sSt[it]?:0.0)+0.25*(eps[it]?:0.0))*100}; val final=Scoring.breakTies(base,s6,sSt)
        return filtered.indices.map{i->
            val o=filtered[i]
            KModelResult(o.symbol,round2(final[i]!!),"K4",linkedMapOf(
                "Getiri1A" to o.return1m,"Getiri3A" to o.return3m,"Getiri6A" to o.return6m,
                "Vol21" to o.vol21,"Degisim3Gun" to o.change3d,"RSI14" to o.rsi14,
                "Score_Getiri1A" to s1[i],"Score_Getiri3A" to s3[i],"Score_Getiri6A" to s6[i],
                "Score_Stabilite" to sSt[i],"Score_TS_Ortalama" to ts[i],"Score_EPS_Blok" to eps[i]
            ))
        }.sortedByDescending{it.score}.take(topN)
    }

    fun k5(items: List<ConsensusInput>, topN: Int = 20): List<KModelResult> = items.groupBy{it.symbol}.map { (symbol, xs) ->
        val avg=xs.map{it.score}.average(); val first=xs.first(); val supports=parseLevels(first.supportText); val resistances=parseLevels(first.resistanceText); val p=first.lastPrice
        val modelNames=xs.map{it.model}
        val contributions=xs.map{linkedMapOf("sheet" to it.model,"skor" to it.score)}
        KModelResult(symbol,round2(avg),"K5",linkedMapOf(
            "K_Adet" to xs.size,"K_Listesi" to modelNames.joinToString(", "),"SkorOrt" to avg,
            "DestekUzakPct" to if(p!=null&&supports.isNotEmpty())(p/supports.first()-1)*100 else null,
            "DirencYakinPct" to if(p!=null&&resistances.isNotEmpty())(resistances.first()/p-1)*100 else null,
            "K_SkorListesi" to contributions
        ))
    }.sortedByDescending{it.score}.take(topN)

    private fun parseLevels(s:String?):List<Double> = s?.split(Regex("[/;|\\-]+"))?.mapNotNull{it.trim().replace(',','.').toDoubleOrNull()} ?: emptyList()
    private fun round2(x:Double)=kotlin.math.round(x*100)/100
}
