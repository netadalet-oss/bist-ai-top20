package com.aurum.domain.kmodels

data class KModelInput(
    val symbol: String,
    val vol5: Double? = null, val vol21: Double? = null, val vol63: Double? = null,
    val bollUpper: Double? = null, val bollLower: Double? = null, val closeT: Double? = null,
    val volumeChange: Double? = null, val rsi14: Double? = null, val change3d: Double? = null,
    val intradayChange: Double? = null, val ema20: Double? = null, val ema50: Double? = null,
    val ema200: Double? = null, val macdHist: Double? = null, val momentum10: Double? = null,
    val return1m: Double? = null, val return3m: Double? = null, val return6m: Double? = null,
    val historyClose: List<Double?> = emptyList(),
    val historyChangePct: List<Double?> = emptyList(),
    val historyVolumeChangePct: List<Double?> = emptyList(),
    val supportText: String? = null, val resistanceText: String? = null,
    val lastPrice: Double? = null,
    val dataTimestampEpochMillis: Long? = null,
    val t0TimestampEpochMillis: Long? = null,
    val latestCloseTimestampEpochMillis: Long? = null,
    val criticalFieldsPresent: Boolean = true,
    val sourceSnapshotSha256: String? = null
)

data class KModelResult(
    val symbol: String,
    val score: Double,
    val model: String,
    val reasonFields: Map<String, Any?>
)

data class ConsensusInput(
    val symbol: String,
    val model: String,
    val score: Double,
    val supportText: String? = null,
    val resistanceText: String? = null,
    val lastPrice: Double? = null
)
