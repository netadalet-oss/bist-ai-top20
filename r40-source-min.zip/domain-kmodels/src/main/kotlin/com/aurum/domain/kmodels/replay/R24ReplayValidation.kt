package com.aurum.domain.kmodels.replay

import java.nio.file.Path

fun main(args: Array<String>) {
    require(args.size == 2) { "Usage: <Veriler.csv> <goldenDir>" }
    val report = ReplayRunner.run(Path.of(args[0]), Path.of(args[1]))
    check(report.sourceRows > 0)
    check(report.usableInputs > 0)
    check(report.models.map { it.model }.toSet() == setOf("K1","K2","K3","K4","K5"))
    println(ReplayRunner.toJson(report))
    println("R24_REPLAY_PASS")
}
