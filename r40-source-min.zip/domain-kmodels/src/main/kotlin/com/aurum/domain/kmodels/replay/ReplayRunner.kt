package com.aurum.domain.kmodels.replay

import com.aurum.domain.kmodels.*
import java.nio.file.Files
import java.nio.file.Path
import kotlin.math.abs

object ReplayRunner {
    data class Expected(val symbol: String, val score: Double?)
    data class ModelReport(
        val model: String, val expectedCount: Int, val actualCount: Int,
        val overlapCount: Int, val precisionAt20: Double,
        val exactRankMatches: Int, val meanAbsoluteRankErrorOnOverlap: Double?,
        val scoreComparableCount: Int, val meanAbsoluteScoreError: Double?,
        val expectedOnly: List<String>, val actualOnly: List<String>
    )
    data class ReplayReport(val sourceRows: Int, val usableInputs: Int, val missingFields: Set<String>, val models: List<ModelReport>)

    fun run(verilerCsv: Path, goldenDir: Path): ReplayReport {
        val loaded = GoldenInputLoader.load(verilerCsv)
        val inputs = loaded.inputs
        val actual = linkedMapOf(
            "K1" to KModels.k1(inputs), "K2" to KModels.k2(inputs), "K3" to K3DipRecovery.rank(inputs), "K4" to KModels.k4(inputs)
        )
        val consensus = actual.flatMap { (model, rows) -> rows.map { r ->
            val input = inputs.first { it.symbol == r.symbol }
            ConsensusInput(r.symbol, model, r.score, input.supportText, input.resistanceText, input.lastPrice)
        }}
        actual["K5"] = KModels.k5(consensus)
        val reports = actual.map { (model, rows) -> compare(model, readExpected(goldenDir.resolve("${model}_EXPECTED_TOP20_R23.csv")), rows) }
        return ReplayReport(loaded.sourceRowCount, inputs.size, loaded.missingFields, reports)
    }

    private fun readExpected(path: Path): List<Expected> {
        val rows = CsvSupport.parse(Files.readString(path)); if (rows.size < 2) return emptyList()
        val headers = rows.first().map(CsvSupport::normalizeHeader)
        val symbolIdx = headers.indexOf("hisse")
        val scoreIdx = headers.indexOf("skor")
        return rows.drop(1).mapNotNull { r -> r.getOrNull(symbolIdx)?.trim()?.takeIf { it.isNotEmpty() }?.let { Expected(it, if(scoreIdx>=0) CsvSupport.number(r.getOrNull(scoreIdx)) else null) } }
    }

    private fun compare(model:String, expected:List<Expected>, actual:List<KModelResult>):ModelReport {
        val eRank=expected.mapIndexed{idx,e->e.symbol to idx+1}.toMap(); val aRank=actual.mapIndexed{idx,a->a.symbol to idx+1}.toMap()
        val overlap=eRank.keys.intersect(aRank.keys); val exact=overlap.count{eRank[it]==aRank[it]}
        val rankMae=overlap.map{abs(eRank.getValue(it)-aRank.getValue(it)).toDouble()}.takeIf{it.isNotEmpty()}?.average()
        val eScore=expected.mapNotNull{e->e.score?.let{e.symbol to it}}.toMap(); val aScore=actual.associate{it.symbol to it.score}
        val comparable=overlap.filter{eScore[it]!=null&&aScore[it]!=null}; val scoreMae=comparable.map{abs(eScore.getValue(it)-aScore.getValue(it))}.takeIf{it.isNotEmpty()}?.average()
        return ModelReport(model,expected.size,actual.size,overlap.size,if(expected.isEmpty())0.0 else overlap.size.toDouble()/expected.size,exact,rankMae,comparable.size,scoreMae,(eRank.keys-aRank.keys).sorted(),(aRank.keys-eRank.keys).sorted())
    }

    fun toJson(report:ReplayReport):String {
        fun q(s:String)="\""+s.replace("\\","\\\\").replace("\"","\\\"")+"\""
        fun list(xs:List<String>)=xs.joinToString(prefix="[",postfix="]"){q(it)}
        val models=report.models.joinToString(prefix="[",postfix="]"){m->"""{"model":${q(m.model)},"expectedCount":${m.expectedCount},"actualCount":${m.actualCount},"overlapCount":${m.overlapCount},"precisionAt20":${m.precisionAt20},"exactRankMatches":${m.exactRankMatches},"meanAbsoluteRankErrorOnOverlap":${m.meanAbsoluteRankErrorOnOverlap},"scoreComparableCount":${m.scoreComparableCount},"meanAbsoluteScoreError":${m.meanAbsoluteScoreError},"expectedOnly":${list(m.expectedOnly)},"actualOnly":${list(m.actualOnly)}}"""}
        return """{"sourceRows":${report.sourceRows},"usableInputs":${report.usableInputs},"missingFields":${list(report.missingFields.sorted())},"models":$models}"""
    }
}
