package com.aurum.domain.kmodels.replay

import com.aurum.domain.kmodels.KModelInput
import java.nio.file.Files
import java.nio.file.Path
import java.security.MessageDigest

object GoldenInputLoader {
    private val aliases = mapOf(
        "symbol" to listOf("Hisse"),
        "vol5" to listOf("Volatilite5G_T0"), "vol21" to listOf("Volatilite21G_T0"), "vol63" to listOf("Volatilite63G_T0"),
        "bollUpper" to listOf("Boll_Ust_T0"), "bollLower" to listOf("Boll_Alt_T0"), "closeT" to listOf("Kapanis_T0"),
        "volumeChange" to listOf("HacimDegisim%_T0"), "rsi14" to listOf("RSI14_T0"), "change3d" to listOf("Degisim3Gun(%)_T0"),
        "intradayChange" to listOf("AnlikDegisim%"), "ema20" to listOf("EMA20_T0"), "ema50" to listOf("EMA50_T0"), "ema200" to listOf("EMA200_T0"),
        "macdHist" to listOf("MACDHist_T0", "MACD_Hist_T0"), "momentum10" to listOf("Momentum10_T0"),
        "return1m" to listOf("Getiri_TL_1A_T0", "Getiri1Ay%_T0"), "return3m" to listOf("Getiri_TL_3A_T0", "Getiri3Ay%_T0"), "return6m" to listOf("Getiri_TL_6A_T0", "Getiri6Ay%_T0"),
        "supportText" to listOf("Destekler(3)_T0"), "resistanceText" to listOf("Direncler(3)_T0"), "lastPrice" to listOf("Anlik"),
        "dataTimestamp" to listOf("VeriZamani"), "t0Date" to listOf("KapanisTarihi_T0", "KapanışTarihi_T0")
    )

    data class LoadResult(val inputs: List<KModelInput>, val missingFields: Set<String>, val sourceRowCount: Int)

    fun load(path: Path): LoadResult {
        val rows = CsvSupport.parse(Files.readString(path))
        require(rows.isNotEmpty()) { "Empty golden Veriler CSV" }
        val headers = rows.first().map(CsvSupport::normalizeHeader)
        fun index(field: String): Int? = aliases[field].orEmpty().map(CsvSupport::normalizeHeader).firstNotNullOfOrNull { a -> headers.indexOf(a).takeIf { it >= 0 } }
        val indexes = aliases.keys.associateWith(::index)
        val missing = indexes.filterValues { it == null }.keys
        fun cell(row: List<String>, field: String): String? = indexes[field]?.let { row.getOrNull(it) }
        fun history(row: List<String>, prefix: String): List<Double?> = (0..90).map { t ->
            val target = CsvSupport.normalizeHeader("${prefix}_T$t")
            val idx = headers.indexOf(target)
            if (idx < 0) null else CsvSupport.number(row.getOrNull(idx))
        }
        val sourceHash = MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(path)).joinToString("") { "%02x".format(it) }
        val critical = listOf("vol5","vol21","vol63","bollUpper","bollLower","closeT","rsi14","intradayChange")
        fun excelEpochMillis(v: String?): Long? {
            val n=CsvSupport.number(v) ?: return null
            return ((n - 25569.0) * 86_400_000.0).toLong()
        }
        val inputs = rows.drop(1).mapNotNull { row ->
            val symbol = cell(row, "symbol")?.trim()?.takeIf { it.matches(Regex("[A-Z0-9]{2,8}")) } ?: return@mapNotNull null
            KModelInput(
                symbol = symbol,
                vol5 = CsvSupport.number(cell(row,"vol5")), vol21 = CsvSupport.number(cell(row,"vol21")), vol63 = CsvSupport.number(cell(row,"vol63")),
                bollUpper = CsvSupport.number(cell(row,"bollUpper")), bollLower = CsvSupport.number(cell(row,"bollLower")), closeT = CsvSupport.number(cell(row,"closeT")),
                volumeChange = CsvSupport.number(cell(row,"volumeChange")), rsi14 = CsvSupport.number(cell(row,"rsi14")), change3d = CsvSupport.number(cell(row,"change3d")),
                intradayChange = CsvSupport.number(cell(row,"intradayChange")), ema20 = CsvSupport.number(cell(row,"ema20")), ema50 = CsvSupport.number(cell(row,"ema50")),
                ema200 = CsvSupport.number(cell(row,"ema200")), macdHist = CsvSupport.number(cell(row,"macdHist")), momentum10 = CsvSupport.number(cell(row,"momentum10")),
                return1m = CsvSupport.number(cell(row,"return1m")), return3m = CsvSupport.number(cell(row,"return3m")), return6m = CsvSupport.number(cell(row,"return6m")),
                historyClose = history(row,"Kapanis"), historyChangePct = history(row,"FiyatDegisim%"), historyVolumeChangePct = history(row,"HacimDegisim%"),
                supportText = cell(row,"supportText"), resistanceText = cell(row,"resistanceText"), lastPrice = CsvSupport.number(cell(row,"lastPrice")),
                dataTimestampEpochMillis = excelEpochMillis(cell(row,"dataTimestamp")),
                t0TimestampEpochMillis = excelEpochMillis(cell(row,"t0Date")),
                criticalFieldsPresent = critical.all { f -> cell(row,f)?.isNotBlank() == true && CsvSupport.number(cell(row,f)) != null },
                sourceSnapshotSha256 = sourceHash
            )
        }
        return LoadResult(inputs, missing, rows.size - 1)
    }
}
