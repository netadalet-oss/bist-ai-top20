package com.aurum.domain.kmodels

object GlobalModelFilters {
    enum class RejectionReason { EXTREME_INTRADAY_MOVE, EXTREME_T0_MOVE, MISSING_CRITICAL_DATA, STALE_T0, INVALID_SOURCE_HASH }
    data class Decision(val input: KModelInput, val accepted: Boolean, val reasons: Set<RejectionReason>)

    fun evaluate(row: KModelInput): Decision {
        val reasons = linkedSetOf<RejectionReason>()
        if (kotlin.math.abs(row.intradayChange ?: 0.0) >= 15.0) reasons += RejectionReason.EXTREME_INTRADAY_MOVE
        if (kotlin.math.abs(row.historyChangePct.firstOrNull() ?: 0.0) >= 15.0) reasons += RejectionReason.EXTREME_T0_MOVE
        if (!row.criticalFieldsPresent) reasons += RejectionReason.MISSING_CRITICAL_DATA
        val dataTs=row.dataTimestampEpochMillis; val t0Ts=row.t0TimestampEpochMillis
        if (dataTs != null && t0Ts != null && t0Ts < dataTs - 36L*60*60*1000) reasons += RejectionReason.STALE_T0
        val h=row.sourceSnapshotSha256
        if (h != null && !Regex("^[0-9a-fA-F]{64}$").matches(h)) reasons += RejectionReason.INVALID_SOURCE_HASH
        return Decision(row,reasons.isEmpty(),reasons)
    }

    fun apply(rows: List<KModelInput>): List<KModelInput> = rows.map(::evaluate).filter { it.accepted }.map { it.input }
}
