package com.aurum.domain.kmodels.io

/** Narrow compatibility layer for Apps Script Number() semantics used by the source. */
object JsNumberSemantics {
    fun toFiniteDouble(value: Any?): Double? = when (value) {
        null -> null
        is Boolean -> if (value) 1.0 else 0.0
        is Number -> value.toDouble().takeIf { it.isFinite() }
        else -> {
            val text = value.toString().trim()
            if (text.isEmpty()) null else text.toDoubleOrNull()?.takeIf { it.isFinite() }
        }
    }
}

enum class SourceFieldStatus { POPULATED, REFERENCED_BUT_UNPOPULATED }

data class SourceFieldContract(val field: String, val status: SourceFieldStatus, val consumers: Set<String>)

object LegacySourceFieldAudit {
    val contracts = listOf(
        SourceFieldContract("vol63", SourceFieldStatus.REFERENCED_BUT_UNPOPULATED, setOf("K1")),
        SourceFieldContract("hacimdeg", SourceFieldStatus.REFERENCED_BUT_UNPOPULATED, setOf("K1")),
        SourceFieldContract("hacimdeg_T", SourceFieldStatus.REFERENCED_BUT_UNPOPULATED, setOf("K1")),
        SourceFieldContract("momentum10", SourceFieldStatus.REFERENCED_BUT_UNPOPULATED, setOf("K2"))
    )
}
