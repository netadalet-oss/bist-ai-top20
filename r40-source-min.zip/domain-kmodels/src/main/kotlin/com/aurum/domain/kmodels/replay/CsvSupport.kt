package com.aurum.domain.kmodels.replay

object CsvSupport {
    fun parse(text: String): List<List<String>> {
        val rows = mutableListOf<MutableList<String>>()
        var row = mutableListOf<String>()
        val field = StringBuilder()
        var quoted = false
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            when {
                quoted && ch == '"' && i + 1 < text.length && text[i + 1] == '"' -> { field.append('"'); i++ }
                ch == '"' -> quoted = !quoted
                !quoted && ch == ',' -> { row.add(field.toString()); field.setLength(0) }
                !quoted && (ch == '\n' || ch == '\r') -> {
                    if (ch == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                    row.add(field.toString()); field.setLength(0)
                    if (row.any { it.isNotEmpty() }) rows.add(row)
                    row = mutableListOf()
                }
                else -> field.append(ch)
            }
            i++
        }
        if (field.isNotEmpty() || row.isNotEmpty()) { row.add(field.toString()); rows.add(row) }
        return rows
    }

    fun normalizeHeader(value: String): String = value
        .replace("\uFEFF", "")
        .replace("\u2060", "")
        .replace("\u200B", "")
        .replace("\u200C", "")
        .replace("\u200D", "")
        .replace("\n", "")
        .replace("\r", "")
        .replace(" ", "")
        .replace("ı", "i").replace("İ", "I")
        .replace("ş", "s").replace("Ş", "S")
        .replace("ğ", "g").replace("Ğ", "G")
        .replace("ü", "u").replace("Ü", "U")
        .replace("ö", "o").replace("Ö", "O")
        .replace("ç", "c").replace("Ç", "C")
        .lowercase()

    fun number(value: String?): Double? {
        val raw = value?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        if (raw.contains("[object Object]", ignoreCase = true)) return null
        val cleaned = raw.replace("%", "").replace("₺", "").trim()
        return when {
            Regex("^-?\\d{1,3}(\\.\\d{3})+,\\d+$").matches(cleaned) -> cleaned.replace(".", "").replace(',', '.').toDoubleOrNull()
            Regex("^-?\\d+,\\d+$").matches(cleaned) -> cleaned.replace(',', '.').toDoubleOrNull()
            else -> cleaned.toDoubleOrNull()
        }
    }
}
