package com.aurum.domain.kmodels.diagnostics

import com.aurum.domain.kmodels.KModelResult
import kotlin.math.abs

data class ReasonFieldDifference(
    val field: String,
    val expectedRaw: String?,
    val actualRaw: String?,
    val expectedNumber: Double?,
    val actualNumber: Double?,
    val absoluteError: Double?
)

data class ReasonComparison(
    val symbol: String,
    val model: String,
    val comparedFields: Int,
    val exactMatches: Int,
    val numericMatches: Int,
    val missingExpectedFields: List<String>,
    val differences: List<ReasonFieldDifference>
)

object ReasonFieldComparator {
    fun compare(result: KModelResult, expectedReason: String?, tolerance: Double = 0.00015): ReasonComparison {
        val expected = ReasonFieldParser.parse(expectedReason)
        val actual = result.reasonFields.entries.associate { ReasonFieldParser.normalize(it.key) to serialize(it.value) }
        val keys = (expected.keys + actual.keys).sorted()
        var exact = 0
        var numeric = 0
        val diffs = mutableListOf<ReasonFieldDifference>()
        for (key in keys) {
            val e = expected[key]
            val a = actual[key]
            if (e != null && a != null && e == a) exact++
            val en = number(e)
            val an = number(a)
            val err = if (en != null && an != null) abs(en-an) else null
            if (err != null && err <= tolerance) numeric++
            if (!(e != null && a != null && (e == a || (err != null && err <= tolerance)))) {
                diffs += ReasonFieldDifference(key,e,a,en,an,err)
            }
        }
        return ReasonComparison(result.symbol,result.model,expected.size,exact,numeric,
            expected.keys.filter { it !in actual },diffs)
    }

    private fun serialize(v: Any?): String? = when(v) {
        null -> null
        is Double -> if (v.isFinite()) "%.4f".format(java.util.Locale.US,v).trimEnd('0').trimEnd('.') else null
        is Float -> serialize(v.toDouble())
        is Number -> v.toString()
        is Boolean -> if(v) "1" else "0"
        else -> v.toString()
    }

    private fun number(v: String?): Double? = v?.replace(',','.')?.trim()?.toDoubleOrNull()
}
