package com.aurum.domain.kmodels

import kotlin.math.abs
import kotlin.math.floor

object Scoring {
    fun minMax(values: List<Double?>, invert: Boolean = false): List<Double?> {
        val nums = values.filterNotNull().filter { it.isFinite() }
        if (nums.isEmpty()) return values.map { null }
        val lo = nums.min()
        val hi = nums.max()
        if (abs(hi - lo) < 1e-12) return values.map { if (it == null) null else 0.5 }
        return values.map { v ->
            if (v == null || !v.isFinite()) null else {
                val t = ((v - lo) / (hi - lo)).coerceIn(0.0, 1.0)
                if (invert) 1.0 - t else t
            }
        }
    }

    fun robustRange(values: List<Double?>, invert: Boolean = false, low: Double = 0.05, high: Double = 0.95): List<Double?> {
        val nums = values.filterNotNull().filter { it.isFinite() }.sorted()
        if (nums.isEmpty()) return values.map { null }
        fun quantile(q: Double): Double {
            val pos = (nums.size - 1) * q.coerceIn(0.0, 1.0)
            val lo = floor(pos).toInt(); val hi = kotlin.math.ceil(pos).toInt()
            if (lo == hi) return nums[lo]
            val w = pos - lo
            return nums[lo] * (1 - w) + nums[hi] * w
        }
        val a = quantile(low); val b = quantile(high)
        if (abs(b - a) < 1e-12) return values.map { if (it == null) null else 0.5 }
        return values.map { v ->
            if (v == null || !v.isFinite()) null else {
                val t = ((v - a) / (b - a)).coerceIn(0.0, 1.0)
                if (invert) 1.0 - t else t
            }
        }
    }

    fun average(vararg columns: List<Double?>): List<Double?> {
        val size = columns.firstOrNull()?.size ?: 0
        return List(size) { i -> columns.mapNotNull { it.getOrNull(i) }.takeIf { it.isNotEmpty() }?.average() }
    }

    fun breakTies(base: List<Double?>, vararg epsColumns: List<Double?>): List<Double?> {
        val eps = if (epsColumns.isEmpty()) emptyList() else average(*epsColumns)
        val groups = base.indices.groupBy { i -> base[i]?.let { "%.4f".format(it) } ?: "NA" }
        return base.mapIndexed { i, v ->
            if (v == null) null else if ((groups["%.4f".format(v)]?.size ?: 0) > 1) v + (eps.getOrNull(i) ?: 0.0) else v
        }
    }
}
