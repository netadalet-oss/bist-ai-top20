package com.aurum.domain.kmodels.diagnostics

/** Parses the human-readable Apps Script reason string into structured fields. */
object ReasonFieldParser {
    fun parse(reason: String?): Map<String, String> {
        if (reason.isNullOrBlank()) return emptyMap()
        return reason.split(" | ").mapNotNull { token ->
            val idx = token.indexOf(':')
            if (idx <= 0) null else normalize(token.substring(0, idx)) to token.substring(idx + 1).trim()
        }.toMap()
    }

    fun normalize(value: String): String = value
        .trim()
        .replace(Regex("([a-z0-9])([A-Z])"), "$1_$2")
        .lowercase()
        .replace('ğ','g').replace('ü','u').replace('ş','s').replace('ı','i').replace('ö','o').replace('ç','c')
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
}
