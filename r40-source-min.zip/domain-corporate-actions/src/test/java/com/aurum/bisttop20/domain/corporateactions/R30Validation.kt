package com.aurum.bisttop20.domain.corporateactions

object R30Validation {
    @JvmStatic fun main(args: Array<String>) {
        val h1 = "a".repeat(64); val h2 = "b".repeat(64)
        val split = CorporateAction("a-split", "i1", CorporateActionType.SPLIT, 2000, 1900, ratio=2.0, sourceIds=setOf("s1","s2"), sourceHashesSha256=setOf(h1,h2), verified=true, qualityStatus="VALIDATED")
        val dividend = CorporateAction("a-div", "i1", CorporateActionType.CASH_DIVIDEND, 3000, 2900, cashAmount=10.0, referencePrice=100.0, sourceIds=setOf("s1","s2"), sourceHashesSha256=setOf(h1,h2), verified=true, qualityStatus="VALIDATED")
        val symbol = CorporateAction("a-sym", "i1", CorporateActionType.SYMBOL_CHANGE, 2500, 2500, oldSymbol="OLD", newSymbol="NEW", sourceIds=setOf("s1","s2"), sourceHashesSha256=setOf(h1,h2), verified=true, qualityStatus="VALIDATED")
        val raw = listOf(
            RawPriceBar("b1","i1","OLD",1000,100.0,110.0,90.0,100.0,1000.0,"src",h1),
            RawPriceBar("b2","i1","OLD",2600,90.0,95.0,85.0,90.0,1200.0,"src",h1),
            RawPriceBar("b3","i1","OLD",4000,80.0,82.0,78.0,81.0,1300.0,"src",h1)
        )
        val before = raw.map { it.copy() }
        val deps = listOf(FeatureSnapshotDependency("f1","i1",500,3500,true), FeatureSnapshotDependency("f2","i2",500,3500,true))
        val (adjusted, impact) = CorporateActionEngine().adjust(raw, listOf(split, symbol, dividend), deps)
        check(raw == before) { "raw bars mutated" }
        check(kotlin.math.abs(adjusted[0].close - 45.0) < 1e-9) { "split+dividend chain wrong: ${adjusted[0].close}" }
        check(kotlin.math.abs(adjusted[0].volume - 2000.0) < 1e-9)
        check(adjusted[1].displaySymbol == "NEW")
        check(kotlin.math.abs(adjusted[1].close - 81.0) < 1e-9)
        check(adjusted[2].close == 81.0 && adjusted[2].appliedActionIds.isEmpty())
        check(impact.affectedFeatureSnapshotIds == listOf("f1"))
        check(!impact.historicalPredictionsModified)
        var rejected = false
        try { CorporateActionValidator.validate(split.copy(sourceIds=setOf("s1"))) } catch (_: IllegalArgumentException) { rejected=true }
        check(rejected) { "single-source action accepted" }
        println("R30_CORPORATE_ACTION_ENGINE_PASS")
    }
}
