package com.aurum.bisttop20.domain.corporateactions

import java.security.MessageDigest

class CorporateActionValidationException(message: String) : IllegalArgumentException(message)

object CorporateActionValidator {
    fun validate(action: CorporateAction) {
        require(action.actionId.isNotBlank()) { "actionId required" }
        require(action.instrumentId.isNotBlank()) { "instrumentId required" }
        require(action.sourceIds.size >= 2) { "at least two sources required" }
        require(action.sourceHashesSha256.size >= 2 && action.sourceHashesSha256.all(::isSha256)) { "two valid source hashes required" }
        require(action.verified) { "unverified corporate action cannot adjust prices" }
        require(action.qualityStatus == "VALIDATED") { "qualityStatus must be VALIDATED" }
        require(action.effectiveEpochMillis >= action.referenceEpochMillis) { "effective time precedes reference time" }
        when (action.type) {
            CorporateActionType.RIGHTS_ISSUE,
            CorporateActionType.BONUS_ISSUE,
            CorporateActionType.SPLIT,
            CorporateActionType.REVERSE_SPLIT,
            CorporateActionType.MERGER -> require((action.ratio ?: 0.0) > 0.0) { "positive ratio required" }
            CorporateActionType.CASH_DIVIDEND -> require((action.cashAmount ?: -1.0) >= 0.0) { "cash amount required" }
            CorporateActionType.REFERENCE_PRICE_CHANGE -> require((action.referencePrice ?: 0.0) > 0.0) { "reference price required" }
            CorporateActionType.SYMBOL_CHANGE -> {
                require(!action.oldSymbol.isNullOrBlank() && !action.newSymbol.isNullOrBlank()) { "old/new symbol required" }
                require(action.oldSymbol != action.newSymbol) { "symbol must change" }
            }
        }
    }

    private fun isSha256(value: String): Boolean = value.matches(Regex("^[0-9a-fA-F]{64}$"))
}

object AdjustmentFactorCalculator {
    /** Returns a backward-adjustment factor applied to bars strictly before the action effective time. */
    fun priceFactor(action: CorporateAction): Double {
        CorporateActionValidator.validate(action)
        return when (action.type) {
            CorporateActionType.SPLIT,
            CorporateActionType.BONUS_ISSUE -> 1.0 / action.ratio!!
            CorporateActionType.REVERSE_SPLIT,
            CorporateActionType.MERGER -> action.ratio!!
            CorporateActionType.RIGHTS_ISSUE -> {
                val ratio = action.ratio!!
                val ref = action.referencePrice ?: throw CorporateActionValidationException("rights issue requires referencePrice")
                val subscription = action.cashAmount ?: throw CorporateActionValidationException("rights issue requires subscription price")
                ((ref + ratio * subscription) / (1.0 + ratio)) / ref
            }
            CorporateActionType.CASH_DIVIDEND -> {
                val ref = action.referencePrice ?: throw CorporateActionValidationException("dividend requires referencePrice")
                ((ref - action.cashAmount!!) / ref).coerceAtLeast(0.0)
            }
            CorporateActionType.REFERENCE_PRICE_CHANGE -> action.referencePrice!!
            CorporateActionType.SYMBOL_CHANGE -> 1.0
        }
    }

    fun volumeFactor(action: CorporateAction): Double = when (action.type) {
        CorporateActionType.SPLIT,
        CorporateActionType.BONUS_ISSUE -> action.ratio!!
        CorporateActionType.REVERSE_SPLIT,
        CorporateActionType.MERGER -> 1.0 / action.ratio!!
        else -> 1.0
    }
}

class CorporateActionEngine {
    fun adjust(
        rawBars: List<RawPriceBar>,
        actions: List<CorporateAction>,
        featureDependencies: List<FeatureSnapshotDependency>
    ): Pair<List<AdjustedPriceBar>, AdjustmentImpact> {
        require(rawBars.map { it.barId }.distinct().size == rawBars.size) { "duplicate raw bar id" }
        actions.forEach(CorporateActionValidator::validate)
        val ordered = actions.sortedBy { it.effectiveEpochMillis }
        val version = adjustmentVersion(ordered)
        val adjusted = rawBars.map { raw ->
            val applicable = ordered.filter { it.instrumentId == raw.instrumentId && raw.timestamp < it.effectiveEpochMillis }
            val priceFactor = applicable.fold(1.0) { acc, action -> acc * AdjustmentFactorCalculator.priceFactor(action) }
            val volumeFactor = applicable.fold(1.0) { acc, action -> acc * AdjustmentFactorCalculator.volumeFactor(action) }
            val displaySymbol = ordered
                .filter { it.instrumentId == raw.instrumentId && it.type == CorporateActionType.SYMBOL_CHANGE && raw.timestamp >= it.effectiveEpochMillis }
                .maxByOrNull { it.effectiveEpochMillis }?.newSymbol ?: raw.symbol
            AdjustedPriceBar(
                adjustedBarId = sha256("${raw.barId}|$version"),
                rawBarId = raw.barId,
                instrumentId = raw.instrumentId,
                displaySymbol = displaySymbol,
                timestamp = raw.timestamp,
                open = raw.open * priceFactor,
                high = raw.high * priceFactor,
                low = raw.low * priceFactor,
                close = raw.close * priceFactor,
                volume = raw.volume * volumeFactor,
                priceFactor = priceFactor,
                volumeFactor = volumeFactor,
                adjustmentVersion = version,
                appliedActionIds = applicable.map { it.actionId }
            )
        }
        val affectedRaw = adjusted.filter { it.appliedActionIds.isNotEmpty() }.map { it.rawBarId }
        val relevantActions = ordered.map { it.actionId }
        val minActionTime = ordered.minOfOrNull { it.effectiveEpochMillis }
        val affectedFeatures = if (minActionTime == null) emptyList() else featureDependencies
            .filter { dep -> ordered.any { it.instrumentId == dep.instrumentId && dep.startEpochMillis < it.effectiveEpochMillis && dep.endEpochMillis >= minActionTime } }
            .map { it.featureSnapshotId }
        return adjusted to AdjustmentImpact(
            actionIds = relevantActions,
            affectedRawBarIds = affectedRaw,
            affectedFeatureSnapshotIds = affectedFeatures,
            newAdjustmentVersion = version,
            anomalyRecheckRequired = affectedRaw.isNotEmpty()
        )
    }

    private fun adjustmentVersion(actions: List<CorporateAction>): String = sha256(
        actions.joinToString("|") { "${it.actionId}:${it.effectiveEpochMillis}:${it.type}:${it.ratio}:${it.cashAmount}:${it.referencePrice}" }
    )

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}
