package com.aurum.bisttop20.domain.corporateactions

enum class CorporateActionType {
    RIGHTS_ISSUE, BONUS_ISSUE, SPLIT, REVERSE_SPLIT, MERGER, CASH_DIVIDEND, REFERENCE_PRICE_CHANGE, SYMBOL_CHANGE
}

data class CorporateAction(
    val actionId: String,
    val instrumentId: String,
    val type: CorporateActionType,
    val effectiveEpochMillis: Long,
    val referenceEpochMillis: Long,
    val ratio: Double? = null,
    val cashAmount: Double? = null,
    val referencePrice: Double? = null,
    val oldSymbol: String? = null,
    val newSymbol: String? = null,
    val sourceIds: Set<String>,
    val sourceHashesSha256: Set<String>,
    val verified: Boolean,
    val qualityStatus: String = "PENDING"
)

data class RawPriceBar(
    val barId: String,
    val instrumentId: String,
    val symbol: String,
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val sourceId: String,
    val sourceHashSha256: String
)

data class AdjustedPriceBar(
    val adjustedBarId: String,
    val rawBarId: String,
    val instrumentId: String,
    val displaySymbol: String,
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val priceFactor: Double,
    val volumeFactor: Double,
    val adjustmentVersion: String,
    val appliedActionIds: List<String>
)

data class AdjustmentImpact(
    val actionIds: List<String>,
    val affectedRawBarIds: List<String>,
    val affectedFeatureSnapshotIds: List<String>,
    val newAdjustmentVersion: String,
    val anomalyRecheckRequired: Boolean,
    val historicalPredictionsModified: Boolean = false
)

data class FeatureSnapshotDependency(
    val featureSnapshotId: String,
    val instrumentId: String,
    val startEpochMillis: Long,
    val endEpochMillis: Long,
    val frozen: Boolean
)
