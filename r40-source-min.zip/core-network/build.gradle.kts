plugins { alias(libs.plugins.kotlin.android); alias(libs.plugins.android.library) }
android { namespace = "com.aurum.bisttop20.network"; compileSdk = 35; defaultConfig { minSdk = 26 }; compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }; kotlinOptions { jvmTarget = "17" } }
