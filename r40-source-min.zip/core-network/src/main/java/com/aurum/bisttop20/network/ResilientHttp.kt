package com.aurum.bisttop20.network

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.min
import kotlin.random.Random

data class HttpRequest(val url: String, val headers: Map<String,String> = emptyMap())
data class HttpResponse(val code: Int, val body: ByteArray, val headers: Map<String,List<String>>)

interface HttpTransport { fun execute(request: HttpRequest, connectTimeoutMs: Int, readTimeoutMs: Int): HttpResponse }

class UrlConnectionTransport : HttpTransport {
    override fun execute(request: HttpRequest, connectTimeoutMs: Int, readTimeoutMs: Int): HttpResponse {
        val c = URL(request.url).openConnection() as HttpURLConnection
        c.requestMethod = "GET"; c.connectTimeout = connectTimeoutMs; c.readTimeout = readTimeoutMs
        c.instanceFollowRedirects = true; c.setRequestProperty("Accept-Encoding", "gzip")
        c.setRequestProperty("User-Agent", "Aurum-BIST-Top20/0.39")
        request.headers.forEach { (k,v) -> c.setRequestProperty(k,v) }
        return try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            HttpResponse(code, stream?.use { it.readBytes() } ?: ByteArray(0), c.headerFields.filterKeys { it != null })
        } finally { c.disconnect() }
    }
}

data class RetryPolicy(
    val maxAttempts: Int = 3,
    val connectTimeoutMs: Int = 8_000,
    val readTimeoutMs: Int = 15_000,
    val initialBackoffMs: Long = 400,
    val maxBackoffMs: Long = 5_000,
    val retryableCodes: Set<Int> = setOf(408, 425, 429, 500, 502, 503, 504)
)

data class QuotaPolicy(val maxRequests: Int, val windowMs: Long)
class QuotaExceeded(message: String): IOException(message)
class HttpFailure(val status: Int, message: String): IOException(message)

class FixedWindowQuota {
    private data class Counter(var start: Long, var used: Int)
    private val counters = ConcurrentHashMap<String, Counter>()
    @Synchronized fun acquire(key: String, policy: QuotaPolicy, now: Long = System.currentTimeMillis()) {
        val c = counters.getOrPut(key) { Counter(now,0) }
        if (now-c.start >= policy.windowMs) { c.start=now; c.used=0 }
        if (c.used >= policy.maxRequests) throw QuotaExceeded("QUOTA_EXCEEDED:$key")
        c.used++
    }
}

class ResilientHttpClient(
    private val transport: HttpTransport = UrlConnectionTransport(),
    private val sleeper: (Long)->Unit = { Thread.sleep(it) },
    private val quota: FixedWindowQuota = FixedWindowQuota()
) {
    fun get(sourceId: String, urls: List<String>, retry: RetryPolicy, quotaPolicy: QuotaPolicy, headers: Map<String,String> = emptyMap()): HttpResponse {
        require(urls.isNotEmpty())
        var last: Throwable? = null
        urls.forEach { url ->
            repeat(retry.maxAttempts) { idx ->
                quota.acquire(sourceId, quotaPolicy)
                try {
                    val r = transport.execute(HttpRequest(url, headers), retry.connectTimeoutMs, retry.readTimeoutMs)
                    if (r.code in 200..299) return r
                    if (r.code !in retry.retryableCodes) throw HttpFailure(r.code, "HTTP_${r.code}:$url")
                    last = HttpFailure(r.code, "RETRYABLE_HTTP_${r.code}:$url")
                } catch (e: IOException) { last = e }
                if (idx + 1 < retry.maxAttempts) {
                    val cap = min(retry.maxBackoffMs, retry.initialBackoffMs shl idx)
                    sleeper((cap/2) + Random.nextLong(0, cap/2 + 1))
                }
            }
        }
        throw IOException("ALL_SOURCES_FAILED", last)
    }
}
