package com.aurum.bisttop20.network

import java.io.IOException

private class FakeTransport(private val outcomes:MutableMap<String,ArrayDeque<Any>>):HttpTransport{
 override fun execute(request:HttpRequest,connectTimeoutMs:Int,readTimeoutMs:Int):HttpResponse{
  val x=outcomes.getValue(request.url).removeFirst()
  if(x is Throwable) throw x
  return x as HttpResponse
 }
}
fun main(){
 val outcomes:MutableMap<String,ArrayDeque<Any>> = mutableMapOf(
  "primary" to ArrayDeque(listOf(HttpResponse(503,byteArrayOf(),emptyMap()) as Any,HttpResponse(503,byteArrayOf(),emptyMap()) as Any,HttpResponse(503,byteArrayOf(),emptyMap()) as Any)),
  "fallback" to ArrayDeque(List(5){HttpResponse(200,"ok".toByteArray(),emptyMap()) as Any})
 )
 val c=ResilientHttpClient(FakeTransport(outcomes), sleeper={})
 val r=c.get("s",listOf("primary","fallback"),RetryPolicy(maxAttempts=3),QuotaPolicy(10,60_000))
 check(String(r.body)=="ok")
 var quota=false
 try{ repeat(3){c.get("q",listOf("fallback"),RetryPolicy(maxAttempts=1),QuotaPolicy(1,60_000))} }catch(_:QuotaExceeded){quota=true}catch(_:Exception){}
 check(quota)
 println("R39_NETWORK_POLICY_PASS")
}
